'use strict';
// 单场会议详情页：独立窗口，不碰 index.html 的会议状态。数据优先取 Mac 归档 /meeting-result；Mac 不在线或该场未同步时退回本机 localStorage（tht-state）。
const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const id=new URLSearchParams(location.search).get('id')||'';
let settings={};try{settings=JSON.parse(localStorage.getItem('tht-settings')||'{}');}catch{}
const ts=v=>typeof v==='number'?v:(Date.parse(v)||0);
const fmtDur=sec=>{sec=Math.max(0,Math.round(sec));const h=Math.floor(sec/3600),m=Math.floor(sec%3600/60),s=sec%60;return (h?h+':':'')+String(m).padStart(2,'0')+':'+String(s).padStart(2,'0');};
const clock=(row,start)=>{if(row.t)return row.t;const at=Number(row.at||0);const rel=at>1e11?(at-start)/1000:at;const m=Math.floor(rel/60),s=Math.floor(rel%60);return m+':'+String(s).padStart(2,'0');};
let record=null,source='';
// 界面语言跟着主界面走：主界面存了就用存的，没存过按浏览器语言猜一次
let uiLang=(navigator.language||'').toLowerCase().startsWith('zh')?'zh':'en';
try{const v=localStorage.getItem('tht-ui');if(v)uiLang=(v==='en'?'en':'zh');}catch{}
if(window.opener||history.length<=1){$('#closewin').hidden=false;$('#closewin').onclick=()=>window.close();}

function fromLocal(){try{const st=JSON.parse(localStorage.getItem('tht-state')||'{}');return (st.sessions||[]).find(s=>String(s.id)===id)||null;}catch{return null;}}
async function fromMac(){const r=await fetch('/asr-relay/meeting-result?id='+encodeURIComponent(id)+'&token='+encodeURIComponent(settings.relayToken||''),{cache:'no-store',signal:AbortSignal.timeout(6000)});if(!r.ok)throw Error(String(r.status));return r.json();}

// 说话人只显示真名或「未认人」（Aaron 09-22 定）：S0 / S1 这类声音编号只留在数据里，不上界面。
const UNNAMED=()=>uiLang==='en'?'Unnamed':'未认人';
function spkName(s,names){if(!s)return '';return (names&&names[s])||({me:'我',them:'对方'})[s]||UNNAMED();}
let hasAudio=false;
let audioGone='';   // 'retention' = 录音已按保留期清理（服务端 X-Audio-Gone 头），回看页据此显示说明而不是空白
let audioRetentionDays=30;
// 点任何一个时间戳都跳到播放器的那一刻。录音不存在时整套回听不出现。
function seekTo(sec){const a=$('#player');if(!a)return;const t=Math.max(0,Number(sec)||0);
  const go=()=>{try{a.currentTime=t;a.play().catch(()=>{});}catch(e){}};
  if(a.readyState>=1)go();else{a.addEventListener('loadedmetadata',go,{once:true});a.load();}}
document.addEventListener('click',e=>{const b=e.target.closest('.play');if(!b)return;e.preventDefault();seekTo(b.dataset.sec);});
document.addEventListener('keydown',e=>{if(e.key!=='Enter'&&e.key!==' ')return;const b=e.target.closest&&e.target.closest('time.play');if(!b)return;e.preventDefault();seekTo(b.dataset.sec);});

// 批 4（F5 / F4）：会后台那块小统计（四个数，服务端 finalize 时从 usage.jsonl 与场次算好，落在 s.stats）+ 附件区（one_pager 纠错单，s.attachments）。
// 没有 stats 也没有附件（老场次）就整块不出现。纠错单链接带口令走 /asr-relay/one-pager。
function renderPostStats(s){
  const box=$('#post-stats'); if(!box) return;
  const st=s.stats&&typeof s.stats==='object'?s.stats:null;
  const att=Array.isArray(s.attachments)?s.attachments.filter(a=>a&&a.kind==='one_pager'&&a.path):[];
  if(!st&&!att.length){box.hidden=true;box.innerHTML='';return;}
  const en=(s.uiLang||'')==='en'; const n=v=>Number.isFinite(Number(v))?String(Number(v)):'—';
  const parts=[];
  if(st){
    parts.push('<span title="usage.jsonl provider=jev">'+(en?'Jev calls':'Jev 调用')+' <b>'+n(st.jevCalls)+'</b></span>');
    parts.push('<span title="usage.jsonl live 档">'+(en?'Sonnet calls':'Sonnet 调用')+' <b>'+n(st.sonnetCalls)+'</b></span>');
    parts.push('<span>'+(en?'Insights':'洞察')+' <b>'+n(st.insights)+'</b></span>');
    parts.push('<span title="adopt 反馈或按钮已执行">'+(en?'Adopted':'被采纳')+' <b>'+n(st.adopted)+'</b></span>');
    if(st.sourceHit&&typeof st.sourceHit==='object') parts.push('<span title="按钮执行时出处 / 承诺卡查到没有">'+(en?'Source hit / miss':'出处命中 / 缺失')+' <b>'+n(st.sourceHit.hit)+'</b> / <b>'+n(st.sourceHit.miss)+'</b></span>');
  }
  for(const a of att){
    const href='/asr-relay/'+String(a.path).replace(/^\/+/,'')+'&token='+encodeURIComponent(settings.relayToken||'');
    parts.push('<span>📄 <a href="'+esc(href)+'" target="_blank" rel="noopener">'+esc(a.title||(en?'One-pager':'一页纠错单'))+'</a></span>');
  }
  box.innerHTML=parts.join(''); box.hidden=false;
}
function render(s){
  record=s;
  const start=ts(s.start);const lastAt=(s.transcript&&s.transcript.length)?Number(s.transcript[s.transcript.length-1].at||0):0;
  const end=ts(s.end)||(lastAt>1e11?lastAt:(lastAt?start+lastAt*1000:0));
  const title=s.topicTitle||s.title||('会议 '+new Date(start).toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'}));
  document.title=title; $('#title').textContent=title;
  const parts=[];
  parts.push('<span><b>'+esc(new Date(start).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}))+'</b></span>');
  if(end)parts.push('<span>时长 <b>'+fmtDur((end-start)/1000)+'</b></span>');
  parts.push('<span><b>'+(s.transcript||[]).length+'</b> 句</span>');
  if(s.topicTitle&&s.title&&s.title!==s.topicTitle)parts.push('<span title="原始标题">'+esc(s.title.slice(0,40))+'</span>');
  const ppl=Array.isArray(s.participants)?s.participants.filter(Boolean):[];
  if(ppl.length)parts.push('<span>参会人 <b>'+esc(ppl.join('、'))+'</b></span>');
  if(s.speakerWarning)parts.push('<span>'+esc(s.speakerWarning)+'</span>');
  // 转写缺口和说话人存疑是两件事（R3）：缺口只提示、不抹名字，两条并存各显各的
  if(s.gapWarning)parts.push('<span>'+esc(s.gapWarning)+'</span>');
  // 降级要看得见：首选模型没回应、备用顶上了，这一行说清这场是谁写的（会中那条黄条的会后版）
  if(s.modelNote||(s.brief&&s.brief.modelNote))parts.push('<span>'+esc(s.modelNote||s.brief.modelNote)+'</span>');
  $('#meta').innerHTML=parts.join('');
  renderPostStats(s);
  mountPlayer();
  mountMemoryLink();
  mountHead(s);
  // 原话表要在 renderBrief 之前备好：议题要点下面那行原话按 seg 取，晚一步就取不到，
  // 直接以「完整」状态打开的那一次会少掉原话，得再点一次开关才补上。
  segText=new Map();(s.transcript||[]).forEach(row=>{const id=row.id!=null?String(row.id):'';if(id)segText.set(id,row.text||'');});
  $('#src-chip').hidden=false;$('#src-chip').textContent=source==='mac'?'来源：Mac 归档'+(s.archiveNote?'（'+s.archiveNote+'）':''):'来源：本机记录（Mac 未同步）';
  renderBrief(s);
  paintSpeakers();
  const tr=(s.transcript||[]);$('#c-tr').textContent=tr.length;
  const names=spkMap(s);
  // 段落 id 挂在 <p> 上：要点点一下要落到「就是这一句」，靠的是 data-seg，不是按时间猜最近的一句。
  $('#transcript').innerHTML=tr.length?tr.map(row=>{const sp=row.speaker||row.spk||row.who||'';const rsec=(()=>{const at=Number(row.at||0);if(!at)return null;return at>1e11?(at-start)/1000:at;})();
    const seg=row.id!=null?String(row.id):'';
    return '<p'+(seg?' data-seg="'+esc(seg)+'"':'')+(rsec!=null?' data-sec="'+rsec+'"':'')+'>'+(hasAudio&&rsec!=null?'<time class="play" role="button" tabindex="0" data-sec="'+rsec+'" title="'+(uiLang==='en'?'Replay this line':'回听这一句')+'">'+esc(clock(row,start))+'</time>':'<time>'+esc(clock(row,start))+'</time>')+(sp?'<span class="spk s'+esc(String(sp).replace(/\D/g,'')||'0')+'">'+esc(spkName(sp,names))+'</span>':'')+esc(row.text)+'</p>'+(row.originalText&&row.originalText!==row.text?'<span class="orig">原句：'+esc(row.originalText)+'</span>':'');}).join(''):'<div class="empty">没有转写内容。</div>';
}

// ---- 回看页新版（REQ-004）：页面只渲染结构化数据，不出现 Markdown 原始标记 ----
const COLORS=['#202124','#c8102e','#1f5fbf','#1e7e34','#b26a00','#6a3fb5','#00838f','#8d6e63'];
const mmss=sec=>{sec=Math.max(0,Math.round(sec||0));const h=Math.floor(sec/3600),m=Math.floor(sec%3600/60),x=sec%60;return (h?h+':'+String(m).padStart(2,'0'):m)+':'+String(x).padStart(2,'0');};
// 界面文案：[中文, English]。这一屏原来全是中文，界面切到 en 时只有一半跟着换。
const L={sum:['智能总结','Summary'],rev:['洞察与行动','Insights & actions'],ins:['洞察','Insights'],acts:['行动','Actions'],addTodo:['加为待办','Add to-do'],more:['展开依据','Show reasoning'],revItems:['这场没有需要你注意的偏离或冲突。','No deviations or conflicts to flag.'],
  topics:['议题','Topics'],keyc:['核心结论','Key conclusions'],todos:['待办','Action items'],
  quick:['一屏速览','At a glance'],concl:['结论：','Conclusion: '],noKeyc:['这场没有形成核心结论。','No key conclusions.'],
  colWhat:['事项','Item'],colWho:['负责人','Owner'],colDue:['期限','Due'],sugg:['建议','suggested'],
  sayPh:['一句话改待办：「第 2 条派给 Cary，周五前」「加一条：整理手板结果」「第 3 条不要了」','Change to-dos in one line: "#2 assign to Cary, by Friday" "add: collect mockup results" "#3 drop"'],
  sayGo:['执行','Apply'],sayBusy:['正在改…','Applying…'],sayCancel:['取消','Cancel'],sayStop:['已取消','Cancelled'],
  sayHint:['「派给谁」只填好草稿，真建任务还要你点「派发」。','"Assign to" only fills in the draft; nothing is sent until you click Assign.'],
  byModel:['模型理解的','interpreted by the model'],
  detail:['议题展开','Topics in detail'],showFull:['展开完整','Show full'],showBrief:['只看结论','Conclusions only'],
  open:['未决：','Open: '],noConc:['未形成结论','No conclusion reached'],srcLine:['原句','Source'],
  facts:['补充背景','Background'],align:['和项目目标的关系','Against project goals'],
  noCtx:['未接项目背景，以下只依据会内内容。','No project context attached; this is based on the meeting alone.'],
  revFail:['点评这次没生成出来：','Review did not come through: '],revNone:['点评尚未生成。','Review not generated yet.'],
  inferred:['会内推断','inferred from the meeting'],by:['依据：','Source: '],
  askLeft:['需要你定一下 · 还剩 {n} 题','Your call · {n} left'],
  askDone:['需要你定的 {n} 题都已确定','All {n} questions answered'],
  done:['✓ 已确定','✓ Answered'],edit:['改','Edit'],extra:['补充：','Note: '],
  recommend:[' · 推荐',' · suggested'],optNote:['补一句（可选）','Add a note (optional)'],
  noSave:['没存上，Mac 在线后再点一次','Not saved; try again when the Mac is online'],
  decHint:['改状态','Change status']};
const t=k=>L[k][uiLang==='en'?1:0];
const tf=(k,n)=>t(k).replace('{n}',n);
// 议题的决定状态：四选一，页面上每个议题都显示，点一下能改。
const DEC=[['已一致','Agreed','ok'],['待讨论','Open',''],['有分歧','Disputed','bad'],['搁置','Parked','mute']];
const decLabel=v=>{const d=DEC.find(x=>x[0]===v)||DEC[1];return uiLang==='en'?d[1]:d[0];};
const decClass=v=>{const d=DEC.find(x=>x[0]===v)||DEC[1];return d[2];};
const decOf=(b,card)=>{const v=(b.decisions||{})[String(card.n)]||card.decision;return DEC.some(x=>x[0]===v)?v:'待讨论';};
// 速览 / 完整只有这一个开关，状态记在本机。隐私窗口里 localStorage 会抛，抛了就当默认速览。
let viewFull=false;try{viewFull=localStorage.getItem('tht-archive-view')==='full';}catch{}
const setViewFull=v=>{viewFull=v;try{localStorage.setItem('tht-archive-view',v?'full':'brief');}catch{}};
let segText=new Map();
const decEditing=new Set();
// 名字只存一处：names 映射。以前这里还从「需要你定一下」的答案里二次推导，
// 于是认人清单把一个名字清掉之后，旧答案又会把它顶回来。现在认人只走 /speaker-confirm，答案不再参与显示。
// names 里的键可能是 '1' 也可能是老写法 'S1'（share.who 两种都认），这里归一到转写用的 '1'，不然认了名的人会被「未认人」盖掉
function spkMap(s){const m={};(s.transcript||[]).forEach(r=>{const k=String(r.speaker??r.spk??r.who??'');if(k&&/^\w{1,12}$/.test(k)&&!m[k])m[k]=UNNAMED();});Object.entries(s.names||{}).forEach(([k,v])=>{if(!v)return;const kk=(/^S\d+$/.test(k)&&!(k in m)&&(k.slice(1) in m))?k.slice(1):k;m[kk]=v;});return m;}
function nmTxt(text,map){let t=String(text==null?'':text);Object.keys(map).forEach(k=>{if(!map[k]||!/^\w{1,12}$/.test(k))return;t=t.replace(new RegExp('(?:说话人\\s*|Speaker\\s*|S)'+k+'(?!\\d)','g'),map[k]);});return t;}
function nm(text,map){let t=esc(text);Object.keys(map).forEach(k=>{if(!map[k]||!/^\w{1,12}$/.test(k))return;t=t.replace(new RegExp('(?:说话人\\s*|Speaker\\s*|S)'+k+'(?!\\d)','g'),()=>esc(map[k]));});return t;}
// 时间胶囊 = 回到原句的入口。段落 id（seg）在就精确落到那一句；只有时间就按时间找最近的一句；
// 两样都没有的条目不做成可点的样式，免得点了没反应。
const tbtn=(sec,seg)=>(sec||seg)?'<button type="button" class="bf-t" data-sec="'+Number(sec||0)+'"'+(seg?' data-seg="'+esc(seg)+'"':'')+'>'+(sec?mmss(sec):t('srcLine'))+'</button>':'';
function mdLite(src){ // 旧会议只有 Markdown 长文时的兜底渲染
  const out=[];let ul=false,tb=false;const inl=t=>esc(t).replace(/\*\*(.+?)\*\*/g,'<b>$1</b>').replace(/`([^`]+)`/g,'$1').replace(/\*([^*]+)\*/g,'$1');
  const close=()=>{if(ul){out.push('</ul>');ul=false;}if(tb){out.push('</table>');tb=false;}};
  String(src||'').split('\n').forEach(l=>{const x=l.trim();
    if(!x||/^-{3,}$/.test(x)){close();return;}
    let m;
    if((m=/^(#{1,6})\s+(.*)$/.exec(x))){close();out.push('<h3>'+inl(m[2])+'</h3>');return;}
    if(/^\|/.test(x)){if(/^\|[\s:|-]+\|?$/.test(x))return;if(ul){out.push('</ul>');ul=false;}if(!tb){out.push('<table>');tb=true;}out.push('<tr>'+x.replace(/^\||\|$/g,'').split('|').map(c=>'<td>'+inl(c.trim())+'</td>').join('')+'</tr>');return;}
    if((m=/^(?:[-*+]|\d+[.)、])\s+(?:\[[ xX]\]\s*)?(.*)$/.exec(x))){if(tb){out.push('</table>');tb=false;}if(!ul){out.push('<ul>');ul=true;}out.push('<li>'+inl(m[1])+'</li>');return;}
    close();out.push('<p>'+inl(x.replace(/^>\s*/,''))+'</p>');});
  close();return out.join('');}
function renderBrief(s){
  const b=s.brief, grid=$('#bf-grid'), legacy=$('#legacy-box'), ask=$('#ask-box');
  if(!b||!b.overview){
    grid.hidden=true;ask.hidden=true;legacy.hidden=false;
    $('#summary').innerHTML=s.summary?mdLite(s.summary):'<p class="bf-note">总结尚未完成，逐字稿已保留。</p>';
    const btn=$('#bf-build');btn.hidden=source!=='mac'||!(s.transcript||[]).length;btn.onclick=()=>buildBrief(btn);
    return;
  }
  legacy.hidden=true;grid.hidden=false;
  $('#bf-sum-h').textContent=t('sum');$('#bf-rev-h').textContent=t('rev');
  const map=spkMap(s), ov=b.overview, dur=Math.max(b.duration||0,...ov.topics.map(x=>x.to||0),1);
  let bar='',pos=0;ov.topics.forEach((x,i)=>{const f=Math.max(pos,x.from||0),to=Math.max(f,x.to||0);if(f>pos)bar+='<i class="gap" style="width:'+((f-pos)/dur*100)+'%"></i>';bar+='<i data-sec="'+f+'" title="'+esc(x.title)+' '+mmss(f)+'–'+mmss(to)+'" style="width:'+((to-f)/dur*100)+'%;background:'+COLORS[i%COLORS.length]+'">'+x.n+'</i>';pos=to;});
  // 飞书纪要式（Aaron 09-22 定）：标题自动编号（1 速览 / 2 议题 / 3 待办，议题再编 2.1 2.2），结论加粗，待办是表。
  // 一个议题一张卡片：速览只留结论和状态，完整才展开要点和原话。开关只有 #bf-view 那一个。
  const quote=seg=>seg?(segText.get(String(seg))||''):'';
  const card=(c,i)=>{const head=ov.topics[i]||{},v=decOf(b,c),editing=decEditing.has(String(c.n));
    const badge=editing
      ? '<span class="bf-dec-pick">'+DEC.map(d=>'<button type="button" class="bf-opt'+(d[0]===v?' on':'')+'" data-dec-set="'+c.n+'|'+d[0]+'">'+esc(uiLang==='en'?d[1]:d[0])+'</button>').join('')+'</span>'
      : '<button type="button" class="bf-dec '+decClass(v)+'" data-dec="'+c.n+'" title="'+esc(t('decHint'))+'">'+esc(decLabel(v))+'</button>';
    return '<div class="bf-card" data-topic="'+c.n+'"><h3><span class="fs-n sub">2.'+(i+1)+'</span><span class="bf-ttl">'+nm(head.title||'',map)+'</span>'+badge+(head.to?'<span class="bf-dur">'+mmss(head.from||0)+'–'+mmss(head.to)+'</span>':'')+'</h3>'
      +'<div class="bf-key"><b>'+esc(t('concl'))+(c.conclusion?nm(c.conclusion,map):esc(t('noConc')))+'</b></div>'
      +(viewFull?'<ul>'+(c.points||[]).map(x=>'<li>'+nm(x.text,map)+tbtn(x.at,x.seg)+(quote(x.seg)?'<div class="bf-quote">「'+nm(quote(x.seg),map)+'」</div>':'')+'</li>').join('')+'</ul>'
        +(c.open&&c.open.length?'<div class="bf-open">'+esc(t('open'))+c.open.map(x=>nm(x,map)).join('；')+'</div>':''):'')
      +'</div>';};
  $('#bf-sum').innerHTML=
    (b.meta&&b.meta.scope?'<p class="bf-scope">'+nm(b.meta.scope,map)+'</p>':'')
    +'<section class="fs"><h3 class="fs-h"><span class="fs-n">1</span>'+esc(t('keyc'))+'</h3>'
      +(ov.conclusions.length?ov.conclusions.slice(0,3).map(c=>'<div class="bf-key"><b>'+nm(c,map)+'</b></div>').join(''):'<p class="bf-note">'+esc(t('noKeyc'))+'</p>')+'</section>'
    +'<section class="fs"><h3 class="fs-h"><span class="fs-n">2</span>'+esc(t('topics'))+'</h3>'
      +'<div class="td-wrap"><table class="bf-table bf-tt"><thead><tr><th>#</th><th>'+esc(T('议题','Topic'))+'</th><th>'+esc(T('结论','Conclusion'))+'</th><th>'+esc(T('状态','Status'))+'</th><th>'+esc(T('未对齐','Open'))+'</th><th>'+esc(T('下一步','Next'))+'</th></tr></thead><tbody>'
      +ov.topics.map((x,i)=>{const c=(b.topics||[])[i]||{},td=(b.todos||[]).filter(t=>t.topic===x.n||t.topic===i+1);
        return '<tr><td class="td-n"><span class="bf-n" style="background:'+COLORS[i%COLORS.length]+'">'+x.n+'</span></td><td><b>'+nm(x.title,map)+'</b><div class="bf-dur">'+mmss(x.from)+'–'+mmss(x.to)+'</div></td>'
          +'<td>'+(c.conclusion?nm(c.conclusion,map):'<span class="bf-sug">'+esc(t('noConc'))+'</span>')+'</td>'
          +'<td><span class="bf-tag '+(c.decision==='已一致'?'ok':c.decision==='有分歧'?'bad':'')+'">'+esc(c.decision||'—')+'</span></td>'
          +'<td>'+((c.open||[]).length?(c.open||[]).map(o=>nm(o,map)).join('<br>'):'<span class="bf-sug">—</span>')+'</td>'
          +'<td>'+(td.length?td.map(t=>nm(t.what,map)+(t.owner?' <span class="bf-sug">· '+esc(t.owner)+'</span>':'')).join('<br>'):'<span class="bf-sug">—</span>')+'</td></tr>';}).join('')
      +'</tbody></table></div><div class="bf-bar">'+bar+'</div>'
      +'<details class="bf-detail"'+(viewFull?' open':'')+'><summary class="fs-h">'+esc(t('detail'))+' <span class="bf-sug">'+(b.topics||[]).length+'</span></summary>'+(b.topics||[]).map(card).join('')+'</details></section>'
    +'<section class="fs" id="bf-brain"><h3 class="fs-h"><span class="fs-n">3</span>'+esc(T('项目状态更新','Project state updates'))+' <span class="bf-sug" id="bf-upd-n"></span></h3><div id="bf-updates"></div></section>';
  const view=$('#bf-view');view.textContent=viewFull?t('showBrief'):t('showFull');view.onclick=()=>{setViewFull(!viewFull);render(record);};
  $('#bf-sum').querySelectorAll('[data-dec]').forEach(el=>el.onclick=()=>{decEditing.add(el.dataset.dec);render(record);});
  $('#bf-sum').querySelectorAll('[data-dec-set]').forEach(el=>el.onclick=()=>{const [n,v]=el.dataset.decSet.split('|');saveDecision(Number(n),v);});
  paintActions();
  // REQ-009：点评里删掉了三块——逐句挑错、夸「哪些说对了」都不是重点（Aaron 09-20「很鸡肋」），
  // 「建议」那一区搬去了待办卡。和事实源硬冲突的那几条，现在以风险提示的形式出现在待办卡下面。
  // Aaron 09-24：洞察 + 行动并排在智能总结旁，取代「点评与指导」。洞察 = 冲突 / 偏离 / 一句话立场 / 补充背景，每条最多一个动作；行动 = 待办表 + 一句话改待办。
  const r=b.review||{};
  const dev=(r.alignment||[]).filter(a=>a.status&&a.status!=='推进');
  const ins=(b.insights||[]).filter(x=>x&&x.question);
  const insItems=ins.length?ins.map((x,i)=>'<div class="bf-ins"><span class="td-n">'+(x.n||i+1)+'</span><div><b>'+nm(x.question,map)+'</b><div>'+nm(x.answer||'',map)+'</div>'
      +(x.detail?'<details class="bf-more"><summary>'+esc(t('more'))+'</summary><div class="bf-quote">'+mdLite(x.detail)+'</div></details>':'')+'</div>'
      +(x.action&&x.action.text?'<button type="button" class="bf-t" data-say="'+esc('加一条：'+x.action.text+(x.action.owner?'，派给 '+x.action.owner:''))+'">'+esc(x.action.label||t('addTodo'))+'</button>':'')+'</div>')
    // 没有 insights 的老场次：退回偏离 + 背景，也编号
    :dev.map((a,i)=>'<div class="bf-ins"><span class="td-n">'+(i+1)+'</span><div><span class="bf-tag '+(a.status==='偏离'?'bad':'')+'">'+esc(a.status)+'</span><b>'+esc(a.goal)+'</b><div>'+nm(a.note,map)+'</div></div><button type="button" class="bf-t" data-say="'+esc('加一条：'+a.goal+'——'+(a.note||''))+'">'+esc(t('addTodo'))+'</button></div>')
      .concat((r.facts||[]).map((f,i)=>'<div class="bf-ins"><span class="td-n">'+(dev.length+i+1)+'</span><div>'+nm(f.text,map)+(f.source?'<div class="bf-src">'+esc(f.source)+'</div>':'')+'</div></div>'));
  const revItems=insItems;
  $('#bf-rev').innerHTML=
    '<section class="fs" id="bf-ins"><h3 class="fs-h">'+esc(t('ins'))+'</h3>'
      +(b.review||ins.length?'':'<p class="bf-note">'+(b.reviewWarning?esc(t('revFail'))+esc(b.reviewWarning):esc(t('revNone')))+'</p>')
      +'<div id="bf-risks"></div><div id="bf-rev-items">'+(revItems.join('')||(b.review?'<p class="bf-note">'+esc(t('revItems'))+'</p>':''))+'</div><div id="bf-think"></div></section>'
    +'<section class="fs" id="bf-todo"><h3 class="fs-h">'+esc(t('acts'))+' <span class="bf-sug" id="bf-todo-n"></span></h3><div id="bf-cards"></div><div id="bf-say"></div></section>';
  $('#bf-rev').querySelectorAll('[data-say]').forEach(el=>el.onclick=()=>{sayDraft=el.dataset.say;saySend(el.dataset.say);});
  // 问「S2 是谁」的题不在这里出现了：认人只有上面那一个入口（#spk-box），两处都问会互相顶。
  const qs=(b.questions||[]).filter(q=>!(q.affects||[]).some(f=>/^speaker:/i.test(f)));ask.hidden=!qs.length;
  if(qs.length){const ans=b.answers||{};
    const left=qs.filter(q=>!ans[q.id]).length;
    ask.innerHTML='<h2>'+esc(left?tf('askLeft',left):tf('askDone',qs.length))+'</h2>'+qs.map((q,i)=>{const a=ans[q.id];
      // 答过的收成一行：✓ 题目 → 你的答案，要改再点开
      if(a&&!askEditing.has(q.id)){const v=(a.text||'').trim();return '<div class="bf-qdone" data-q="'+esc(q.id)+'"><span class="bf-tag ok">'+esc(t('done'))+'</span><span class="bf-qd-ask">'+esc(q.ask)+'</span><b>'+esc(q.options[a.choice]||'')+'</b>'+(v?'<span class="bf-src">'+esc(t('extra'))+esc(v)+'</span>':'')+'<button type="button" class="bf-t" data-edit="'+esc(q.id)+'">'+esc(t('edit'))+'</button></div>';}
      const cur=a?a.choice:q.recommend;return '<div class="bf-qrow" data-q="'+esc(q.id)+'"><b>'+(i+1)+'　'+esc(q.ask)+'</b>'+q.options.map((o,k)=>'<button type="button" class="bf-opt'+(k===cur?' on':'')+'" data-k="'+k+'" title="'+(k===q.recommend?esc(q.why||''):'')+'">'+esc(o)+(k===q.recommend?esc(t('recommend')):'')+'</button>').join('')+'<input type="text" placeholder="'+esc(t('optNote'))+'" value="'+esc(a&&a.text||'')+'"></div>';}).join('');
    ask.querySelectorAll('[data-edit]').forEach(el=>el.onclick=()=>{askEditing.add(el.dataset.edit);render(record);});
    ask.querySelectorAll('.bf-qrow').forEach(row=>{const qid=row.dataset.q;const send=(choice,text)=>saveAnswer(qid,choice,text);
      row.querySelectorAll('.bf-opt').forEach(o=>o.onclick=()=>send(Number(o.dataset.k),row.querySelector('input').value));
      row.querySelector('input').onchange=e=>{const on=row.querySelector('.bf-opt.on');send(on?Number(on.dataset.k):0,e.target.value);};});
  }
  document.querySelectorAll('#bf-grid [data-sec],#ask-box [data-sec]').forEach(el=>el.onclick=()=>jumpTo(Number(el.dataset.sec),el.dataset.seg||''));
}
// ===== 会后一屏认人 =====
// 谁还没名字、他说过哪几句、候选人是谁，都由 /meeting-speakers 算好。这里只负责：听一段、点一下、当场全页换名。
// 认人只有这一个入口——「需要你定一下」里问说话人的题已经隐藏（见 renderBrief）。
let spkRows=null,spkOpen=false,spkAll=false,spkNote='',spkNoteBad=false,spkNoteFor='',spkAudio=null,spkPlaying='';
const spkLabel=k=>k==='me'?'我':k==='them'?'对方':UNNAMED();
async function loadSpeakers(){
  if(source!=='mac')return;
  try{const r=await fetch('/asr-relay/meeting-speakers?id='+encodeURIComponent(id)+'&token='+encodeURIComponent(settings.relayToken||''),{cache:'no-store',signal:AbortSignal.timeout(8000)});
      const j=await r.json();if(j.ok)spkRows=j.speakers;}catch(e){spkRows=null;}
  paintSpeakers();
}
function paintSpeakers(){
  const box=$('#spk-box');if(!box)return;
  if(!spkRows||!spkRows.length){box.hidden=true;return;}
  box.hidden=false;
  const left=spkRows.filter(r=>!r.name).length;
  // 全认完就收成一行——这件事做完了，不该继续占着智能总结上面的位置
  if(!left&&!spkOpen){
    box.innerHTML='<div class="spk-done"><b>已认 '+spkRows.length+' 人</b><span>'+esc(spkRows.map(r=>r.name).join('，'))+'</span><button type="button" id="spk-edit">改</button>'+spkState()+'</div>';
    $('#spk-edit').onclick=()=>{spkOpen=true;spkNote='';spkNoteFor='';paintSpeakers();};
    return;
  }
  // 声音一多（一场会常有 8–10 个编号）整块会把总结挤到两屏以下。先只摆说话最多的 3 个——逐字稿大头就是他们，其余一键展开。
  const many=spkRows.length>3&&!spkAll,shown=many?spkRows.slice(0,3):spkRows,restLines=many?spkRows.slice(3).reduce((n,r)=>n+(r.lines||0),0):0;
  box.innerHTML='<h2>这场会里的人</h2><p class="spk-hint">'+(left?'还有 '+left+' 个人没名字。听一句，点个名字，逐字稿、总结、待办里的「'+UNNAMED()+'」当场全换过来。':'都认完了，点名字可以改。')+'</p>'
    +shown.map(r=>'<div class="spk-row" data-spk="'+esc(r.spk)+'"><span class="spk-who"><i class="spk-dot" style="background:'+COLORS[(Number(String(r.spk).replace(/\D/g,''))||0)%COLORS.length]+'"></i>'+esc(r.name||spkLabel(r.spk))+'</span><span class="spk-lines">'+r.lines+' 句</span>'
      +'<div class="spk-samples">'+(r.samples.length
        ? r.samples.map(x=>'<button type="button" class="spk-clip" data-clip="'+esc(r.spk)+'|'+x.start+'|'+x.dur+'"><span class="t">'+(hasAudio?'▶ ':'')+mmss(x.start)+'</span><span class="q">'+esc(x.text)+'</span></button>').join('')
        : '<span class="spk-lines">这个编号只有零碎的语气词，没有整句可听</span>')+'</div>'
      +'<div class="spk-acts">'+r.candidates.map(c=>'<button type="button" data-pick="'+esc(c)+'">'+esc(c)+'</button>').join('')
      +'<input type="text" placeholder="或者自己填，回车保存" value="'+esc(r.name||'')+'">'
      +'<button type="button" class="self" data-pick="本人">是本人</button>'
      +'<span class="spk-state'+(spkNoteFor===r.spk&&spkNoteBad?' bad':'')+'">'+(spkNoteFor===r.spk?esc(spkNote):'')+'</span></div></div>').join('')
    +(many?'<div class="spk-done"><span>'+T('还有 '+(spkRows.length-3)+' 个声音，共 '+restLines+' 句','+'+(spkRows.length-3)+' more voices, '+restLines+' lines')+'</span><button type="button" id="spk-all">'+T('展开','Show all')+'</button></div>':'');
  if(many)$('#spk-all').onclick=()=>{spkAll=true;paintSpeakers();};
  box.querySelectorAll('.spk-row').forEach(row=>{const spk=row.dataset.spk;
    row.querySelectorAll('[data-pick]').forEach(b=>b.onclick=()=>saveSpeaker(spk,b.dataset.pick,row));
    const input=row.querySelector('input');
    input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();saveSpeaker(spk,input.value,row);}};
  });
  box.querySelectorAll('[data-clip]').forEach(b=>b.onclick=()=>playClip(b));
}
function spkState(){return spkNote?'<span class="spk-state'+(spkNoteBad?' bad':'')+'">'+esc(spkNote)+'</span>':'';}
// 试听：只取那一段的 WAV（服务端按 start/dur 切），再点一次就停。同时只播一段。
function playClip(btn){
  if(!hasAudio)return;
  const key=btn.dataset.clip,[,start,dur]=key.split('|');
  if(!spkAudio){spkAudio=new Audio();spkAudio.onended=()=>{spkPlaying='';paintPlaying();};}
  if(spkPlaying===key){spkAudio.pause();spkPlaying='';return paintPlaying();}
  spkAudio.src=audioUrl()+'&start='+encodeURIComponent(start)+'&dur='+encodeURIComponent(dur);
  spkPlaying=key;paintPlaying();
  spkAudio.play().catch(()=>{spkPlaying='';paintPlaying();});
}
function paintPlaying(){document.querySelectorAll('[data-clip]').forEach(b=>{const t=b.querySelector('.t');if(t)t.textContent=(b.dataset.clip===spkPlaying?'⏸ ':'▶ ')+mmss(Number(b.dataset.clip.split('|')[1]));});}
async function saveSpeaker(spk,name,row){
  spkNoteFor=spk;
  const state=row.querySelector('.spk-state');if(state){state.textContent='保存中…';state.classList.remove('bad');}
  try{
    const r=await fetch('/asr-relay/speaker-confirm?token='+encodeURIComponent(settings.relayToken||''),
      {method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id,names:{[spk]:String(name||'').trim()}}),signal:AbortSignal.timeout(20000)});
    const j=await r.json();
    if(!j.ok)throw Error(j.error||'没存上');
    spkRows=j.speakers;record.names=j.names;
    spkNote=String(name||'').trim()?'已保存':'已清掉这个名字';spkNoteBad=false;
    if(!spkRows.filter(x=>!x.name).length)spkOpen=false;   // 认完了就收起来，别让它一直占着位置
    render(record);                                        // 全页的 S 编号当场换成人名
  }catch(e){spkNote='没存上：'+(e.message||e);spkNoteBad=true;paintSpeakers();}
}
// ===== 会后处理台（REQ-009）=====
// 这一屏的目标：看完这场会产生的事就已经清掉了，每件事只点一次。
// 卡片、草稿、预研究都是会后自动备好的（/meeting-actions），这里只负责显示和「点那一下」。
// 外发只有一条路：把草稿改完，点「发出 / 派发」。没有任何别的按钮会往外发东西。
const T=(zh,en)=>uiLang==='en'?en:zh;
const KIND_LABEL=k=>({meeting:T('我要组织的会','Meeting to set up'),research:T('让我做的研究','Research for me'),
  delegate:T('派给别人','Delegate'),self:T('我自己做',"I'll do it")}[k]||k);
let actData=null,actStatus='',actTimer=null,actOpen=new Set(),actNote=new Map(),actFocus=null;
const actUncertain=new Set();   // 第 9 条：上次「发」没弄清发没发出去的卡；再点先问一句，带 retryConfirmed 才让服务端重发
const actTok=()=>encodeURIComponent(settings.relayToken||'');

async function loadActions(){
  if(source!=='mac')return;
  try{
    const r=await fetch('/asr-relay/meeting-actions?id='+encodeURIComponent(id)+'&token='+actTok(),{cache:'no-store',signal:AbortSignal.timeout(15000)});
    const j=await r.json();
    actStatus=j.status||'';
    if(j.status==='done'){actData=j.actions;stopActPoll();}
    else if(j.status==='running'&&!actTimer)actTimer=setInterval(loadActions,4000);   // 跑完自己更新，不用他刷新
    else if(j.status!=='running')stopActPoll();
  }catch(e){actStatus='error';actNote.set('*',T('读不到处理台数据：','Could not load: ')+(e.message||e));stopActPoll();}
  paintActions();
}
function stopActPoll(){if(actTimer){clearInterval(actTimer);actTimer=null;}}
// 「项目现在最重要的三件事」每天全项目共用一份，不每场重算——每场重算它会漂，漂了就没人信。
async function loadFocus(){
  if(source!=='mac')return;
  try{const r=await fetch('/asr-relay/project-focus?token='+actTok(),{cache:'no-store',signal:AbortSignal.timeout(20000)});
      actFocus=await r.json();}catch(e){actFocus=null;}
  paintActions();
}
function paintActions(){
  const box=document.getElementById('bf-cards');if(!box)return;
  const think=document.getElementById('bf-think'),risks=document.getElementById('bf-risks'),cnt=document.getElementById('bf-todo-n');
  if(!actData){
    if(cnt)cnt.textContent='';
    box.innerHTML=actStatus==='running'
      ? '<p class="bf-note">'+T('正在把这场会产生的事整理成待办（通常 1–3 分钟），好了这里会自己出现。','Turning this meeting into to-dos (usually 1–3 min). It will appear here on its own.')+'</p>'
      : (actStatus==='unavailable'||actStatus==='error'
        ? '<p class="bf-note">'+esc(actNote.get('*')||T('这场会还没整理出待办。','No to-dos from this meeting yet.'))+'</p>'
        : '');
    if(think)think.innerHTML='';if(risks)risks.innerHTML='';
    paintSay();return;
  }
  const cards=actData.cards||[],live=cards.filter(c=>c.state!=='dismissed'),hidden=cards.filter(c=>c.state==='dismissed');
  if(cnt)cnt.textContent=live.length;
  box.innerHTML=(actData.classifiedBy==='rules'&&live.length?'<p class="bf-note">'+T('这批分类是按关键词判的（模型这次没回应），类型可能要你自己调。','Typed by keyword rules this time (the model did not answer).')+'</p>':'')
    +(live.length?'<div class="td-wrap"><table class="bf-table td-table"><thead><tr><th>#</th><th>'+esc(t('colWhat'))+'</th><th>'+esc(t('colWho'))+'</th><th>'+esc(t('colDue'))+'</th><th></th></tr></thead><tbody>'+live.map((c,i)=>actRow(c,i+1)).join('')+'</tbody></table></div>':'<p class="bf-note">'+T('这场没有要处理的事。','Nothing to process from this meeting.')+'</p>')
    +hidden.map(c=>'<div class="bf-undo" data-undo="'+esc(c.id)+'"><span>'+(c.doneAt?T('已做完','Done'):T('已收起','Dismissed'))+'「'+esc(c.text.slice(0,40))+'」</span><button type="button">'+T('撤销','Undo')+'</button></div>').join('');
  if(think)think.innerHTML=thinkHtml();
  if(risks)risks.innerHTML=risksHtml();
  paintSay();
  wireActions(box);
  wireHandoff(box,cid=>{const c=(actData.cards||[]).find(x=>x.id===cid)||{};return {meetingId:sessionIdOf(),meetingTitle:(record&&record.title)||'',kind:'todo',text:c.text||'',context:c.reason||'',due:c.due||(c.draft&&c.draft.due)||''};},paintActions);
}
// 待办表的一行：# / 事项（类型标签 + 说明）/ 负责人 / 期限 / 动作。展开的草稿占整行。
function actRow(c,n){
  const note=actNote.get(c.id)||'',open=actOpen.has(c.id),d=c.draft||{},map=spkMap(record||{});
  const owner=c.owner||d.assignee||'',due=c.due||d.due||'';
  return '<tr class="bf-act'+(c.state==='sent'?' done':'')+'" data-card="'+esc(c.id)+'"><td class="td-n">'+n+'</td>'
    +'<td><span class="bf-tag k-'+esc(c.kind)+'">'+esc(KIND_LABEL(c.kind))+'</span>'+nm(c.text,map)
    +(c.reason?'<div class="bf-act-why">'+nm(c.reason,map)+'</div>':'')
    +(c.advice&&c.advice!==c.text?'<div class="bf-act-why">'+T('建议做法：','Suggested: ')+nm(c.advice,map)+'</div>':'')
    +(c.researchSkipped?'<div class="bf-act-why">'+esc(c.researchSkipped)+'</div>':'')
    +(c.sentNote?'<div class="bf-act-why">'+esc(c.sentNote)+'</div>':'')
    +(c.claimFailed&&c.claimNote?'<div class="bf-act-why">'+esc(c.claimNote)+'</div>':'')+'</td>'
    +'<td>'+(owner?nm(owner,map):'<span class="bf-sug">—</span>')+'</td><td>'+(due?esc(due):'<span class="bf-sug">—</span>')+'</td>'
    +'<td class="td-act">'+mainAction(c,open)+(c.state==='sent'?'':hoBtn(c.id))+'<button type="button" class="bf-x" data-x="'+esc(c.id)+'" title="'+T('我不认这条','Not mine')+'" aria-label="'+T('我不认这条','Not mine')+'">✕</button>'
    +(note?'<div class="bf-act-state'+(/没|失败|不/.test(note)?' bad':'')+'">'+esc(note)+'</div>':'')+'</td></tr>'
    +(open?'<tr class="bf-draft-row" data-card="'+esc(c.id)+'"><td colspan="5"><div class="bf-draft">'+draftHtml(c)+'</div></td></tr>':'')
    +(hoOpen.has(c.id)||hoNote.get(c.id)?'<tr class="bf-draft-row"><td colspan="5">'+hoForm(c.id,/^S\d+$/.test(owner)?'':owner)+'</td></tr>':'');
}
// ===== 一句话改待办（Aaron 09-22 定）=====
// 不限模板：规则听得懂的当场改，听不懂的服务端问模型翻译成同一套操作。这里不外发：「派给谁」只填草稿，还要点「派发」。
let sayBusy=false,sayLog='',sayBad=false,sayDraft='',sayAbort=null;
function paintSay(){
  const host=document.getElementById('bf-say');if(!host)return;
  if(source!=='mac'){host.innerHTML='';return;}
  host.innerHTML='<form class="bf-say" id="say-form"><input type="text" id="say-in" maxlength="800" autocomplete="off" placeholder="'+esc(t('sayPh'))+'" value="'+esc(sayDraft)+'"'+(sayBusy?' disabled':'')+'>'
    +(sayBusy?'<button type="button" id="say-cancel">'+esc(t('sayCancel'))+'</button>':'<button type="submit">'+esc(t('sayGo'))+'</button>')+'</form>'
    +(sayBusy?'<div class="bf-say-log">'+esc(t('sayBusy'))+'</div>':'')
    +(sayLog?'<div class="bf-say-log'+(sayBad?' bad':'')+'">'+sayLog+'</div>':'')
    +'<p class="bf-say-hint">'+esc(t('sayHint'))+'</p>';
  const input=document.getElementById('say-in');input.oninput=()=>{sayDraft=input.value;};
  document.getElementById('say-form').onsubmit=e=>{e.preventDefault();const v=input.value.trim();if(v&&!sayBusy)saySend(v);};
  const cancel=document.getElementById('say-cancel');if(cancel)cancel.onclick=()=>{if(sayAbort)sayAbort.abort();};
}
async function saySend(text){
  sayBusy=true;sayLog='';sayBad=false;sayAbort=new AbortController();paintSay();
  const timer=setTimeout(()=>sayAbort&&sayAbort.abort(),90000);
  try{
    const r=await fetch('/asr-relay/todo-say?token='+actTok(),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id,text}),signal:sayAbort.signal});
    const j=await r.json();
    if(!j.ok)throw Error(j.error||T('没改成','Failed'));
    actData=j.actions;actStatus='done';if(j.focus)actOpen.add(j.focus);
    sayLog=(j.applied||[]).map(x=>'✓ '+nm(x,spkMap(record||{}))).join('<br>')+(j.by==='model'?' <span class="bf-sug">· '+esc(t('byModel'))+'</span>':'');sayDraft='';
  }catch(e){
    // 取消 = 撤回这次请求；服务端可能已经改完，所以取消后重读一遍，页面上不留半截状态
    if(e&&e.name==='AbortError'){sayLog=esc(t('sayStop'));sayBad=false;clearTimeout(timer);sayBusy=false;sayAbort=null;loadActions();return;}
    sayLog=esc(e.message||e);sayBad=true;
  }
  clearTimeout(timer);sayBusy=false;sayAbort=null;paintActions();
}
function thinkHtml(){
  const lines=[];
  if(actData&&actData.thinking&&actData.thinking.position)lines.push(esc(actData.thinking.position));
  if(actFocus&&actFocus.configured&&(actFocus.items||[]).length)
    lines.push(T('项目现在最重要的三件事：','Top three for the project right now: ')+esc(actFocus.items.join('；')));
  if(!lines.length)return '';
  return '<div class="bf-h">'+T('一句话思考','In one line')+'</div>'+lines.map(x=>'<div class="bf-think">'+x+'</div>').join('');
}
// 没有硬冲突时整块不渲染——这里不出现任何「本场没有风险」的空状态，那只是噪音。
function risksHtml(){
  const rs=(actData&&actData.risks)||[];if(!rs.length)return '';
  return '<div class="bf-h">'+T('风险提示','Conflicts')+'</div>'+rs.map(r=>'<div class="bf-risk">'+esc(r.text)
    +(r.evidence?'<div class="bf-src">'+T('依据：','Source: ')+esc(r.evidence.slice(0,160))+'</div>':'')
    +(r.link?'<div class="bf-src"><a href="'+esc(r.link)+'" target="_blank" rel="noopener">'+T('看依据','Open source')+' ↗</a></div>':'')+'</div>').join('');
}
function mainAction(c,open){
  if(c.state==='sent'){
    const cal=c.sentRef&&c.sentRef.type==='calendar';
    const label=cal?T('已发出 · 看日历','Sent · open calendar'):T('已派发 · 看任务','Assigned · open task');
    return c.sentRef&&c.sentRef.url
      ? '<a class="bf-go" href="'+esc(c.sentRef.url)+'" target="_blank" rel="noopener">'+label+' ↗</a>'
      : '<span class="bf-go done">'+label+'</span>';
  }
  if(c.state==='claimed')return '<span class="bf-go done">'+T('已进「我的待办」',"In my to-dos")+'</span>';
  if(c.kind==='self')return '<button type="button" class="bf-go" data-do="claim">'+T('我来做',"I'll do it")+'</button>';
  const label=c.kind==='meeting'?T('打开日历草稿','Open calendar draft')
    :c.kind==='delegate'?T('打开任务草稿','Open task draft'):T('看预研究','See pre-research');
  return '<button type="button" class="bf-go" data-open="1">'+(open?T('收起','Collapse'):label)+'</button>';
}
function draftHtml(c){
  const d=c.draft||{};
  if(c.kind==='meeting'){
    if(!d.title&&!(d.slots||[]).length)return '<p class="bf-note">'+T('日历草稿这次没生成出来，下面自己填也能发。','No draft this time — fill it in and send.')+'</p>'+meetingForm({});
    return meetingForm(d);
  }
  if(c.kind==='delegate')return delegateForm(d);
  if(!d.scope&&!d.expected)return '<p class="bf-note">'+T('预研究这次没跑出来。','The pre-research did not run this time.')+'</p>';
  return '<div class="bf-pre"><b>'+T('会覆盖什么','Scope')+'</b><p>'+esc(d.scope||'')+'</p>'
    +((d.sources||[]).length?'<b>'+T('用哪些源','Sources')+'</b><ul>'+d.sources.map(s=>'<li>'+esc(s)+'</li>').join('')+'</ul>':'')
    +'<b>'+T('预计给出什么结论','Expected conclusion')+'</b><p>'+esc(d.expected||'')+'</p>'
    +refsHtml(d.refs)+'</div>';
}
// 依据：这份草稿是引擎真去查了哪几条资料才写出来的。会议点回那一场，飞书文档点开原文，
// 本机文件只给路径（浏览器打不开本机盘，给了也是死链）。没有依据就不出现这一段，不写「无」。
function refsHtml(refs){
  const list=(refs||[]).filter(r=>r&&r.ref);
  if(!list.length)return '';
  return '<b>'+T('依据','What this is based on')+'</b><ul class="bf-refs">'+list.map(r=>{
    const label=esc(r.title||r.ref);
    const where=esc(SRC_LABEL(r.source)+(r.at?' · '+String(r.at).slice(0,10):''));
    let body=label;
    if(r.meetingId)body='<a href="archive.html?id='+encodeURIComponent(r.meetingId)+'">'+label+'</a>';
    else if(/^https?:\/\//.test(String(r.url||'')))body='<a href="'+esc(r.url)+'" target="_blank" rel="noopener">'+label+'</a>';
    return '<li>'+body+(where?' <em class="bf-note">'+where+'</em>':'')+'</li>';
  }).join('')+'</ul>';
}
// 依据后面那个小标签写「东西在哪」，不是把工具层的内部来源码直接摆出来。
// 取不到就退回前缀，再取不到就不写——宁可少一个标签，也不给他一个 local:meeting 这种字眼。
const SRC_LABEL=s=>{
  const v=String(s||'');
  const full={'local:meeting':T('会议','Meeting'),'local:memory':T('会议记忆','Memory'),'local:file':T('本机文件','Local file'),
    'local:hub':T('工作台','Work hub'),'hub:upstream':T('工作台','Work hub'),
    'lark:docs':T('飞书文档','Feishu doc'),'lark:calendar':T('飞书日历','Feishu calendar'),'lark:task':T('飞书任务','Feishu task'),
    'slack:search':'Slack','notion:search':'Notion','notion:blocks':'Notion'}[v];
  if(full)return full;
  return {local:T('本机','Local'),hub:T('工作台','Work hub'),lark:T('飞书','Feishu'),slack:'Slack',notion:'Notion'}[v.split(':')[0]]||'';
};
function meetingForm(d){
  const slots=d.slots||[];
  return '<label class="bf-f"><span>'+T('标题','Title')+'</span><input type="text" data-f="title" value="'+esc(d.title||'')+'"></label>'
    +'<label class="bf-f"><span>'+T('议程','Agenda')+'</span><textarea data-f="agenda" rows="3" placeholder="'+T('一行一条','One per line')+'">'+esc((d.agenda||[]).join('\n'))+'</textarea></label>'
    +'<label class="bf-f"><span>'+T('参会人','Attendees')+'</span><input type="text" data-f="attendees" value="'+esc((d.attendees||[]).join('、'))+'" placeholder="'+T('顿号分隔；留空就先不邀请人','Separated by 、; leave empty to invite nobody')+'"></label>'
    +(slots.length?'<div class="bf-f"><span>'+T('时间','When')+'</span><div class="bf-slots">'+slots.map((s,i)=>'<label><input type="radio" name="slot-'+Math.random().toString(36).slice(2,7)+'" data-f="pick" value="'+i+'"'+(i?'':' checked')+'> '+esc(whenText(s))+'</label>').join('')+'</div></div>':'')
    +'<label class="bf-f"><span>'+T('说明','Note')+'</span><textarea data-f="note" rows="2">'+esc(d.note||'')+'</textarea></label>'
    +'<div class="bf-send"><button type="button" data-do="send">'+T('发出会议邀请','Send invite')+'</button>'
    +'<span class="bf-note">'+T('点这一下才真发，改完再点。','Nothing goes out until you click this.')+'</span></div>';
}
function delegateForm(d){
  return '<label class="bf-f"><span>'+T('负责人','Assignee')+'</span><input type="text" data-f="assignee" value="'+esc(nmTxt(d.assignee||'',spkMap(record||{})))+'"></label>'
    +'<label class="bf-f"><span>'+T('截止','Due')+'</span><input type="date" data-f="due" value="'+esc(d.due||'')+'">'
    +(d.dueDefault?'<em class="bf-note">'+T('默认截止，可改','Default due date — change it')+'</em>':'')+'</label>'
    +'<label class="bf-f"><span>'+T('说明','Description')+'</span><textarea data-f="description" rows="4">'+esc(nmTxt(d.description||'',spkMap(record||{})))+'</textarea></label>'
    +'<label class="bf-f"><span>'+T('相关链接','Links')+'</span><textarea data-f="links" rows="2" placeholder="'+T('一行一个','One per line')+'">'+esc((d.links||[]).join('\n'))+'</textarea></label>'
    +'<div class="bf-send"><button type="button" data-do="send">'+T('派发','Assign')+'</button>'
    +'<span class="bf-note">'+T('点这一下才真建飞书任务。','No Feishu task is created until you click this.')+'</span></div>';
}
function whenText(s){
  try{const a=new Date(s.start),b=new Date(s.end);
    const p=n=>String(n).padStart(2,'0');
    return (a.getMonth()+1)+'/'+a.getDate()+' '+p(a.getHours())+':'+p(a.getMinutes())+'–'+p(b.getHours())+':'+p(b.getMinutes());
  }catch(e){return String(s.start||'');}
}
// ===== 项目状态更新（Project Brain，2026-09-24）=====
// 会后模型把这场会和 .memory/project-state.md 对照，列出「改变了我们对项目哪些认知」；每条只在这里点一次：
// 接受 / 改一下 → 写回 project-state.md 对应节（带来源）；不要 → 记住，下次同义不再提。模型自己永远写不到状态文件。
let updDoc=null,updStatus='',updBusy=false,updEdit=new Map(),updNote='';
const UPD_TYPE={new_fact:'新事实',changed_fact:'口径变化',decision:'决定',superseded_decision:'推翻旧决定',owner_change:'负责人变化',milestone_change:'节点变化',new_action:'新动作',resolved_question:'未定项已定',new_open_question:'新未定项',assumption:'假设',risk:'风险',blocker:'阻塞'};
const UPD_LEVEL={mentioned:'提到',discussed:'讨论过',proposed:'有人提议',agreed:'会上同意',decided:'会上拍板'};
async function loadUpdates(run){
  if(source!=='mac')return;
  updBusy=!!run;paintUpdates();
  try{
    const r=await fetch('/asr-relay/memory-updates?id='+encodeURIComponent(id)+(run?'&run=1':'')+'&token='+actTok(),{cache:'no-store',signal:AbortSignal.timeout(run?180000:15000)});
    const j=await r.json();
    if(!j.ok){updStatus='error';updNote=j.error||'';}
    else{updStatus=j.status;updDoc=j.doc;updNote='';}
  }catch(e){updStatus='error';updNote=e.message||String(e);}
  updBusy=false;paintUpdates();
}
async function decideUpdate(uid,action,all){
  const it=all?null:(updDoc.items||[]).find(x=>x.uid===uid);
  const text=action==='edit'?(updEdit.get(uid)||'').trim():'';
  if(action==='edit'&&text.length<4){updNote=T('改后的内容太短','Edited text too short');paintUpdates();return;}
  if(all&&!confirm(T('把所有待确认条目写进项目状态？','Accept all pending updates into project state?')))return;
  updBusy=true;paintUpdates();
  try{
    const r=await fetch('/asr-relay/memory-update?token='+actTok(),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id,uid:uid||'',do:action,text,all:!!all,confirmed:true}),signal:AbortSignal.timeout(20000)});
    const j=await r.json();
    if(!j.ok){updNote=j.error||'';}else{updDoc=j.doc;updNote='';updEdit.delete(uid);}
  }catch(e){updNote=e.message||String(e);}
  updBusy=false;paintUpdates();
}
function paintUpdates(){
  const box=document.getElementById('bf-updates'),cnt=document.getElementById('bf-upd-n');if(!box)return;
  const items=(updDoc&&updDoc.items)||[],pend=items.filter(x=>!x.decision);
  if(cnt)cnt.textContent=updDoc?(pend.length?pend.length+' '+T('条待确认','pending'):T('已全部处理','all done')):'';
  let h='';
  if(updBusy)h+='<p class="bf-note">'+T('正在对照项目状态…（最长 3 分钟）','Comparing with project state… (up to 3 min)')+'</p>';
  if(updNote)h+='<p class="bf-note bad">'+esc(updNote)+'</p>';
  if(!updDoc){
    h+='<p class="bf-note">'+(updStatus==='error'?T('读不到差异数据。','Could not load.'):T('这场会还没和项目状态对照过。','Not compared with project state yet.'))+'</p>';
    if(!updBusy)h+='<button type="button" class="bf-btn" data-upd-run="1">'+T('现在对照','Compare now')+'</button>';
    box.innerHTML=h;wireUpdates(box);return;
  }
  h+='<p class="bf-note">'+T('模型只列「这场会改变了我们对项目哪些认知」；你点「接受」才写进 project-state.md，写回的行带来源。','Only items that change what we know. Nothing is written until you accept; each accepted line carries its source.')+'</p>';
  if(!items.length)h+='<p class="bf-note">'+T('这场会没有改变项目状态的内容。','This meeting changed nothing in project state.')+'</p>';
  h+=items.map(it=>{
    const d=it.decision,lv=UPD_LEVEL[it.level]||it.level,ty=UPD_TYPE[it.type]||it.type;
    const head='<div class="upd-h"><span class="td-tag">'+esc(ty)+'</span> <b>'+esc(it.field)+'</b> <span class="bf-sug">'+esc(lv)+' · '+esc(it.confidence)+' · '+esc(it.section.replace(/^##\s*/,''))+'</span>'+(it.sectionGuessed?' <span class="bf-tag bad">节由模型推断</span>':'')+'</div>';
    const body='<div class="upd-b"><div><span class="bf-sug">'+T('原','Before')+'</span> '+esc(it.before)+'</div><div><span class="bf-sug">'+T('改为','After')+'</span> '+esc(d&&d.action==='edit'?d.text:it.after)+'</div>'+(it.evidence?'<div class="bf-sug">'+T('会上原话','Said')+'：'+esc(it.evidence)+'</div>':'')+'</div>';
    let act;
    if(d)act='<div class="upd-a bf-sug">'+(d.action==='reject'?T('已拒绝','Rejected'):d.action==='edit'?T('已按改后写入','Written (edited)'):T('已写入项目状态','Written'))+'</div>';
    else act='<div class="upd-a"><textarea class="upd-in" data-upd-in="'+esc(it.uid)+'" rows="2" placeholder="'+esc(T('要改就在这里改，再点「改一下」','Edit here, then click Edit'))+'">'+esc(updEdit.get(it.uid)||'')+'</textarea>'
      +'<button type="button" class="bf-btn" data-upd="'+esc(it.uid)+'" data-act="accept"'+(updBusy?' disabled':'')+'>'+T('接受','Accept')+'</button> '
      +'<button type="button" class="bf-btn" data-upd="'+esc(it.uid)+'" data-act="edit"'+(updBusy?' disabled':'')+'>'+T('改一下','Edit')+'</button> '
      +'<button type="button" class="bf-btn ghost" data-upd="'+esc(it.uid)+'" data-act="reject"'+(updBusy?' disabled':'')+'>'+T('不要','Reject')+'</button> '+hoBtn(it.uid)+'</div>';
    return '<div class="upd'+(d?' done':'')+'" data-upd-card="'+esc(it.uid)+'">'+head+body+act+hoForm(it.uid,hoGuess(it.after))+'</div>';
  }).join('');
  h+='<div class="upd-foot">'+(pend.length>1?'<button type="button" class="bf-btn" data-upd-all="1"'+(updBusy?' disabled':'')+'>'+T('全部接受','Accept all')+'</button> ':'')
    +'<button type="button" class="bf-btn ghost" data-upd-run="1"'+(updBusy?' disabled':'')+'>'+T('重新对照','Compare again')+'</button></div>';
  box.innerHTML=h;wireUpdates(box);
  wireHandoff(box,uid=>{const it=items.find(x=>x.uid===uid)||{};return {meetingId:sessionIdOf(),meetingTitle:(record&&record.title)||'',kind:'decision',text:it.field+'：'+(it.after||''),context:T('原：','Before: ')+(it.before||'')+(it.evidence?'\n'+it.evidence:'')};},paintUpdates);
}
function wireUpdates(box){
  box.querySelectorAll('[data-upd-in]').forEach(el=>el.addEventListener('input',()=>updEdit.set(el.getAttribute('data-upd-in'),el.value)));
  box.querySelectorAll('[data-upd]').forEach(b=>b.addEventListener('click',()=>decideUpdate(b.getAttribute('data-upd'),b.getAttribute('data-act'),false)));
  const all=box.querySelector('[data-upd-all]');if(all)all.addEventListener('click',()=>decideUpdate('','accept',true));
  const run=box.querySelector('[data-upd-run]');if(run)run.addEventListener('click',()=>loadUpdates(true));
}
function wireActions(box){
  box.querySelectorAll('[data-undo]').forEach(el=>el.querySelector('button').onclick=()=>actDo(el.dataset.undo,'restore'));
  box.querySelectorAll('tr[data-card]').forEach(row=>{
    const cid=row.dataset.card;
    const x=row.querySelector('[data-x]');if(x)x.onclick=()=>actDo(cid,'dismiss');
    const open=row.querySelector('[data-open]');
    if(open)open.onclick=()=>{if(actOpen.has(cid))actOpen.delete(cid);else actOpen.add(cid);paintActions();};
    row.querySelectorAll('[data-do]').forEach(b=>b.onclick=()=>actDo(cid,b.dataset.do,readDraft(row)));
  });
}
// 草稿只从这张卡自己的输入框读，不从内存里拼——他看到什么就发什么。
function readDraft(card){
  const d={},f=n=>card.querySelector('[data-f="'+n+'"]');
  const val=n=>{const el=f(n);return el?el.value:undefined;};
  if(val('title')!==undefined)d.title=val('title').trim();
  if(val('agenda')!==undefined)d.agenda=val('agenda').split('\n').map(x=>x.trim()).filter(Boolean);
  if(val('attendees')!==undefined)d.attendees=val('attendees').split(/[、,，;；]/).map(x=>x.trim()).filter(Boolean);
  if(val('note')!==undefined)d.note=val('note');
  const picked=card.querySelector('[data-f="pick"]:checked');
  if(picked)d.pick=Number(picked.value)||0;
  if(val('assignee')!==undefined)d.assignee=val('assignee').trim();
  if(val('due')!==undefined)d.due=val('due');
  if(val('description')!==undefined)d.description=val('description');
  if(val('links')!==undefined)d.links=val('links').split('\n').map(x=>x.trim()).filter(Boolean);
  if(!Object.keys(d).length)return undefined;
  const cur=(actData.cards||[]).find(c=>c.id===card.dataset.card);
  if(cur&&cur.kind==='meeting'&&cur.draft&&cur.draft.slots)d.slots=cur.draft.slots;   // 时间备选不让他手打，只让他选
  return d;
}
async function actDo(cardId,action,draft){
  const body={id,cardId,do:action,draft,confirmed:action==='send'};
  if(action==='send'&&actUncertain.has(cardId)){
    if(!confirm(T('上次没确认发没发出去，确定再发？','Last attempt may or may not have gone out. Send again?')))return;
    body.retryConfirmed=true;
  }
  actNote.set(cardId,action==='send'?T('正在发…','Sending…'):T('处理中…','Working…'));
  paintActions();
  try{
    const r=await fetch('/asr-relay/meeting-action?token='+actTok(),{method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify(body),signal:AbortSignal.timeout(120000)});
    const j=await r.json();
    if(!j.ok){if(j.uncertain)actUncertain.add(cardId);throw Error(j.error||T('没成','failed'));}
    actData=j.actions;
    if(action==='send'){actOpen.delete(cardId);actUncertain.delete(cardId);actNote.set(cardId,j.alreadySent?T('这份早发过了，没再发','Already sent earlier; not sent again'):'');}
    else if(action==='claim')actNote.set(cardId,j.card.claimNote||'');
    else if(action==='save-draft')actNote.set(cardId,T('草稿已存','Draft saved'));
    else actNote.set(cardId,'');
  }catch(e){actNote.set(cardId,(action==='send'?T('没发出去：','Not sent: '):T('没成：','Failed: '))+(e.message||e));}
  paintActions();
}


// 点一个要点 → 落到逐字稿里那一句。带段落 id 的落到「就是这一句」；只有时间的按时间找最近的一句。
function jumpTo(sec,seg){
  seekTo(sec);const box=$('#tr-box');box.open=true;
  let hit=null;
  if(seg)for(const p of document.querySelectorAll('#transcript p[data-seg]'))if(p.dataset.seg===String(seg)){hit=p;break;}
  if(!hit&&sec){const rows=[...document.querySelectorAll('#transcript p[data-sec]')];hit=rows[0]||null;rows.forEach(r=>{if(Number(r.dataset.sec)<=sec+1)hit=r;});}
  if(!hit)return;
  hit.scrollIntoView({block:'center',behavior:'smooth'});
  hit.style.background='#fff8e1';setTimeout(()=>{hit.style.background='';},2000);
}
const askEditing=new Set();
// 改议题的决定状态：先在页面上换掉，再写回存档；没存上就退回原值并当场说一声。
// 写入口和「需要你定一下」是同一个（/meeting-answer），不另开第二个。
async function saveDecision(n,v){
  decEditing.delete(String(n));
  const b=record.brief,key=String(n),before=(b.decisions||{})[key];
  b.decisions={...(b.decisions||{}),[key]:v};
  render(record);
  try{const r=await fetch('/asr-relay/meeting-answer?token='+encodeURIComponent(settings.relayToken||''),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id,topic:n,decision:v})});if(!r.ok)throw 0;}
  catch(e){
    if(before===undefined)delete record.brief.decisions[key];else record.brief.decisions[key]=before;
    render(record);
    const head=document.querySelector('.bf-card[data-topic="'+n+'"] h3');
    if(head){const note=document.createElement('span');note.className='bf-tag bad';note.textContent=t('noSave');head.appendChild(note);}
  }
}
async function saveAnswer(qid,choice,text){
  askEditing.delete(qid);
  const b=record.brief;b.answers=b.answers||{};b.answers[qid]={choice,text:(text||'').trim(),at:Date.now()};
  render(record); // 先在页面上当场换掉，再存
  try{const r=await fetch('/asr-relay/meeting-answer?token='+encodeURIComponent(settings.relayToken||''),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id,qid,choice,text:(text||'').trim()})});if(!r.ok)throw 0;}
  catch(e){delete record.brief.answers[qid];render(record);const row=document.querySelector('.bf-qrow[data-q="'+qid+'"]');if(row){const n=document.createElement('span');n.className='bf-tag bad';n.textContent='没存上，Mac 在线后再点一次';row.appendChild(n);}}
}
// P-17：以前这里叫「整理成新版」走 /meeting-brief，往期会议列表那个「重新整理」走 /meeting-retry，
// 同一个诉求两个按钮做两件事。现在两边都调 /meeting-retry，由服务端按缺什么补什么
// （缺总结就整场重跑、然后补新版数据、收敛和会议记忆），进度合成一条 /meeting-refresh-state。
async function buildBrief(btn){
  btn.disabled=true;btn.textContent='重新整理中，约 3–8 分钟…';
  const tk=encodeURIComponent(settings.relayToken||'');
  const back=msg=>{btn.disabled=false;btn.textContent='重新整理';btn.title=msg||'';const n=document.createElement('span');n.className='bf-src';n.textContent=' '+(msg||'没整理出来');btn.after(n);setTimeout(()=>n.remove(),8000);};
  try{const r=await fetch('/asr-relay/meeting-retry?token='+tk,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({id})});
      if(!r.ok)return back(await r.text().catch(()=>'')||'Mac 没接上');}catch(e){return back('Mac 没接上');}
  const began=Date.now();let idle=0;
  const poll=async()=>{try{const r=await fetch('/asr-relay/meeting-refresh-state?id='+encodeURIComponent(id)+'&token='+tk,{cache:'no-store'});const j=await r.json();
      if(j.state==='done'){location.reload();return;} if(j.state==='failed'||j.state==='empty')return back(j.error);
      if(j.state==='none'&&++idle>=6)return back('没启动起来，再点一次');if(Date.now()-began>45*60000)return back('等太久了，稍后刷新看看');
      if(j.phase)btn.textContent=j.phase+'…';}catch(e){}
    setTimeout(poll,5000);};
  setTimeout(poll,4000);
}
// 顶部会议信息：日历时间、组织者、参会人并在一行；置信度低时同一行标出来，可换一场
async function mountHead(s){
  if(source!=='mac')return;const meta=$('#meta');const tk=encodeURIComponent(settings.relayToken||'');
  const paint=j=>{let el=document.getElementById('cal-line');if(!el){el=document.createElement('span');el.id='cal-line';el.style.cssText='display:flex;flex-wrap:wrap;gap:10px;align-items:center;flex-basis:100%';meta.appendChild(el);}
    const ev=j&&j.event;if(!ev){el.innerHTML='<span>日历：'+esc(j&&j.chosen==='none'?'你标了不是日历上的会':(j&&j.reason||'没对上日程'))+'</span>'+(j&&j.chosen==='none'?'<button type="button" class="btn sm" data-cal="reset">重新匹配</button>':'');}
    else{const low=ev.confidence==='low'&&!ev.chosenByUser;const who=ev.attendees||[];
      el.innerHTML='<span>日程 <b>'+esc(ev.title)+'</b> '+esc((ev.start||'').slice(11,16)+(ev.end?'–'+ev.end.slice(11,16):''))+'</span>'+(ev.organizer?'<span>组织者 <b>'+esc(ev.organizer)+'</b></span>':'')+(who.length?'<span>参会 <b>'+who.length+'</b> 人：'+esc(who.join('、'))+'</span>':'')
        +(low?'<span class="bf-tag bad">按时间猜的</span>':'')+((ev.candidates||[]).length>1?'<select data-cal="pick">'+ev.candidates.map(c=>'<option value="'+esc(c.eventId)+'"'+(c.eventId===ev.eventId?' selected':'')+'>'+esc(c.title)+' '+esc((c.start||'').slice(11,16))+'</option>').join('')+'</select>':'')
        +(low?'<button type="button" class="btn sm" data-cal="'+esc(ev.eventId)+'">就是这场</button>':'')+'<button type="button" class="btn sm" data-cal="none">不是日历上的会</button>';}
    el.querySelectorAll('[data-cal]').forEach(c=>{const send=async v=>{el.style.opacity=.6;const r=await fetch('/asr-relay/calendar-match?id='+encodeURIComponent(id)+(v==='reset'?'&refresh=1':'')+'&token='+tk,v==='reset'?{cache:'no-store'}:{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({eventId:v})});el.style.opacity=1;paint(await r.json());};
      if(c.tagName==='SELECT')c.onchange=()=>send(c.value);else c.onclick=()=>send(c.dataset.cal);});};
  try{const r=await fetch('/asr-relay/calendar-match?id='+encodeURIComponent(id)+'&token='+tk,{cache:'no-store',signal:AbortSignal.timeout(60000)});paint(await r.json());}catch(e){}
}

// 录音在 Mac 上。先 HEAD 一下，有才挂播放器，避免页面上出现一个点不动的控件。
// 这一场往长期记忆里留下了什么。点进去能看到那几条。
async function mountMemoryLink(){
  let el=document.getElementById('mem-link');
  try{
    const r=await fetch('/asr-relay/meeting-memory?id='+encodeURIComponent(id)+'&token='+encodeURIComponent(settings.relayToken||''),{cache:'no-store',signal:AbortSignal.timeout(6000)});
    const j=await r.json();
    if(!j.ok||!j.count){ if(el) el.hidden=true; return; }
    if(!el){ el=document.createElement('div'); el.id='mem-link'; el.className='cond-bar';
      (document.getElementById('cond-bar')||document.getElementById('player-box')).insertAdjacentElement('afterend', el); }
    el.hidden=false;
    const kinds={decision:'决定',promise:'承诺',question:'未决',term:'术语',name:'人名',rule:'习惯'};
    const by={}; for(const c of j.cards) by[c.kind]=(by[c.kind]||0)+1;
    const desc=Object.entries(by).map(([k,v])=>v+' 条'+(kinds[k]||k)).join('、');
    el.innerHTML='<span>这场留进长期记忆：'+desc+'，下一场相关时会被自动翻出来。</span>'
      +'<button type="button" id="mem-open">去会议记忆看</button>';
    document.getElementById('mem-open').onclick=()=>window.open('memory.html?meeting='+encodeURIComponent(id),'_blank','noopener');
  }catch(e){ if(el) el.hidden=true; }
}
function audioUrl(){return '/asr-relay/audio?id='+encodeURIComponent(id)+'&token='+encodeURIComponent(settings.relayToken||'');}
// 渲染之前先确认录音在不在：渲染时要靠 hasAudio 决定时间戳是不是可点的。
async function probeAudio(){
  hasAudio=false;
  if(source!=='mac')return;                       // 本机记录没有录音文件
  audioGone='';
  try{const r=await fetch(audioUrl(),{method:'HEAD',cache:'no-store',signal:AbortSignal.timeout(4000)});hasAudio=r.ok;if(!r.ok){audioGone=r.headers.get('X-Audio-Gone')||'';audioRetentionDays=Number(r.headers.get('X-Audio-Retention-Days'))||30;}}catch(e){hasAudio=false;}
}
function mountPlayer(){
  const host=$('#player-box'); if(!host)return;
  if(!hasAudio){
    if(audioGone==='retention'){host.hidden=false;host.innerHTML='<span class="ph">'+(uiLang==='en'?'Recording removed under the '+audioRetentionDays+'-day retention policy · transcript kept':'录音已按 '+audioRetentionDays+' 天保留期清理 · 文字记录仍在')+'</span>';return;}
    host.hidden=true;host.innerHTML='';return;
  }
  host.hidden=false;
  host.innerHTML='<span class="ph">'+(uiLang==='en'?'Replay this meeting · click any timestamp to jump there':'回听本场录音 · 点任意时间戳跳到那一刻')+'</span><audio id="player" controls preload="metadata" src="'+audioUrl().replace(/"/g,'&quot;')+'"></audio>';
}

// 工作台的会议待办点「回到原句」会带着 #t=<秒> 过来：渲染完直接跳过去，
// 展开逐字稿、高亮那一句；有录音时顺手把播放器也拨到那一刻。
function jumpFromHash(){const m=/(?:^|[#&])t=(\d+(?:\.\d+)?)/.exec(location.hash||'');if(m)jumpTo(Number(m[1]));}
window.addEventListener('hashchange',jumpFromHash);
(async()=>{
  if(!id){$('#title').textContent='缺少会议编号';return;}
  try{const s=await fromMac();source='mac';await probeAudio();render(s);loadSpeakers();loadActions();loadFocus();loadUpdates();jumpFromHash();}
  catch(e){const s=fromLocal();if(s){source='local';hasAudio=false;render(s);jumpFromHash();}else{$('#title').textContent=e.message==='401'?'请回到 Meeting LiveMate，在设置里连接 Mac 后重试。':'这场会议在 Mac 和本机都没找到（Mac 在线吗？）';}}
})();

// 下载和分享是同一件事，只留一个入口（顶栏这个）。统一走 /share-export：
// 有新版结构化总结的会，正文 = 编号议题 + 加粗结论 + 待办表（③ 点评不进分享）+ 逐字稿；老会议走收敛结果。
$('#download').onclick=openTake;

// 会后带走：下载和分享是同一件事的三个去处，共用同一份正文（纪要 + 逐字稿）。
// 分开做成三个按钮的话，三处各生成一遍，内容迟早对不上。
const tok=()=>encodeURIComponent(settings.relayToken||'');
async function openTake(){
  let d=document.getElementById('take-dlg');
  if(!d){
    d=document.createElement('dialog'); d.id='take-dlg'; d.className='take-dlg';
    d.innerHTML='<div class="take-head"><b>带走这一场</b><button type="button" data-x aria-label="关闭">×</button></div>'
      +'<p class="take-sub" id="take-sub">纪要 + 带说话人的逐字稿，一份 Markdown。</p>'
      +'<div class="take-row"><button type="button" class="p" id="take-dl">下载 Markdown</button></div>'
      +'<div class="take-row"><label for="take-lark">发到飞书</label>'
      +'<input id="take-q" placeholder="搜会话名，留空就发给我自己"><select id="take-lark"></select>'
      +'<button type="button" id="take-lark-go">发送</button></div>'
      +'<div class="take-row"><label>发到 Slack</label><span class="take-hint">发到你自己的 Slack 私聊</span>'
      +'<button type="button" id="take-slack-go">发送</button></div>'
      +'<p class="take-msg" id="take-msg" hidden></p>';
    document.body.appendChild(d);
    d.querySelector('[data-x]').onclick=()=>d.close();
    d.addEventListener('cancel',e=>{e.preventDefault();d.close();});
    d.addEventListener('click',e=>{if(e.target===d)d.close();});
    document.getElementById('take-dl').onclick=takeDownload;
    document.getElementById('take-q').oninput=debounceTargets();
    document.getElementById('take-lark-go').onclick=()=>takeSend('lark',{chatId:document.getElementById('take-lark').value});
    document.getElementById('take-slack-go').onclick=()=>takeSend('slack',{channel:'self'});
  }
  document.getElementById('take-msg').hidden=true;
  d.showModal();
  loadTargets('');
}
function debounceTargets(){ let t=null; return e=>{ clearTimeout(t); t=setTimeout(()=>loadTargets(e.target.value.trim()),400); }; }
async function loadTargets(q){
  const sel=document.getElementById('take-lark'); if(!sel) return;
  sel.innerHTML='<option value="self">发给我自己（飞书私聊）</option>';
  try{
    const r=await fetch('/asr-relay/share-targets?q='+encodeURIComponent(q)+'&token='+tok(),{cache:'no-store',signal:AbortSignal.timeout(25000)});
    const j=await r.json();
    if(!j.ok) return;
    sel.innerHTML=(j.lark||[]).map(x=>'<option value="'+esc(x.id)+'">'+esc(x.name)+'</option>').join('')
      || '<option value="self">发给我自己（飞书私聊）</option>';
  }catch(e){ /* 搜不到就只剩「发给自己」，不打断 */ }
}
function takeMsg(text, warn){ const m=document.getElementById('take-msg'); m.textContent=text; m.className='take-msg'+(warn?' warn':''); m.hidden=false; }
async function takeDownload(){
  takeMsg('正在整理…');
  try{
    const r=await fetch('/asr-relay/share-export?id='+encodeURIComponent(id)+'&token='+tok(),{cache:'no-store',signal:AbortSignal.timeout(30000)});
    const j=await r.json();
    if(!j.ok) return takeMsg(j.error||'导不出来', true);
    const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([j.markdown],{type:'text/markdown;charset=utf-8'}));
    a.download=j.filename; a.click(); setTimeout(()=>URL.revokeObjectURL(a.href),4000);
    takeMsg('已下载 '+j.filename+'（'+Math.round(j.bytes/1024)+' KB）');
  }catch(e){ takeMsg('导不出来：'+e.message, true); }
}
async function takeSend(target, extra){
  const btn=document.getElementById(target==='lark'?'take-lark-go':'take-slack-go');
  btn.disabled=true; takeMsg(target==='slack'?'正在发到 Slack，走连接器会慢几秒…':'正在发…');
  try{
    const r=await fetch('/asr-relay/share-send?token='+tok(),{method:'POST',headers:{'content-type':'application/json'},
      body:JSON.stringify({id,target,confirmed:true,...extra}),signal:AbortSignal.timeout(200000)});
    const j=await r.json();
    const where=target==='lark'?'飞书':'Slack';
    takeMsg(j.ok
      ? (j.attached===false ? '纪要发到'+where+'了；逐字稿没能当附件发（'+(j.why||'')+'），用上面的下载拿全文'
                            : '发出去了（'+where+'，纪要 + 逐字稿附件）')
      : (j.error||'没发出去'), !j.ok);
  }catch(e){ takeMsg('没发出去：'+e.message, true); }
  finally{ btn.disabled=false; }
}

// ===== 交给某人（Aaron 2026-09-24「give to Abel」）：一下 = 给他建飞书任务 + 私聊他 + 追加到行动清单文档并 @他 =====
// 名字从「补充：给 abel 决定」这类文字里猜一个默认值，发之前你还能改；发出只走 /person-handoff，那边有 confirmed 门禁和幂等。
const hoOpen=new Set(),hoNote=new Map(),hoPartial=new Map();let hoBusy=false;
function sessionIdOf(){try{return new URLSearchParams(location.search).get('id')||'';}catch{return '';}}
function hoGuess(text){const m=/给\s*([A-Za-z][A-Za-z .]{1,20}?)\s*(决定|定|做|跟|确认|看)/.exec(text||'')||/(?:give|hand|ask)\s+(?:to\s+)?([A-Z][a-z]+(?: [A-Z][a-z]+)?)/.exec(text||'');return m?m[1].trim():'';}
function hoBtn(id){return '<button type="button" class="bf-t" data-ho="'+esc(id)+'" title="'+T('建任务 + 私聊 + 行动清单 @他','Task + DM + action list @')+'">'+T('交给…','Hand to…')+'</button>';}
function hoForm(id,def){
  const note=hoNote.get(id)||'';
  if(!hoOpen.has(id))return note?'<div class="bf-act-state'+(/失败|没|✗/.test(note)?' bad':'')+'">'+note+'</div>':'';
  return '<div class="bf-ho" data-ho-form="'+esc(id)+'"><input type="text" maxlength="60" placeholder="'+T('给谁（名字）','Who (name)')+'" value="'+esc(def||'')+'">'
    +'<button type="button" class="bf-btn" data-ho-go="'+esc(id)+'"'+(hoBusy?' disabled':'')+'>'+(hoPartial.get(id)?T('补发失败的那几件','Retry failed items'):T('发出：任务 + 私聊 + 行动清单 @他','Send: task + DM + list @'))+'</button>'
    +'<button type="button" class="bf-btn ghost" data-ho-x="'+esc(id)+'">'+T('取消','Cancel')+'</button>'+(note?'<div class="bf-act-state">'+note+'</div>':'')+'</div>';
}
function wireHandoff(box,payloadOf,repaint){
  box.querySelectorAll('[data-ho]').forEach(b=>b.onclick=()=>{hoOpen.add(b.dataset.ho);repaint();});
  box.querySelectorAll('[data-ho-x]').forEach(b=>b.onclick=()=>{hoOpen.delete(b.dataset.hoX);repaint();});
  box.querySelectorAll('[data-ho-go]').forEach(b=>b.onclick=async()=>{
    const id=b.dataset.hoGo,form=b.closest('.bf-ho'),person=(form.querySelector('input').value||'').trim();
    if(!person){hoNote.set(id,T('先写给谁','Name someone first'));repaint();return;}
    hoBusy=true;hoNote.set(id,T('发出中…','Sending…'));repaint();
    try{
      const r=await fetch('/asr-relay/person-handoff?token='+actTok(),{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({...payloadOf(id),person,confirmed:true,sourceId:id,...(hoPartial.get(id)?{retryFailed:true,retryConfirmed:true}:{})}),signal:AbortSignal.timeout(90000)});
      const j=await r.json().catch(()=>({}));if(!r.ok||!j.ok)throw new Error(j.error||('HTTP '+r.status));
      const part=(k,l)=>j[k]&&j[k].ok?(j[k].url?'<a href="'+esc(j[k].url)+'" target="_blank" rel="noopener">'+l+' ✓</a>':l+' ✓'):l+' ✗'+(j[k]&&j[k].error?' '+esc(j[k].error):'');
      hoPartial.set(id,!!j.partial);hoNote.set(id,(j.partial?T('只成了一部分，失败：','Partly sent, failed: ')+esc((j.failed||[]).join('、'))+'；':'')+(j.fallbackToAaron?T('没找到这个人，先建给你：','Person not found, sent to you: '):T('已交给 ','Handed to ')+esc((j.assignee&&j.assignee.name)||person)+'：')
        +part('task',T('任务','Task'))+' · '+part('message',T('私聊','DM'))+' · '+part('doc',T('行动清单','Action list')));
      hoOpen.delete(id);
    }catch(e){hoNote.set(id,T('没发出去：','Failed: ')+esc(e.message||String(e)));}
    hoBusy=false;repaint();
  });
}
