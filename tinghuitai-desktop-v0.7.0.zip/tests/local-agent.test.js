'use strict';
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs'), os = require('os'), path = require('path');
const agent = require('../app/local-agent');

test('本机 Agent：任意模型只提结构化动作，UI 确认后才由统一工具层执行', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'local-agent-'));
  const planned = await agent.plan({}, {
    instruction: '约明天的评审会', dataDir: dir,
    askWithTools: async (_env, opts) => {
      assert.ok(opts.tools.includes('meetings.search'));
      assert.match(opts.system, /写动作由听会台在用户确认后执行/);
      return { ok: true, text: JSON.stringify({ reply: '要现在建日历吗？', action: { name: 'lark.calendar.create', args: {
        title: '评审会', start: '2026-10-01T10:00:00+08:00', end: '2026-10-01T11:00:00+08:00', attendees: []
      } } }), provider: 'fake', usage: { input: 10, output: 5, calls: 1 } };
    }
  });
  assert.equal(planned.ok, true); assert.equal(planned.proposal.name, 'lark.calendar.create');
  let seen, calls = 0;
  const done = await agent.execute({}, planned.proposal, { dataDir: dir, callTool: async (name, args, ctx) => {
    calls++; seen = { name, args, ctx }; return { ok: true, data: { url: 'https://calendar.test/e/1' } };
  }, actionKey: 'test-action-1' });
  assert.equal(seen.ctx.confirmedByUser, true); assert.equal(seen.ctx.caller, 'ui');
  assert.match(done.text, /已完成.*https:\/\/calendar\.test/);
  const again = await agent.execute({}, planned.proposal, { dataDir: dir, callTool: async () => { calls++; return { ok: true }; }, actionKey: 'test-action-1' });
  assert.equal(again.ok, true); assert.equal(calls, 1, '相同动作 id 只执行一次');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('本机 Agent：没有服务端动作 id 不执行；结果不确定时默认禁止重发', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'local-agent-gate-'));
  const proposal = { name: 'slack.message.send', args: { channel: 'C1', text: 'hello' } };
  let calls = 0;
  assert.equal((await agent.execute({}, proposal, { dataDir: dir, callTool: async () => { calls++; return { ok: true }; } })).reason, 'missing_action_key');
  const first = await agent.execute({}, proposal, { dataDir: dir, actionKey: 'uncertain-1', callTool: async () => { calls++; return { ok: false, error: 'timeout', uncertain: true }; } });
  assert.equal(first.reason, 'send_uncertain');
  const second = await agent.execute({}, proposal, { dataDir: dir, actionKey: 'uncertain-1', callTool: async () => { calls++; return { ok: true }; } });
  assert.equal(second.reason, 'send_uncertain'); assert.equal(calls, 1, '没有再次确认就不重发');
  fs.rmSync(dir, { recursive: true, force: true });
});

test('本机 Agent：模型伪造清单外写工具会被丢弃', async () => {
  const r = await agent.plan({}, { instruction: '删文档', askWithTools: async () => ({ ok: true,
    text: '{"reply":"不能执行","action":{"name":"shell.exec","args":{"cmd":"rm -rf /"}}}' }) });
  assert.equal(r.ok, true); assert.equal(r.proposal, null); assert.equal(r.text, '不能执行');
});
