'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
// Exercise the actual renderer with a minimal DOM, not a second Markdown implementation.
class Node {
 constructor(tag,text=''){this.tagName=tag.toUpperCase();this.children=[];this.dataset={};this.attributes={};this.value=text;this.classList={toggle(){}};}
 set textContent(v){this.value=String(v);this.children=[];}get textContent(){return this.value+this.children.map(n=>n.textContent).join('');}
 append(...nodes){this.children.push(...nodes);}setAttribute(k,v){this.attributes[k]=v;}
}
function render(body){const source=fs.readFileSync(path.join(__dirname,'../web/meeting-board-ui.js'),'utf8'),ctx={document:{createElement:tag=>new Node(tag),createTextNode:text=>new Node('#text',text)},tr:zh=>zh,choose(){}};vm.createContext(ctx);vm.runInContext("const el=(tag,value='',cls='')=>{const n=document.createElement(tag);n.textContent=value;n.className=cls;return n;};"+source.slice(source.indexOf('function inline('),source.indexOf('function assistant('))+';this.render=markdown;',ctx);return ctx.render(body,'module');}
function all(root){return [root,...root.children.flatMap(all)];}
test('meeting canvas treats model HTML and unsafe Markdown links as inert text',()=>{const payload='<img src=x onerror=alert(1)> <script>alert(2)</script> [bad](javascript:alert(3)) [safe](https://example.com/)';const nodes=all(render(payload));assert(nodes.every(n=>!['IMG','SCRIPT','IFRAME'].includes(n.tagName)));const links=nodes.filter(n=>n.tagName==='A');assert.equal(links.length,1);assert.equal(links[0].href,'https://example.com/');assert.equal(links[0].rel,'noopener noreferrer');assert(nodes[0].textContent.includes('<script>'));});
test('inline comments preserve raw offsets through nested bullets and tables',()=>{const body='## Choices\n- **One** item\n\n| A | B |\n|---|---|\n| keep | edit |';const nodes=all(render(body)),editable=nodes.filter(n=>n.dataset.original);assert(editable.length>=4);for(const n of editable){assert.equal(body.slice(Number(n.dataset.start),Number(n.dataset.end)),n.dataset.original);}assert(nodes.some(n=>n.tagName==='TABLE'));assert(nodes.some(n=>n.tagName==='STRONG'));});
