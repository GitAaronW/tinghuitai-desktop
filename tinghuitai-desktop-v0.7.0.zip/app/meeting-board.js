'use strict';
const crypto=require('crypto');
const KINDS=['summary','plan','task','map','note','insight'];
function validate(board){
 if(!board||typeof board!=='object'||!Array.isArray(board.modules)||board.modules.length>120)throw Error('invalid board');
 const seen=new Set();const modules=board.modules.map(m=>{
  if(!m||typeof m.id!=='string'||!/^[\w-]{1,80}$/.test(m.id)||seen.has(m.id))throw Error('invalid module id');seen.add(m.id);
  if(!KINDS.includes(m.kind)||typeof m.title!=='string'||m.title.length>200||typeof m.body!=='string'||m.body.length>40000||typeof m.edited!=='boolean')throw Error('invalid module');
  if(!Array.isArray(m.sourceRefs)||m.sourceRefs.length>100||m.sourceRefs.some(x=>typeof x!=='string'||x.length>160))throw Error('invalid references');
  const views=['document','timeline','checklist','diagram','comparison'];
  const view=views.includes(m.view)?m.view:undefined;
  return {id:m.id,kind:m.kind,title:m.title,body:m.body,edited:m.edited,sourceRefs:m.sourceRefs.slice(),...(view?{view}:{}),...(typeof m.topic==='string'&&m.topic.length<=120?{topic:m.topic}:{}),...(typeof m.context==='string'&&m.context.length<=1000?{context:m.context}:{}),...(Array.isArray(m.nodes)&&m.nodes.length<=30&&m.nodes.every(n=>n&&typeof n.label==='string'&&n.label.length<=240&&(!n.detail||typeof n.detail==='string'&&n.detail.length<=1000))?{nodes:m.nodes.map(n=>({label:n.label,detail:n.detail||''}))}:{})};
 });return {version:1,modules,...(typeof board.goal==='string'&&board.goal.length<=600?{goal:board.goal}:{}),cursor:Math.max(0,Number.isSafeInteger(board.cursor)?board.cursor:0),updated:new Date().toISOString(),...(board.cloud&&typeof board.cloud.url==='string'&&(()=>{try{const u=new URL(board.cloud.url);return u.protocol==='https:'&&/(^|\.)(larksuite\.com|feishu\.cn)$/.test(u.hostname);}catch{return false;}})()?{cloud:{url:board.cloud.url,verified:board.cloud.verified===true}}:{})};
}
function merge(board, incoming, refs){
 const old=validate(board||{modules:[]}),known=new Set(refs),seen=new Set();
 if(!Array.isArray(incoming)||incoming.length>50)throw Error('invalid model output');
 for(const raw of incoming){
  const prior=old.modules.find(m=>m.id===raw.id);if(prior?.edited)continue;
  const m={...raw,id:prior?prior.id:crypto.randomUUID(),edited:false,sourceRefs:(raw.sourceRefs||[]).filter(x=>known.has(x))};
  if(prior){if(seen.has(prior.id))throw Error('duplicate patch');seen.add(prior.id);Object.assign(prior,m);}else old.modules.push(m);
 }return validate(old);
}
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
function exportBoard(board,title,format){
 board=validate(board);const md='# '+title+'\n\n'+board.modules.map(m=>'## '+m.title+'\n\n'+m.body).join('\n\n');
 if(format==='html')return '<!doctype html><html><head><meta charset="utf-8"><title>'+esc(title)+'</title></head><body><h1>'+esc(title)+'</h1>'+board.modules.map(m=>'<h2>'+esc(m.title)+'</h2><pre>'+esc(m.body)+'</pre>').join('')+'</body></html>';
 if(format==='opml')return '<?xml version="1.0" encoding="UTF-8"?><opml version="2.0"><head><title>'+esc(title)+'</title></head><body><outline text="'+esc(title)+'">'+board.modules.map(m=>'<outline text="'+esc(m.title)+'">'+m.body.split('\n').filter(Boolean).map(t=>'<outline text="'+esc(t)+'"/>').join('')+'</outline>').join('')+'</outline></body></opml>';
 return md;
}
module.exports={validate,merge,exportBoard,KINDS};
