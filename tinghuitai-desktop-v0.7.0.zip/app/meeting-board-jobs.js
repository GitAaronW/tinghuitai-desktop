'use strict';
// Durable local task journal. Model work may run concurrently across meetings;
// changes within one meeting are serialized so each task sees the saved result.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const stores=new Map();
class Jobs {
 constructor(dir){this.file=path.join(dir,'meeting-board-jobs.json');this.items=[];this.tails=new Map();try{const j=JSON.parse(fs.readFileSync(this.file,'utf8'));if(Array.isArray(j))this.items=j;}catch(e){if(e.code!=='ENOENT')throw e;}let dirty=false;for(const j of this.items){if(['queued','running'].includes(j.state)){j.state='interrupted';j.error='服务已重启，任务未完成，请重试 / Service restarted; retry the unfinished task';j.finished=new Date().toISOString();dirty=true;}}if(dirty)this.save();}
 save(){fs.mkdirSync(path.dirname(this.file),{recursive:true});const tmp=this.file+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(tmp,JSON.stringify(this.items),{mode:0o600});fs.renameSync(tmp,this.file);}finally{try{fs.unlinkSync(tmp);}catch{}}}
 list(id){return this.items.filter(j=>j.meetingId===id).slice(-80).map(({request,...j})=>j);}
 enqueue(id,request,run){const duplicate=request.requestId&&this.items.find(j=>j.meetingId===id&&j.request?.requestId===request.requestId);if(duplicate)return this.list(id).find(j=>j.id===duplicate.id);if(this.items.filter(j=>['queued','running'].includes(j.state)).length>=20){const e=Error('任务队列已满，请稍后再试 / Task queue full');e.status=429;throw e;}
 const job={id:crypto.randomUUID(),meetingId:id,state:'queued',action:request.action,moduleId:request.moduleId||'',comment:request.comment||'',quote:request.selection?.original||'',lang:request.lang==='en'?'en':'zh',created:new Date().toISOString(),request};const oldItems=this.items.slice();this.items.push(job);if(this.items.length>1000)this.items=this.items.filter(j=>['queued','running'].includes(j.state)).concat(this.items.filter(j=>!['queued','running'].includes(j.state)).slice(-900));try{this.save();}catch(e){this.items=oldItems;throw e;}
 const previous=this.tails.get(id)||Promise.resolve();const work=previous.catch(()=>{}).then(async()=>{job.state='running';job.started=new Date().toISOString();try{this.save();const result=await run(request);job.state='completed';job.reply=result.reply||'已保存到本场工作台 / Saved to this workspace';job.resultRevision=result.source?.revision;job.resultIds=result.resultIds||[];}catch(e){job.state='failed';job.error=e.message;}finally{job.finished=new Date().toISOString();this.save();}});this.tails.set(id,work);work.catch(()=>{}).finally(()=>{if(this.tails.get(id)===work)this.tails.delete(id);});return this.list(id).find(j=>j.id===job.id);
 }
}
function get(dir){const key=path.resolve(dir);if(!stores.has(key))stores.set(key,new Jobs(key));return stores.get(key);}
module.exports={get,Jobs};
