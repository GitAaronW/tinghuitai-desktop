document.getElementById('b-meeting-board')?.addEventListener('click',()=>{const q=new URLSearchParams();if(cur?.id)q.set('id',cur.id);window.open('meeting-board.html?'+q,'_blank','noopener');});
