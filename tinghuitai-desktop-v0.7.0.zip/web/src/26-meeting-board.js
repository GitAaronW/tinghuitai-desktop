document.getElementById('b-meeting-board')?.addEventListener('click',()=>{const q=new URLSearchParams();if(cur?.id)q.set('id',cur.id);window.open('meeting-board.html?'+q,'_blank','noopener');});

// Reuse the existing application controls without creating another settings store.
if (new URLSearchParams(location.search).has('boardPanel')) {
  const controls = {settings:'gear2',history:'b-hist',update:'m-update'};
  const mode = new URLSearchParams(location.search).get('boardPanel');
  window.addEventListener('load',()=>document.getElementById(controls[mode])?.click(),{once:true});
}
