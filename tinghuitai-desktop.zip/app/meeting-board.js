'use strict';
const crypto=require('crypto');
const KINDS=['summary','plan','task','map','note','insight'];
function validate(board){
 if(!board||typeof board!=='object'||!Array.isArray(board.modules)||board.modules.length>120)throw Error('invalid board');
 const seen=new Set();const modules=board.modules.map(m=>{
  if(!m||typeof m.id!=='string'||!/^[\w-]{1,80}$/.test(m.id)||seen.has(m.id))throw Error('invalid module id');seen.add(m.id);
  if(!KINDS.includes(m.kind)||typeof m.title!=='string'||m.title.length>200||typeof m.body!=='string'||m.body.length>40000||typeof m.edited!=='boolean')throw Error('invalid module');
  if(!Array.isArray(m.sourceRefs)||m.sourceRefs.length>100||m.sourceRefs.some(x=>typeof x!=='string'||x.length>160))throw Error('invalid references');
  const views=['document','timeline','checklist','diagram','comparison'];
  const view=views.includes(m.view)?m.view:undefined;
  return {id:m.id,kind:m.kind,title:m.title,body:m.body,edited:m.edited,sourceRefs:m.sourceRefs.slice(),...(m.origin&&['sourceId','moduleId','sessionId','title'].every(k=>typeof m.origin[k]==='string'&&m.origin[k].length<=200)?{origin:{sourceId:m.origin.sourceId,moduleId:m.origin.moduleId,sessionId:m.origin.sessionId,title:m.origin.title}}:{}),...(view?{view}:{}),...(typeof m.topic==='string'&&m.topic.length<=120?{topic:m.topic}:{}),...(typeof m.context==='string'&&m.context.length<=1000?{context:m.context}:{}),...(Array.isArray(m.nodes)&&m.nodes.length<=30&&m.nodes.every(n=>n&&typeof n.label==='string'&&n.label.length<=240&&(!n.detail||typeof n.detail==='string'&&n.detail.length<=1000))?{nodes:m.nodes.map(n=>({label:n.label,detail:n.detail||''}))}:{})};
 });return {version:1,modules,...(typeof board.goal==='string'&&board.goal.length<=600?{goal:board.goal}:{}),cursor:Math.max(0,Number.isSafeInteger(board.cursor)?board.cursor:0),updated:new Date().toISOString(),...(board.cloud&&typeof board.cloud.url==='string'&&(()=>{try{const u=new URL(board.cloud.url);return u.protocol==='https:'&&/(^|\.)(larksuite\.com|feishu\.cn)$/.test(u.hostname);}catch{return false;}})()?{cloud:{url:board.cloud.url,verified:board.cloud.verified===true}}:{})};
}
function merge(board, incoming, refs){
 const old=validate(board||{modules:[]}),known=new Set(refs),seen=new Set();
 if(!Array.isArray(incoming)||incoming.length>50)throw Error('invalid model output');
 for(const raw of incoming){
  const prior=old.modules.find(m=>m.id===raw.id);if(prior?.edited)continue;
  const m={...raw,id:prior?prior.id:crypto.randomUUID(),edited:false,sourceRefs:(raw.sourceRefs||[]).filter(x=>known.has(x))};
  if(prior?.origin)m.origin=prior.origin;else delete m.origin;
  if(prior){if(seen.has(prior.id))throw Error('duplicate patch');seen.add(prior.id);Object.assign(prior,m);}else old.modules.push(m);
 }return validate(old);
}
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
function inline(s){return esc(s).replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code>$1</code>').replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,(_,label,url)=>'<a rel="noreferrer" href="'+url+'">'+label+'</a>');}
function documentBody(body){
 const out=[];let list=false,table=false;
 const close=()=>{if(list){out.push('</ul>');list=false;}if(table){out.push('</tbody></table></div>');table=false;}};
 for(const line of String(body).split('\n')){
  if(!line.trim()){close();continue;}
  if(/^\s*\|/.test(line)){if(list){out.push('</ul>');list=false;}const cells=line.trim().replace(/^\||\|$/g,'').split('|');if(cells.every(c=>/^\s*:?-+:?\s*$/.test(c)))continue;if(!table){out.push('<div class="table-scroll"><table><tbody>');table=true;}out.push('<tr>'+cells.map(c=>'<td>'+inline(c.trim())+'</td>').join('')+'</tr>');continue;}
  if(table){out.push('</tbody></table></div>');table=false;}
  const bullet=line.match(/^\s*(?:[-*]|\d+[.)])\s+(.+)/);if(bullet){if(!list){out.push('<ul>');list=true;}out.push('<li>'+inline(bullet[1])+'</li>');continue;}
  if(list){out.push('</ul>');list=false;}
  const heading=line.match(/^#{1,6}\s+(.+)/);out.push(heading?'<h3>'+inline(heading[1])+'</h3>':'<p>'+inline(line)+'</p>');
 }close();return out.join('');
}
function exportBoard(board,title,format){
 board=validate(board);const md='# '+title+'\n\n'+(board.goal?board.goal+'\n\n':'')+board.modules.map(m=>'## '+m.title+'\n\n'+m.body).join('\n\n');
 if(format==='html')return '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+esc(title)+'</title><style>body{margin:0;background:#f7f7f8;color:#222;font:16px/1.8 system-ui,"PingFang SC",sans-serif}main{max-width:920px;margin:40px auto;padding:0 24px}h1{font-size:32px;line-height:1.4}h2{font-size:23px;margin:0 0 20px}h3{font-size:18px;margin:24px 0 10px}section{background:white;border:1px solid #e5e5e7;border-radius:20px;padding:32px;margin:24px 0}.goal{color:#666}li{margin:8px 0}a{color:#C8102E}.table-scroll{overflow:auto}table{width:100%;border-collapse:collapse}td{border-bottom:1px solid #eee;padding:12px;vertical-align:top}code{background:#f4f4f5;padding:2px 4px;border-radius:4px}@media print{body{background:white}main{margin:0;max-width:none}section{border:0;padding:12px 0;break-inside:avoid}}</style></head><body><main><h1>'+esc(title)+'</h1>'+(board.goal?'<p class="goal">'+esc(board.goal)+'</p>':'')+board.modules.map(m=>'<section><h2>'+esc(m.title)+'</h2>'+documentBody(m.body)+'</section>').join('')+'</main></body></html>';
 if(format==='opml')return '<?xml version="1.0" encoding="UTF-8"?><opml version="2.0"><head><title>'+esc(title)+'</title></head><body><outline text="'+esc(title)+'">'+board.modules.map(m=>'<outline text="'+esc(m.title)+'">'+m.body.split('\n').filter(Boolean).map(t=>'<outline text="'+esc(t)+'"/>').join('')+'</outline>').join('')+'</outline></body></opml>';
 return md;
}
module.exports={validate,merge,exportBoard,KINDS};
