'use strict';
// Board-specific proposal binding. Actual writes stay in local-agent/tools.
const {proposalOf}=require('./local-agent'),{hash}=require('./send-gate');
const SIGN='— 由 Codex 代 Aaron Wang 发送。';
function fingerprint(source,moduleId){const m=source?.board?.modules.find(m=>m.id===moduleId);return hash([source?.projectManual?source.projectId||'':'',moduleId?m||null:source?.board||{modules:[]}]);}
function seal(proposal){
 const p=proposalOf({action:proposal});if(!p)throw Error('动作参数无效 / Invalid action parameters');
 if(['lark.message.send','slack.message.send'].includes(p.name)){
  if(!p.args.text.endsWith(SIGN))p.args.text+='\n\n'+SIGN;
  const checked=proposalOf({action:p});if(!checked)throw Error('消息加署名后过长，请缩短 / Shorten the message to include its signature');return checked;
 }
 return p;
}
function safeUrl(value){try{const u=new URL(value);return ['https:','http:'].includes(u.protocol)&&!u.username&&!u.password?u.href:'';}catch{return '';}}
function result(out,lang='zh'){
 const d=out?.result?.data||{},url=safeUrl(d.url);
 const ok=out?.ok===true&&out?.result?.ok===true&&out?.receipt?.status==='sent';
 return {ok,uncertain:!!out?.uncertain||!!(out?.ok&&!ok),error:out?.error||out?.reason||'',
  text:ok?(lang==='en'?'Action completed':'已执行'):out?.text||(lang==='en'?'Check the destination; no successful receipt was received':'未收到成功回执，请核对对方记录'),url:ok?url:'',note:typeof d.note==='string'?d.note.slice(0,2000):''};
}
module.exports={fingerprint,seal,safeUrl,result,SIGN};
