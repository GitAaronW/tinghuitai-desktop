'use strict';
// Notion 读类工具。按官方 API 实现：POST /v1/search、GET /v1/blocks/{id}/children，都要 Notion-Version 头。
// 设置项 NOTION_TOKEN 有值才可用；没有就在清单里照样列出来，reason 写明缺什么。
// ⚠️ 2026-09-22 交付时只用假服务端测过，没连过真的 Notion（本机设置里没有 NOTION_TOKEN）。
const reg = require('./index');

const API = 'https://api.notion.com/v1/';
const VERSION = '2022-06-28';
const clip = (s, n) => String(s == null ? '' : s).slice(0, n);
const tokenOf = env => String((env || {}).NOTION_TOKEN || '').trim();

// Notion 的文字都摊在 rich_text 数组里，标题还分 title / Name 两种属性名，统一在这里抽。
function plain(rich) { return (Array.isArray(rich) ? rich : []).map(x => String((x && x.plain_text) || '')).join(''); }
function titleOf(page) {
  const props = (page && page.properties) || {};
  for (const v of Object.values(props)) if (v && v.type === 'title') return plain(v.title);
  if (page && page.title) return plain(page.title);
  return '';
}
function blockText(b) {
  const t = b && b.type;
  const body = t && b[t];
  if (!body) return '';
  if (Array.isArray(body.rich_text)) return plain(body.rich_text);
  if (typeof body.title === 'string') return body.title;
  return '';
}
async function api(ctx, method, endpoint, body) {
  const token = tokenOf(ctx.env);
  if (!token) return { ok: false, error: '设置里没有 NOTION_TOKEN' };
  const f = ctx.fetchImpl || globalThis.fetch;
  if (typeof f !== 'function') return { ok: false, error: '这个 Node 没有 fetch' };
  try {
    const r = await f((ctx.notionBase || API) + endpoint, {
      method, headers: { Authorization: 'Bearer ' + token, 'Notion-Version': VERSION, 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(20000),
    });
    const j = await r.json();
    if (j && j.object === 'error') return { ok: false, error: 'Notion 拒绝了：' + clip(j.message || j.code || '', 120) };
    if (!r.ok) return { ok: false, error: 'Notion 请求失败：HTTP ' + r.status };
    return { ok: true, json: j };
  } catch (e) { return { ok: false, error: 'Notion 连不上：' + clip(e.message, 100) }; }
}
async function children(ctx, id, left, depth = 0) {
  if (left <= 0 || depth > 5) return { ok: true, lines: [], blocks: 0, truncated: left <= 0 };
  let cursor = '', lines = [], blocks = 0, truncated = false;
  do {
    const endpoint = 'blocks/' + encodeURIComponent(id) + '/children?page_size=' + Math.min(100, left) + (cursor ? '&start_cursor=' + encodeURIComponent(cursor) : '');
    const r = await api(ctx, 'GET', endpoint); if (!r.ok) return r;
    const rows = ((r.json || {}).results) || [];
    for (const b of rows) {
      if (blocks >= left) { truncated = true; break; }
      blocks++; const text = blockText(b); if (text) lines.push(text);
      if (b.has_children && blocks < left) {
        const sub = await children(ctx, b.id, left - blocks, depth + 1); if (!sub.ok) return sub;
        blocks += sub.blocks; lines.push(...sub.lines); truncated = truncated || sub.truncated;
      }
    }
    cursor = (r.json || {}).has_more && blocks < left ? String((r.json || {}).next_cursor || '') : '';
    if ((r.json || {}).has_more && !cursor) truncated = true;
  } while (cursor && blocks < left);
  return { ok: true, lines, blocks, truncated };
}
// 云端资料库也走这一层，避免它另写一套 Notion URL、鉴权和超时规则。
// 返回每页的正文快照；单页失败只计错，不拦住其余已授权页面。
async function crawlPages(ctx, { pageLimit = 500, blockLimit = 200 } = {}) {
  let cursor = '', seen = 0, errors = 0;
  const items = [];
  do {
    const request = { page_size: Math.min(100, pageLimit - seen), filter: { property: 'object', value: 'page' }, sort: { direction: 'descending', timestamp: 'last_edited_time' } };
    if (cursor) request.start_cursor = cursor;
    const found = await api(ctx, 'POST', 'search', request);
    if (!found.ok) return { ok: false, error: found.error, items, pages: seen, errors: errors + 1 };
    const rows = ((found.json || {}).results) || [];
    for (const page of rows) {
      if (seen >= pageLimit) break;
      seen++;
      const body = await children(ctx, page.id, blockLimit);
      if (!body.ok) { errors++; continue; }
      items.push({ id: page.id || '', title: clip(titleOf(page) || '（无标题）', 200), url: page.url || '', at: page.last_edited_time || page.created_time || '', text: clip(body.lines.join('\n'), 300000) });
    }
    cursor = (found.json || {}).has_more && seen < pageLimit ? String((found.json || {}).next_cursor || '') : '';
  } while (cursor && seen < pageLimit);
  return { ok: true, items, pages: seen, errors };
}
const unavailable = env => (tokenOf(env) ? { ok: true } : { ok: false, reason: '未接：设置里没有 NOTION_TOKEN（填了就自动可用）' });

reg.register({
  name: 'notion.search', title: '搜 Notion', level: 'read', source: 'notion',
  description: '搜这份 Notion 授权能看到的页面和数据库，返回标题、id 和链接。要正文用 notion.fetch。',
  input: { type: 'object', required: ['query'], properties: {
    query: { type: 'string', minLength: 1, maxLength: 200 },
    limit: { type: 'integer', minimum: 1, maximum: 20, default: 8 },
  } },
  available: unavailable,
  async run(args, ctx) {
    const r = await api(ctx, 'POST', 'search', { query: args.query, page_size: Math.min(20, args.limit || 8) });
    if (!r.ok) return r;
    const results = ((r.json || {}).results) || [];
    return { ok: true, items: results.slice(0, args.limit).map(p => ({
      title: clip(titleOf(p) || '（无标题）', 200), text: clip(titleOf(p), 200),
      objectType: p.object || '', id: p.id || '', url: p.url || '',
      ref: 'notion:' + (p.id || ''), source: 'notion:search', at: p.last_edited_time || p.created_time || '',
    })) };
  },
});

reg.register({
  name: 'notion.fetch', title: '取 Notion 页面内容', level: 'read', source: 'notion',
  description: '按页面 id 取真实标题和递归块正文（纯文字）。id 从 notion.search 的结果里拿。',
  input: { type: 'object', required: ['id'], properties: {
    id: { type: 'string', minLength: 8, maxLength: 80, description: '页面或块 id' },
    limit: { type: 'integer', minimum: 1, maximum: 100, default: 50 },
  } },
  available: unavailable,
  async run(args, ctx) {
    const id = String(args.id).trim();
    if (!/^[0-9a-fA-F-]{8,80}$/.test(id)) return { ok: false, error: 'id 不像 Notion 的页面 id' };
    const [page, body] = await Promise.all([api(ctx, 'GET', 'pages/' + encodeURIComponent(id)), children(ctx, id, Math.min(100, args.limit || 50))]);
    if (!body.ok) return body;
    if (!body.lines.length) return { ok: false, error: '这一页没读到文字内容（可能是数据库页，或授权没分享到这一页）' };
    return { ok: true, data: { title: page.ok ? clip(titleOf(page.json) || '（无标题）', 200) : '（标题读不到）', text: clip(body.lines.join('\n'), 12000), blocks: body.blocks, truncated: body.truncated,
      url: page.ok ? page.json.url || '' : '', ref: 'notion:' + id, source: 'notion:blocks', at: page.ok ? page.json.last_edited_time || '' : '' } };
  },
});

module.exports = { plain, titleOf, blockText, children, crawlPages };
