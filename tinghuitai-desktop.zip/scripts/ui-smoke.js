'use strict';
// 界面冒烟：把「每个入口都点一遍，看它开得起来、也关得掉」这件事自动化。
// 起因：2026-09-11/12 连着三次是同一类问题——功能还在，界面上点不到，或者打开了关不掉。
// 这些都不是逻辑错，单元测试一条都拦不住，只能真的打开页面点一遍。
// 用法：node scripts/ui-smoke.js   （自己起隔离实例、自己开无头 Chrome、自己收摊）
const {spawn,execFileSync}=require('child_process'), fs=require('fs'), os=require('os'), path=require('path'), WebSocket=require('ws');
const CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const PORT=Number(process.env.SMOKE_PORT||47871), CDP=Number(process.env.SMOKE_CDP||47872);
const DATA=fs.mkdtempSync(path.join(os.tmpdir(),'tht-smoke-')), PROFILE=path.join(DATA,'chrome');
const SHOTS=path.join(DATA,'shots'); fs.mkdirSync(SHOTS,{recursive:true});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let server, chrome, ws, id=0, pending=new Map();

function send(method,params={}){ const i=++id; ws.send(JSON.stringify({id:i,method,params}));
  return new Promise((res,rej)=>{ const timer=setTimeout(()=>{pending.delete(i);rej(new Error(method+' 超时'));},30000);pending.set(i,{res,rej,timer}); }); }
async function evaluate(expr){
  const r=await send('Runtime.evaluate',{expression:`(async()=>{${expr}})()`,awaitPromise:true,returnByValue:true});
  if (r.exceptionDetails) throw new Error((r.exceptionDetails.exception?.description||'页面里报错了')+' · '+expr.slice(0,180));
  return r.result.value;
}
async function shot(name){ const r=await send('Page.captureScreenshot',{}); fs.writeFileSync(path.join(SHOTS,name+'.png'), Buffer.from(r.data,'base64')); }

(async ()=>{
  const fails=[]; const ok=m=>console.log('  ✅ '+m); const bad=m=>{ fails.push(m); console.log('  ❌ '+m); };
  try{
    if(process.env.SMOKE_WORKSPACE){
      const previous=new Date();previous.setDate(previous.getDate()-1);previous.setHours(21,0,0,0);
      const {Hub}=require('../app/work-hub'),hub=new Hub(DATA,path.join(DATA,'state','work-hub'));
      fs.mkdirSync(path.join(DATA,'pending'),{recursive:true});
      for(const [id,title] of [['offline-smoke-evening','昨晚的产品讨论'],['offline-smoke-other','另一场会议']]){
        const session={id,title,start:previous.getTime(),end:previous.getTime()+3600000,transcript:[{segId:'s1',text:'Carl 的时间没有约定。',t:30}],summary:'## 尚未约定\nCarl 的时间没有约定。',todos:[],highlights:[]};
        fs.writeFileSync(path.join(DATA,'pending',id+'.json'),JSON.stringify(session));hub.ingestSession(session);
      }hub.save();
    }
    console.log('起隔离实例 …');
    server=spawn(process.execPath,[path.join(__dirname,'../app/server.js')],
      {env:{...process.env,THT_DATA_DIR:DATA,THT_PORT:String(PORT),THT_NO_OPEN:'1'},stdio:'ignore'});
    for(let i=0;i<40;i++){ try{ const r=await fetch(`http://127.0.0.1:${PORT}/health`); if(r.ok) break; }catch{} await sleep(250); }

    console.log('起无头 Chrome …');
    chrome=spawn(CHROME,['--headless=new',`--remote-debugging-port=${CDP}`,`--user-data-dir=${PROFILE}`,
      '--no-first-run','--window-size=1440,900','--disable-gpu','about:blank'],{stdio:'ignore'});
    let target=null;
    for(let i=0;i<40 && !target;i++){ await sleep(300);
      try{ const j=await (await fetch(`http://127.0.0.1:${CDP}/json/list`)).json(); target=j.find(t=>t.type==='page'); }catch{} }
    if(!target) throw new Error('连不上无头 Chrome');
    ws=new WebSocket(target.webSocketDebuggerUrl,{maxPayload:64*1024*1024});
    await new Promise(r=>ws.on('open',r));
    ws.on('message',d=>{ const m=JSON.parse(d); if(m.id&&pending.has(m.id)){ const p=pending.get(m.id); pending.delete(m.id);clearTimeout(p.timer);
      m.error?p.rej(new Error(m.error.message)):p.res(m.result); } });
    await send('Page.enable'); await send('Runtime.enable');

    if(process.env.SMOKE_SETUP){
      await send('Page.navigate',{url:`http://127.0.0.1:${PORT}/tinghuitai/setup.html`});
      await sleep(2500);
      await evaluate(`document.querySelector('[data-l=en]').click(); document.querySelector('input[value=deepgram]').checked=true; paintAsr(); form.elements.DEEPGRAM_API_KEY.value='synthetic-test-only'; return 1`);
      await evaluate(`return run(true)`);
      const first=await evaluate(`return {text:message.textContent,empty:form.elements.DEEPGRAM_API_KEY.value==='',dg:state.deepgramConfigured}`);
      if(!first.empty||!first.dg||!first.text.includes('No AI connected'))bad('首次设置无模型测试反馈');else ok('无模型也可保存转写；测试提示明确');
      await evaluate(`document.querySelector('input[value=volc]').checked=true; paintAsr(); return run(false)`);
      const blocked=await evaluate(`return location.pathname.endsWith('setup.html')&&message.textContent.includes('App Key')`);
      if(!blocked)bad('切火山未阻止漏填凭证');else ok('切换服务要求对应凭证');
      await evaluate(`document.querySelector('input[value=deepgram]').checked=true; paintAsr(); return 1`);
      await shot('setup-en');
      await evaluate(`document.querySelector('[data-l=zh]').click();return 1`);await shot('setup-zh');
      await evaluate(`void run(false);return 1`);await sleep(2000);
      const after=await evaluate(`return location.pathname.endsWith('index.html')`);
      if(!after)bad('保存并进入未导航');else ok('重新保存保留凭证且直接进入');
    }

    console.log('打开听会台 …');
    await send('Page.navigate',{url:`http://127.0.0.1:${PORT}/tinghuitai/index.html`});
    await sleep(5000);
    await shot('00-首页');

    const errs=await evaluate(`return (window.__smokeErrors||[]).slice(0,5)`);
    if (errs && errs.length) bad('页面报错：'+errs.join(' | '));

    if(process.env.SMOKE_WORKSPACE){
      const shell=await evaluate(`const f=document.querySelector('#workspace-frame');return {visible:f.getBoundingClientRect().height>300,oldHidden:getComputedStyle(document.querySelector('#main')).display==='none',controls:['start','b-hist','gear2','m-update'].every(id=>document.getElementById(id).offsetParent!==null),frame:f.contentDocument?.querySelector('#canvas')!==null}`);
      if(!shell.visible||!shell.oldHidden||!shell.controls||!shell.frame)bad('工作区主入口或录音/设置/历史/更新入口');else ok('工作区成为主界面，基础控制保留');
      const navigation=await evaluate(`return {agent:document.querySelector('#b-assistant').textContent,labels:['b-hist','b-memory','b-this'].map(id=>document.getElementById(id).textContent),visible:['m-update','b-feedback'].every(id=>document.getElementById(id).offsetParent!==null)}`);
      if(!navigation.agent.includes('MyAgent')||!navigation.visible||navigation.labels.join('|')!=='历史会议|项目记忆|导出与分享')bad('按钮整理或 MyAgent 命名');else ok('MyAgent、独立更新反馈、清晰导航');
      await evaluate(`document.querySelector('#b-this').click();return 1`);await sleep(300);
      const sharing=await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return {open:d.querySelector('#export-dialog').open,options:d.querySelectorAll('[data-share]').length,duplicate:d.querySelector('#cloud').offsetParent!==null}`);
      if(!sharing.open||sharing.options!==7||sharing.duplicate)bad('统一导出与分享入口');else ok('统一导出与分享，重复飞书入口隐藏');
      await evaluate(`document.querySelector('#workspace-frame').contentDocument.querySelector('#export-close').click();return 1`);
      await evaluate(`document.querySelector('#b-assistant').click();return 1`);await sleep(300);
      if(!await evaluate(`return !document.querySelector('#workspace-frame').contentDocument.querySelector('#assistant').hidden && document.querySelector('#assistant-panel').hidden`))bad('主助手入口仍绑旧会议');else ok('主助手入口独立于录音');
      await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;d.querySelector('#comment').value='翻一下昨天晚上的会议纪要';d.querySelector('#comment').dispatchEvent(new d.defaultView.KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));return 1`);await sleep(5700);
      const reply=await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return {text:d.querySelector('#conversation').textContent,links:d.querySelectorAll('#conversation a[href*="meeting-board.html?id="]').length}`);
      if(!reply.text.includes('Carl 的时间没有约定')||reply.links!==2||reply.text.includes('meeting has no transcript'))bad('没有开会时查昨天纪要');else ok('未录音时找回昨晚纪要和打开入口');
      await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,m=d.querySelector('#meeting');m.value='offline-smoke-other';m.dispatchEvent(new Event('change'));return 1`);await sleep(800);
      if(!await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#conversation').textContent.includes('翻一下昨天')`))bad('切换会议丢失全局对话');else ok('切换会议保留主助手对话');
      await send('Page.reload');await sleep(2200);await evaluate(`document.querySelector('#b-assistant').click();return 1`);await sleep(300);
      if(!await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#conversation').textContent.includes('Carl 的时间没有约定')`))bad('刷新后丢失全局对话');else ok('刷新后恢复主助手对话');
      const chatLayout=await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,c=d.querySelector('#conversation'),input=d.querySelector('#comment');return {styled:!!c.querySelector('.chat .user-message'),separate:c.getBoundingClientRect().bottom<=input.getBoundingClientRect().top,scroll:getComputedStyle(c).overflowY}`);
      if(!chatLayout.styled||!chatLayout.separate||chatLayout.scroll!=='auto')bad('主助手聊天布局与输入框重叠');else ok('主助手消息分层，聊天独立滚动，输入框固定');
      await shot('workspace-global-assistant');
      await evaluate(`document.querySelector('#workspace-frame').contentDocument.querySelector('#assistant-close').click();return 1`);
    }
    // ① 顶栏和页脚上每个看得见的按钮，都要点得动
    const entries=await evaluate(`
      return [...document.querySelectorAll('header button, footer button')]
        .filter(b=>b.offsetParent!==null && !b.disabled && b.id && !/^(start|stop)$/.test(b.id))
        .map(b=>({id:b.id,label:(b.textContent||'').trim().slice(0,14)}));`);
    console.log(`顶栏/页脚可见入口 ${entries.length} 个`);

    for (const e of entries){
      // 每一轮开始前先收干净，免得上一个入口留下的东西干扰判断
      await evaluate(`document.querySelectorAll('dialog[open]').forEach(d=>d.close()); document.querySelectorAll('.sheet.open').forEach(s=>s.classList.remove('open')); return 1`);
      await sleep(200);
      await evaluate(`document.getElementById(${JSON.stringify(e.id)}).click(); return 1`);
      await sleep(700);
      const opened=await evaluate(`
        const d=[...document.querySelectorAll('dialog[open]')].pop();
        const s=[...document.querySelectorAll('.sheet.open')].pop();
        return d?{kind:'dialog',id:d.id}:(s?{kind:'sheet',id:s.id}:null);`);
      if (!opened){ ok(`${e.label}（${e.id}）—— 不开弹窗，跳过`); continue; }
      await shot('10-'+e.id);
      // ② 开得起来就必须关得掉：Esc
      await send('Input.dispatchKeyEvent',{type:'keyDown',key:'Escape',code:'Escape',windowsVirtualKeyCode:27});
      await send('Input.dispatchKeyEvent',{type:'keyUp',key:'Escape',code:'Escape',windowsVirtualKeyCode:27});
      await sleep(500);
      const after=await evaluate(`return document.querySelectorAll('dialog[open], .sheet.open').length`);
      if (after>0) bad(`${e.label}（${e.id}）打开了 ${opened.id}，按 Esc 关不掉`);
      else ok(`${e.label}（${e.id}）→ ${opened.id}，Esc 能关`);
      await evaluate(`document.querySelectorAll('dialog[open]').forEach(d=>d.close()); return 1`);
    }

    // ③ 每个弹窗里都得有看得见的关闭/取消按钮（折叠区里的不算）
    const noClose=await evaluate(`
      const out=[];
      for (const d of document.querySelectorAll('dialog')){
        d.showModal();
        const hit=[...d.querySelectorAll('button')].some(b=>{
          if (b.closest('details:not([open])')) return false;
          if (b.getBoundingClientRect().height===0) return false;
          return /关闭|取消|Close|Cancel|×/.test((b.textContent||'')+(b.getAttribute('aria-label')||''));
        });
        if(!hit) out.push(d.id||'(无 id)');
        d.close();
      }
      return out;`);
    if (noClose.length) bad('这些弹窗里没有看得见的关闭按钮：'+noClose.join(', '));
    else ok('每个弹窗都有看得见的关闭按钮');

    await evaluate(`localStorage.setItem('tht-state',JSON.stringify({sessions:[{id:'notes-back-smoke',start:Date.now(),title:'UI smoke',transcript:[],todos:[]}],names:{}}));location.reload();return 1`);
    await sleep(900);
    await evaluate(`document.querySelector('#b-this').click();document.querySelector('#m-notes').click();return 1`);
    const notesOpened=await evaluate(`return document.querySelector('#meeting-notes').open&&!document.querySelector('#meeting-more-dialog').open`);
    await evaluate(`document.querySelector('#meeting-notes-back').click();return 1`);
    const notesReturned=await evaluate(`return document.querySelector('#meeting-more-dialog').open&&!document.querySelector('#meeting-notes').open`);
    if(!notesOpened||!notesReturned)bad('补充材料返回按钮没有回到这场会菜单');else ok('补充材料可返回这场会菜单');
    await evaluate(`document.querySelector('#meeting-more-dialog').close();return 1`);

    // Optional personal pages remain absent without a configured data source.
    await send('Page.navigate',{url:`http://127.0.0.1:${PORT}/tinghuitai/work.html`});
    await sleep(1200);
    const workspace=await evaluate(`return {hidden:[...document.querySelectorAll('[href="briefs.html"],[href="activity.html"]')].every(a=>a.hidden),button:!!document.querySelector('.cw-fab')}`);
    if(!workspace.hidden||!workspace.button)bad('工作台可选入口');else ok('未配置的日报动态隐藏，助手入口可用');
    await evaluate(`document.querySelector('.cw-fab').click(); return 1`);
    const panel=await evaluate(`return !document.querySelector('.cw-panel').hidden && document.querySelector('.cw-handoff').hidden`);
    if(!panel)bad('助手打开或未配置交办隐藏');else ok('助手可打开；无执行通道不显示交办');
    await evaluate(`document.querySelector('.cw-close').click(); return 1`);
    if(!await evaluate(`return document.querySelector('.cw-panel').hidden`))bad('助手关闭');else ok('助手可关闭');

    // Synthetic ended meeting: summaries above, fresh points below, ascending numbers.
    await send('Page.navigate',{url:`http://127.0.0.1:${PORT}/tinghuitai/index.html`});await sleep(800);
    await evaluate(`const rows=['先讨论需求范围','范围确定为桌面版','再讨论发布节奏','先给小组试用','手机方案继续讨论','成本还需要核对'];const start=Date.now()-600000;localStorage.setItem('tht-ui','zh');localStorage.setItem('tht-state',JSON.stringify({sessions:[{id:'outline-test',start,end:Date.now(),viewOnly:true,transcript:[],todos:[],factchecks:[],highlights:rows.map((text,i)=>({text,at:start+i*60000})),hlGroups:{at:Date.now(),groups:[{title:'先把桌面版做稳定',summary:'本轮先完成桌面端核心需求，手机方案后续讨论。',keys:rows.slice(0,2)},{title:'先在小组中试用',summary:'确认稳定后再扩大试用范围。',keys:rows.slice(2,4)}]}}],names:{}}));return 1`);
    await send('Page.reload');await sleep(1000);
    const outline=await evaluate(`return {headings:[...document.querySelectorAll('.outline-section h3')].map(x=>x.textContent),numbers:[...document.querySelectorAll('.outline-pending .k')].map(x=>x.textContent),sources:document.querySelectorAll('.outline-section details').length}`);
    if(outline.headings.length!==2||!outline.headings[0].startsWith('1.')||!outline.headings[1].startsWith('2.')||outline.numbers.join(',')!=='3.,4.'||outline.sources!==2)bad('凝练提纲顺序与原文展开');else ok('凝练1、2在上，近期3、4在下，原文可展开');
    const folded=await evaluate(`return [...document.querySelectorAll('#hl-pinned>.outline-section')].every(x=>!x.open)`);
    if(!folded)bad('总结默认折叠');else ok('总结置顶且默认只显示标题');
    await evaluate(`document.querySelector('#hl-pinned>.outline-section>summary').click();return 1`);
    if(!await evaluate(`return document.querySelector('#hl-pinned>.outline-section').open`))bad('总结展开');else ok('点击标题可展开正文');
    await shot('outline-chronological');

    // Keep memory in the recording page; verify the compact menu on phone width.
    await evaluate(`document.querySelectorAll('dialog[open]').forEach(d=>d.close());document.querySelector('#b-memory').click();return 1`);
    if(!await evaluate(`return document.querySelector('#memory-dialog').open && document.querySelector('#memory-dialog iframe').getAttribute('src')==='memory.html'`))bad('记忆没有内嵌');else ok('记忆在当前页面内打开');
    await evaluate(`document.querySelector('#memory-dialog .archive-close').click();document.querySelector('#b-this').click();return 1`);
    await send('Emulation.setDeviceMetricsOverride',{width:390,height:844,deviceScaleFactor:1,mobile:true});
    await shot('compact-menu-mobile');
    if(!await evaluate(`const d=document.querySelector('#meeting-more-dialog');return d.getBoundingClientRect().height<844 && d.querySelectorAll('.this-menu>section').length===3`))bad('手机本场菜单未收拢');else ok('手机本场菜单可完整显示');
    await evaluate(`document.querySelector('#meeting-more-dialog').close();return 1`);
    await evaluate(`const original=window.fetch;window.fetch=async(u,o)=>{const p=String(u);if(p.includes('/sharing/slack/channels'))return new Response(JSON.stringify({ok:true,selfAvailable:true,team:'Test',channels:[]}));if(p.includes('/sharing/bundle')){let mode=window.__smokeShareMode||'external';if(o&&o.body){mode=JSON.parse(o.body).mode||mode;window.__smokeShareMode=mode;}return new Response(JSON.stringify({key:'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa',status:'done',bundle:{mode,files:mode==='external'?['minutes']:['minutes','transcript'],slackText:'会议主题\\n讨论内容与待办',brief:{title:'会议',overview:'范围',topics:[],conclusions:[],todos:[]}}}));}return original(u,o);};document.querySelector('#share-slack').click();return 1`);
    await sleep(400);
    if(!await evaluate(`return document.querySelector('#slack-dialog').open && document.querySelector('#slack-channel').value==='self' && document.querySelector('#slack-share-mode').value==='external' && document.querySelector('#slack-files').querySelectorAll('a').length===1 && !document.querySelector('#slack-send').disabled`))bad('Slack 默认自己与对外单附件预览');else ok('Slack 默认自己与对外单附件预览');
    await evaluate(`const s=document.querySelector('#slack-share-mode');s.value='internal';s.dispatchEvent(new Event('change'));return 1`);await sleep(400);
    if(!await evaluate(`return document.querySelector('#slack-files').querySelectorAll('a').length===2`))bad('Slack 内部版双附件预览');else ok('Slack 内部版双附件预览');
    await shot('slack-share-mobile');
    await evaluate(`document.querySelector('#slack-dialog').close();return 1`);
    console.log('\n截图在 '+SHOTS);
    console.log(fails.length ? `\n冒烟失败 ${fails.length} 条` : '\n冒烟全过');
    process.exitCode = fails.length ? 1 : 0;
  } catch(e){ console.error('冒烟跑不起来：'+e.message); process.exitCode=2; }
  finally { try{ws&&ws.close();}catch{} try{chrome&&chrome.kill();}catch{} try{server&&server.kill();}catch{} }
})();
