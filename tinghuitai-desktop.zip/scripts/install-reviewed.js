#!/usr/bin/env node
'use strict';
// Local development updates use the same installation gate as releases.
const fs=require('fs'),path=require('path'),os=require('os'),{execFileSync}=require('child_process');
const root=path.resolve(__dirname,'..'),ackRoot=path.join(os.homedir(),'Workbuddy/agent_bus/ack');
function validate(receipt,head,receiptRoot=ackRoot){
 const file=fs.realpathSync(receipt),base=fs.realpathSync(receiptRoot);
 if(!file.startsWith(base+path.sep))throw Error('需要 Grok 正式 ack 回执');
 const text=fs.readFileSync(file,'utf8');
 if(!/^\s*(?:[-*]\s*)?(?:\*\*)?(?:Verdict|verdict|结论|状态|status)\s*[:：]\s*(?:\*\*)?review_passed\b/m.test(text))throw Error('Grok 尚未给出正式 review_passed');
 if(!text.includes(head))throw Error('审核回执与当前提交不一致，请重新审核');
 return file;
}
if(require.main===module){try{
 const head=execFileSync('git',['rev-parse','HEAD'],{cwd:root,encoding:'utf8'}).trim();
 const receipt=validate(process.argv[2]||'',head);
 console.log('Grok 回执已核对：'+path.basename(receipt));
 const requestId=process.argv[3];
 if(requestId){if(!/^[\w-]{8,100}$/.test(requestId))throw Error('无效开发请求 ID');const dir=path.join(root,'.tmp/development-receipts');fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,requestId+'.json'),JSON.stringify({head,reviewReceipt:receipt,version:require('../package.json').version,at:new Date().toISOString()}));}
 execFileSync('bash',['scripts/deploy-beta.sh'],{cwd:root,stdio:'inherit'});
}catch(e){console.error('未安装：'+e.message);process.exitCode=1;}}
module.exports={validate};
