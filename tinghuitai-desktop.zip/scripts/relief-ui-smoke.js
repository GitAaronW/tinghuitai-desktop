'use strict';
// 界面冒烟：把「每个入口都点一遍，看它开得起来、也关得掉」这件事自动化。
// 起因：2026-09-11/12 连着三次是同一类问题——功能还在，界面上点不到，或者打开了关不掉。
// 这些都不是逻辑错，单元测试一条都拦不住，只能真的打开页面点一遍。
// 用法：node scripts/relief-ui-smoke.js   （自己起隔离实例、自己开无头 Chrome、自己收摊）
const {spawn,execFileSync}=require('child_process'), fs=require('fs'), os=require('os'), path=require('path'), WebSocket=require('ws');
const CHROME='/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const PORT=Number(process.env.SMOKE_PORT||47871), CDP=Number(process.env.SMOKE_CDP||47872);
const DATA=fs.mkdtempSync(path.join(os.tmpdir(),'tht-smoke-')), PROFILE=path.join(DATA,'chrome');
const SHOTS=path.join(DATA,'shots'); fs.mkdirSync(SHOTS,{recursive:true});
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let server, chrome, ws, id=0, pending=new Map();

function send(method,params={}){ const i=++id; ws.send(JSON.stringify({id:i,method,params}));
  return new Promise((res,rej)=>{ const timer=setTimeout(()=>{pending.delete(i);rej(new Error(method+' 超时'));},30000);pending.set(i,{res,rej,timer}); }); }
async function evaluate(expr){
  const r=await send('Runtime.evaluate',{expression:`(async()=>{${expr}})()`,awaitPromise:true,returnByValue:true});
  if (r.exceptionDetails) throw new Error((r.exceptionDetails.exception?.description||'页面里报错了')+' · '+expr.slice(0,180));
  return r.result.value;
}
async function shot(name){ const r=await send('Page.captureScreenshot',{}); fs.writeFileSync(path.join(SHOTS,name+'.png'), Buffer.from(r.data,'base64')); }

(async()=>{
 const checks=[],errors=[];const assert=(value,label)=>{if(!value)throw Error(label);checks.push(label);console.log('PASS '+label)};
 try{
  const previous=new Date();previous.setDate(previous.getDate()-1);previous.setHours(21,0,0,0);
  const {Hub}=require('../app/work-hub'),hub=new Hub(DATA,path.join(DATA,'state','work-hub'));
  fs.mkdirSync(path.join(DATA,'pending'),{recursive:true});
  for(const [id,title] of [['offline-smoke-evening','昨晚的产品讨论'],['offline-smoke-other','另一场会议']]){
   const session={id,title,start:previous.getTime(),end:previous.getTime()+3600000,transcript:[{segId:'s1',speaker:'Aaron',text:'Carl 的时间没有约定。',t:30}],summary:'## 尚未约定\nCarl 的时间没有约定。',todos:[],highlights:[]};
   fs.writeFileSync(path.join(DATA,'pending',id+'.json'),JSON.stringify(session));const source=hub.ingestSession(session);
   hub.update('sources',source.id,{board:{goal:'对齐投资人展示准备',cursor:1,modules:[{id:'summary-one',edited:false,kind:'summary',title:'展示安排',topic:'投资人展示',body:'### 已知\nCarl 的时间没有约定。\n### 仍需明确\n- 评审时间',sourceRefs:['s1']},{id:'action-one',edited:false,kind:'task',title:'整理展示资料',topic:'投资人展示',body:'与 Hannah 收集概念、渲染和样机资料。',owner:'Aaron',sourceRefs:['s1']}]}},source.revision);
  }
  hub.data.tasks.push({id:'quiet-task',key:'manual:quiet',triage:'mine',text:'过时的无期限想法',status:'todo',owner:'Aaron',businessUpdatedAt:'2026-01-01T00:00:00Z',sourceIds:[]},{id:'fresh-task',key:'manual:fresh',triage:'mine',text:'当前展示安排',status:'todo',owner:'Aaron',businessUpdatedAt:new Date().toISOString(),sourceIds:[]});hub.save();
  server=spawn(process.execPath,[path.join(__dirname,'../app/server.js')],{env:{...process.env,THT_DATA_DIR:DATA,THT_PORT:String(PORT),THT_NO_OPEN:'1',THT_LLM_AUTOPICK:'off',LIVE_CARD_WARMUP:'off',THT_CODEX_APP_SERVER_BIN:'/bin/false'},stdio:'ignore'});
  for(let i=0;i<50;i++){try{if((await fetch(`http://127.0.0.1:${PORT}/health`)).ok)break}catch{}await sleep(200)}
  // Canonical routes: old URLs preserve identity and never expose old pages.
  for(const [route,target] of [['archive.html?id=offline-smoke-evening','./?id=offline-smoke-evening'],['meeting-board.html?id=offline-smoke-evening','./?id=offline-smoke-evening'],['activity.html','work.html#activity'],['briefs.html','work.html#briefs']]){const r=await fetch(`http://127.0.0.1:${PORT}/tinghuitai/`+route,{redirect:'manual'});assert(r.status===302&&r.headers.get('location')===target,'canonical redirect '+route)}
  for(const route of ['/meeting-board','/asr-relay/meeting-board']){const r=await fetch(`http://127.0.0.1:${PORT}`+route+'?id=offline-smoke-evening');assert(r.status===200&&(await r.json()).source.board.modules.length===2,'board HTTP namespace '+route)}
  chrome=spawn(CHROME,['--headless=new',`--remote-debugging-port=${CDP}`,`--user-data-dir=${PROFILE}`,'--no-first-run','--window-size=1440,900','--disable-gpu','about:blank'],{stdio:'ignore'});
  let target;for(let i=0;i<50&&!target;i++){await sleep(200);try{target=(await(await fetch(`http://127.0.0.1:${CDP}/json/list`)).json()).find(t=>t.type==='page')}catch{}}
  if(!target)throw Error('Chrome connection');ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise(r=>ws.on('open',r));ws.on('message',d=>{const m=JSON.parse(d);if(m.id&&pending.has(m.id)){const p=pending.get(m.id);pending.delete(m.id);clearTimeout(p.timer);m.error?p.rej(Error(m.error.message)):p.res(m.result)}if(m.method==='Runtime.exceptionThrown')errors.push(m.params.exceptionDetails.exception?.description||m.params.exceptionDetails.text)});
  await send('Page.enable');await send('Runtime.enable');await send('Page.navigate',{url:`http://127.0.0.1:${PORT}/tinghuitai/?id=offline-smoke-evening`});await sleep(3200);
  assert(await evaluate(`const f=document.querySelector('#workspace-frame');return f?.contentDocument?.querySelector('#canvas')&&getComputedStyle(document.querySelector('#main')).display==='none'&&['start','b-hist','gear2','m-update','b-feedback'].every(id=>document.getElementById(id).offsetParent!==null)`),'one canvas and essential controls');
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#canvas').textContent.includes('与 Hannah')`),'complete meeting content appears');await shot('01-meeting');
  await evaluate(`document.getElementById('b-assistant').click();return true`);await sleep(200);
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return !d.querySelector('#assistant').hidden&&d.querySelector('#send').textContent==='发送'&&!d.querySelector('#delegate')`),'MyAgent one send');
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,t=d.querySelector('#comment');t.value='IME draft';t.dispatchEvent(new d.defaultView.KeyboardEvent('keydown',{key:'Enter',isComposing:true,bubbles:true,cancelable:true}));t.dispatchEvent(new d.defaultView.KeyboardEvent('keydown',{key:'Enter',shiftKey:true,bubbles:true,cancelable:true}));return t.value==='IME draft'`),'IME and Shift Enter keep draft');
  await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,t=d.querySelector('#comment');t.value='翻一下昨天晚上的会议纪要';t.dispatchEvent(new d.defaultView.KeyboardEvent('keydown',{key:'Enter',bubbles:true,cancelable:true}));return true`);await sleep(2200);
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return d.querySelector('#conversation').textContent.includes('Carl 的时间没有约定')&&d.querySelectorAll('#conversation a[href*="/tinghuitai/?id="]').length===2`),'Enter retrieves exact minutes without active recording');
  await shot('02-agent');
  await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,m=d.querySelector('#meeting');m.value='offline-smoke-other';m.dispatchEvent(new d.defaultView.Event('change'));return true`);await sleep(700);await send('Page.reload');await sleep(1700);await evaluate(`document.getElementById('b-assistant').click();return true`);await sleep(300);
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument;return location.search.includes('offline-smoke-other')&&d.querySelector('#conversation').textContent.includes('翻一下昨天')`),'meeting switch and refresh preserve conversation');
  await evaluate(`document.querySelector('#workspace-frame').contentDocument.querySelector('#assistant-close').click();document.querySelector('#b-this').click();return true`);await sleep(150);
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#export-dialog').open`),'unified export');
  await evaluate(`document.querySelector('#workspace-frame').contentDocument.querySelector('#export-close').click();return true`);
  await evaluate(`document.querySelector('[data-ui=en]').click();return true`);await sleep(1300);
  assert(await evaluate(`return document.querySelector('#workspace-frame').contentDocument.querySelector('#recap-title').textContent.includes('AI')`),'language reaches canvas');
  await evaluate(`document.querySelector('[data-ui=zh]').click();return true`);await sleep(300);
  await evaluate(`window.__recorderDocument=crypto.randomUUID();window.__meetingCanvas=document.querySelector('#workspace-frame').contentWindow;document.querySelector('#b-work-top').click();return true`);await sleep(1200);
  assert(await evaluate(`return location.pathname.endsWith('/tinghuitai/')&&!document.querySelector('#work-frame').hidden&&document.querySelector('#workspace-frame').hidden&&document.querySelector('#b-work-top').textContent==='← 听会台'`),'work switch keeps recorder document alive');
  await evaluate(`document.querySelector('#b-assistant').click();return true`);await sleep(200);
  assert(await evaluate(`return !document.querySelector('#work-frame').contentDocument.querySelector('.ma-panel').hidden`),'MyAgent follows current surface');
  await evaluate(`document.querySelector('#work-frame').contentDocument.querySelector('.back-link').click();return true`);await sleep(300);
  assert(await evaluate(`return !!window.__recorderDocument&&window.__meetingCanvas===document.querySelector('#workspace-frame').contentWindow&&document.querySelector('#work-frame').hidden&&!document.querySelector('#workspace-frame').hidden&&document.querySelector('#b-work-top').textContent==='工作台'`),'return retains recorder and original canvas');
  await send('Page.navigate',{url:`http://127.0.0.1:${PORT}/tinghuitai/work.html`});await sleep(1300);
  for(const view of ['tasks','graph','sources','people','memory','briefs','activity','focus']){await evaluate(`document.querySelector('[data-view=${view}]').click();return true`);await sleep(200);assert(await evaluate(`return location.pathname.endsWith('/work.html')&&document.querySelector('.topbar')&&document.querySelector('.ma-fab')`),'shared work shell '+view)}
  await evaluate(`document.querySelector('[data-view=tasks]').click();return true`);await sleep(200);
  assert(await evaluate(`return !document.querySelector('#content').textContent.includes('过时的无期限想法')`),'quiet task absent from default');
  await evaluate(`const q=document.querySelector('#filters input');q.value='过时';q.dispatchEvent(new Event('input',{bubbles:true}));return true`);await sleep(600);
  assert(await evaluate(`return document.querySelector('#content').textContent.includes('过时的无期限想法')`),'quiet task searchable');
  await evaluate(`document.querySelector('#work-lang').click();return true`);await sleep(100);assert(await evaluate(`return document.documentElement.lang==='en'&&document.querySelector('[data-view=tasks]').textContent==='Work items'`),'work core language switch');await evaluate(`document.querySelector('#work-lang').click();return true`);await shot('03-work');await evaluate(`document.querySelector('.back-link').click();return true`);await sleep(1900);
  assert(await evaluate(`return location.pathname.endsWith('/tinghuitai/')&&location.search.includes('offline-smoke-other')`),'work returns to selected meeting');
  await send('Emulation.setDeviceMetricsOverride',{width:430,height:932,deviceScaleFactor:1,mobile:true});await sleep(300);await evaluate(`document.getElementById('b-assistant').click();return true`);await sleep(300);
  assert(await evaluate(`const d=document.querySelector('#workspace-frame').contentDocument,r=d.querySelector('#comment').getBoundingClientRect();return r.width>100&&r.right<=d.defaultView.innerWidth+2`),'mobile composer remains usable');await shot('04-mobile');
  if(errors.length)console.error(JSON.stringify({browserErrors:errors}));
  assert(errors.length===0,'zero browser runtime exceptions');console.log(JSON.stringify({checks:checks.length,shots:SHOTS,data:DATA}));
 }catch(e){console.error(e.stack);if(ws){try{await shot('failure');console.error(await evaluate(`return document.querySelector('#workspace-frame')?.contentDocument?.querySelector('#conversation')?.textContent||document.querySelector('#content')?.textContent`));}catch{}}process.exitCode=1}finally{if(ws)ws.close();if(chrome)chrome.kill();if(server)server.kill();console.log('Artifacts '+SHOTS)}
})();
