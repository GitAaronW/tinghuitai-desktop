'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),{spawnSync}=require('child_process'),path=require('path'),os=require('os'),fs=require('fs');
test('internal and external share bundles keep separate data boundaries',()=>{const file=path.join(__dirname,'../app/share-bundle.py');const code=`import importlib.util,json
spec=importlib.util.spec_from_file_location('sb',${JSON.stringify(file)})
sb=importlib.util.module_from_spec(spec);spec.loader.exec_module(sb)
seen=[]
def summarize(source,context_purpose=None):
 seen.append(source);return '# minutes'
def ask_model(*args,**kwargs):
 return {'text':json.dumps({'title':'T','overview':'O','topics':[{'title':'A','points':['P']}],'conclusions':[],'todos':[]},ensure_ascii=False)}
sb.p.summarize=summarize;sb.p.ask_model=ask_model
s={'id':'m','title':'2026-09-28 review','names':{'0':'Alice Zhang','1':'Li'},'notes':'private note','factchecks':[{'claim':'private judgement'}],'transcript':[{'speaker':'0','text':'Alice Zhang: email alice@example.com, phone +86 138 0013 8000, mobile 13800138000, file /Users/alice/secret.txt; deadline 2026-09-28; Alice remains a word.'},{'text':'secret','sensitive':True}]}
ext=sb.generate(s,'external');inn=sb.generate(s,'internal')
print(json.dumps({'external':ext,'internal':inn,'sources':seen},ensure_ascii=False))
`;const d=fs.mkdtempSync(path.join(os.tmpdir(),'share-modes-'));const r=spawnSync('python3',['-c',code],{encoding:'utf8',env:{...process.env,THT_DATA_DIR:d}});fs.rmSync(d,{recursive:true,force:true});assert.equal(r.status,0,r.stderr);const j=JSON.parse(r.stdout);assert.deepEqual(j.external.files,['minutes']);assert.deepEqual(j.internal.files,['minutes','transcript']);assert.equal(j.sources[0].notes,undefined);assert.equal(j.sources[0].names,undefined);assert.equal(j.sources[0].title,'2026-09-28 review');assert.equal(j.sources[0].transcript.length,1);assert.match(j.sources[0].transcript[0].text,/\[姓名已隐藏\]/);assert.match(j.sources[0].transcript[0].text,/\[邮箱已隐藏\]/);assert.equal((j.sources[0].transcript[0].text.match(/\[电话已隐藏\]/g)||[]).length,2);assert.match(j.sources[0].transcript[0].text,/\[本机路径已隐藏\]/);assert.match(j.sources[0].transcript[0].text,/deadline 2026-09-28/);assert.match(j.sources[0].transcript[0].text,/Alice remains/,'short name Li must not redact inside ordinary words');assert.doesNotMatch(JSON.stringify(j.sources[0]),/Alice Zhang|alice@example\.com|138 0013|13800138000|\/Users\/alice/);assert.equal(j.sources[1].notes,'private note');assert.equal(j.sources[1].transcript.length,2);assert.match(j.internal.transcript,/secret/);assert.match(j.internal.transcript,/Alice Zhang/);assert.equal(j.external.transcript,undefined);});
