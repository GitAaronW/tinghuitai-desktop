'use strict';
const test = require('node:test');
const assert = require('node:assert');
const gate = require('../scripts/insight-release-gate');

function rapid(overrides = {}) {
  return {
    meetingId: 'meeting-1',
    cardsPer10MeetingMin: 7.5,
    cardsPer10TranscriptMin: 7.5,
    coalesceSec: 5,
    failed: 0,
    emitted: 45,
    calls: [{ round: 1, insights: [{ point: '讨论了下阶段方案，结论仍待确认。', action: { text: '继续核对数据' } }] }],
    ...overrides,
  };
}

test('rapid gate accepts high recall without the retired five minute cooldown', () => {
  const report = gate.evaluate(rapid(), []);
  assert.strictEqual(report.ok, true);
  assert.strictEqual(report.cards, 45);
  assert.deepStrictEqual(report.checks.map(x => x.id), ['rapid_cadence', 'response_window', 'model_failures', 'semantic_state']);
});

test('rapid gate measures active transcript time and does not treat 负责人 as a promise', () => {
  const report = gate.evaluate(rapid({
    cardsPer10MeetingMin: 6.57,
    cardsPer10TranscriptMin: 8.3,
    calls: [{ round: 15, insights: [{ point: '拖拽体验需要继续确认。', action: { text: '确认拖拽问题的负责人和修复时间' } }] }],
  }), []);
  assert.strictEqual(report.ok, true);
  assert.strictEqual(report.checks[0].actual, 8.3);
  assert.deepStrictEqual(report.risks, []);
});

test('rapid gate rejects failures, slow coalescing, low recall and unsafe state claims', () => {
  const report = gate.evaluate(rapid({
    cardsPer10MeetingMin: 3,
    cardsPer10TranscriptMin: 3,
    coalesceSec: 12,
    failed: 1,
    calls: [{ round: 2, insights: [{ point: '还在讨论，已经确认下周发布。' }] }],
  }), []);
  assert.strictEqual(report.ok, false);
  assert.deepStrictEqual(report.checks.map(x => x.pass), [false, false, false, false]);
});

test('legacy slow-mode report remains supported', () => {
  const report = gate.evaluate({
    sid: 'legacy', tag: 'old', per10min: { after: 1.5 },
    after: { cards: 2, buckets: [2] },
  }, [
    { round: 1, atEnd: 0, insight: { md: '第一张' } },
    { round: 2, atEnd: 300, insight: { md: '第二张' } },
  ]);
  assert.strictEqual(report.ok, true);
});
