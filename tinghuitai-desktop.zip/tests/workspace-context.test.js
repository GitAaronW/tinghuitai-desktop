'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),ctx=require('../app/workspace-context'),bridge=require('../app/codex-app-bridge'),fs=require('fs'),os=require('os'),path=require('path');
test('selected context is bounded; independent requests use separate tasks without another button',()=>{
 assert.equal(ctx.sanitizePageContext({quote:'x'.repeat(10000),sourceIds:Array(20).fill('s')}).quote.length,4000);
 assert.equal(ctx.executionKind('auto','帮我写一份 Carl 汇报计划'),'run');assert.equal(ctx.executionKind('auto','Carl 的材料怎么样了？'),'chat');
 const modules=Array.from({length:20},(_,i)=>({id:'m'+i,title:'CAD '+i,body:'x'.repeat(6000),sourceRefs:['r']}));
 const b=ctx.selectedBoard({modules},{comment:'CAD',pageContext:{objectId:'m18'}});assert.equal(b.modules.length,6);assert.equal(b.modules[0].id,'m18');assert.ok(b.modules.every(m=>m.body.length<=3000));
});
test('hardware project context cannot pull software or health objects into a scoped question',()=>{
 const data={sources:[{sessionId:'m1',projectId:'hardware'}],projects:[{id:'hardware'},{id:'software'},{id:'health'}],workItems:[{id:'w1',projectId:'hardware',title:'Carl CAD'},{id:'w2',projectId:'health',title:'Carl CAD'}]};
 const out=ctx.scopeContext({hub:{data}},{comment:'Carl CAD',contextId:'m1',pageContext:{}},[{id:'m1',projectId:'hardware',title:'Carl'},{id:'m2',projectId:'software',title:'Carl'}]);
 assert.deepEqual(out.projects,[{id:'hardware',title:undefined}]);assert.equal(out.relevantTasks.length,1);assert.equal(out.meetings.length,1);
});
test('saving parallel native threads merges the newest journal without losing another task',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-threads-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 bridge.rememberThread(dir,'run','one','native-one');bridge.rememberThread(dir,'run','two','native-two');bridge.rememberThread(dir,'chat','','master');
 assert.deepEqual(bridge.readMap(dir).value,{globalThreadId:'master',taskThreads:{one:'native-one',two:'native-two'}});
});

test('parallel drafts append to the current canvas without changing confirmed records',()=>{
 const {saveDraft}=require('../app/workspace-context'),source={id:'s',sessionId:'meeting',revision:1,board:{modules:[{id:'original',kind:'note',title:'Original',body:'User edit',edited:true,sourceRefs:['seg1']}]}};
 const ctx={hub:{data:{sources:[source]},update(_kind,id,patch,rev){assert.equal(id,'s');assert.equal(rev,source.revision);Object.assign(source,patch);source.revision++;return source;}}};
 const request={action:'run',contextId:'meeting',requestId:'one',comment:'Draft plan',pageContext:{objectId:'original'}};
 saveDraft(ctx,request,'First draft');saveDraft(ctx,{...request,requestId:'two'},'Second draft');saveDraft(ctx,request,'Duplicate');
 assert.equal(source.board.modules.length,3);assert.equal(source.board.modules[0].body,'User edit');assert.equal(source.board.modules[1].kind,'note');assert.match(source.board.modules[1].context,/AI 草稿/);
});
