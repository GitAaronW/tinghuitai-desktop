'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),attention=require('../web/attention');
const now=Date.parse('2026-10-03T12:00:00Z'),old='2026-09-01T12:00:00Z';
test('seven-day relief uses business evidence, not importer or migration timestamps',()=>{
 const w={status:'todo',updated:new Date(now).toISOString(),created:new Date(now).toISOString(),memberIds:['t'],sourceIds:['s']},db={tasks:[{id:'t',updated:new Date(now).toISOString()}],sources:[{id:'s',date:old,updated:new Date(now).toISOString()}]};
 assert.equal(attention(w,db,now).state,'quiet');assert.equal(attention(w,db,now).idleDays,32);
 w.businessUpdatedAt=new Date(now-1000).toISOString();assert.equal(attention(w,db,now).state,'focus');
 delete w.businessUpdatedAt;db.tasks[0].businessUpdatedAt=new Date(now-1000).toISOString();assert.equal(attention(w,db,now).state,'focus');
});
test('deadlines, promises, dependencies, blocked and submitted work stay visible',()=>{
 for(const protectedField of [{due:'10月8日'},{commitment:true},{dependencies:['d']},{attentionPinned:true},{needsDecision:true},{status:'doing'},{status:'blocked'},{status:'submitted'}])assert.equal(attention({status:'todo',businessUpdatedAt:old,...protectedField},{},now).state,'protected');
 assert.equal(attention({status:'todo'},{},now).state,'focus','Unknown dates cannot silently hide items');
 assert.equal(attention({status:'done',businessUpdatedAt:old},{},now).state,'closed');
});
test('attention is a derived view and never erases or verifies a task',()=>{
 const w={status:'todo',businessUpdatedAt:old},before=JSON.stringify(w);assert.equal(attention(w,{},now).state,'quiet');assert.equal(JSON.stringify(w),before);
});
