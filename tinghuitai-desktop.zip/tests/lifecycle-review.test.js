'use strict';
const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),os=require('os'),path=require('path');
const mem=require('../app/memory'),ops=require('../app/memory-ops'),{Hub,bucketOf}=require('../app/work-hub'),knowledge=require('../app/knowledge');
function temp(t){const d=fs.mkdtempSync(path.join(os.tmpdir(),'tht-lifecycle-'));t.after(()=>{mem.closeAll();fs.rmSync(d,{recursive:true,force:true});});return d;}
test('editing invalidates confirmation; candidates require separate explicit promotion and retain history',t=>{
 const dir=temp(t),db=mem.open(dir),c=mem.putCard(db,{project:'p',kind:'decision',text:'Pin camera plan',confirmed:1});
 assert.throws(()=>mem.reviewCard(db,c.id,'promote'),/候选/);
 let r=mem.updateCard(db,c.id,{text:'Pin alternative plan',human_edited:1});assert.equal(r.confirmed,0);assert.equal(r.needs_review,1);
 r=mem.reviewCard(db,c.id,'candidate');assert.equal(r.memory_tier,'candidate');assert.equal(ops.retrieve(dir,'Pin',{projectId:'p'}).length,0);
 r=mem.reviewCard(db,c.id,'confirm');assert.equal(r.memory_tier,'candidate');assert.equal(r.confirmed,1);
 r=mem.reviewCard(db,c.id,'promote');assert.equal(r.memory_tier,'stable');assert.equal(ops.retrieve(dir,'Pin',{projectId:'p'}).length,1);
 r=mem.updateCard(db,c.id,{text:'Pin changed again'});assert.equal(r.memory_tier,'candidate');assert.equal(r.confirmed,0);
 assert.equal(db.prepare('SELECT count(*) AS n FROM card_history WHERE id=?').get(c.id).n,6);
 assert.match(ops.toPromptBlock([r]),/尚未确认/);
});
test('completed tasks require acceptance criteria and evidence before verification in both write paths',t=>{
 const dir=temp(t),h=new Hub(dir,dir),a=h.task({text:'Prepare CAD',key:'manual:cad',status:'todo'});h.save();
 const w=h.data.workItems.find(x=>x.memberIds.includes(a.id));
 const update=p=>knowledge.update(h,{kind:'work',id:w.id,revision:w.revision,patch:p});
 assert.throws(()=>update({status:'verified'}),/验收标准/);assert.equal(w.status,'todo');
 update({status:'done'});assert.equal(w.status,'done');assert.equal(a.status,'done');
 assert.throws(()=>update({status:'verified',acceptanceCriteria:'All CAD files open'}),/证据/);
 update({status:'verified',acceptanceCriteria:'All CAD files open',completionEvidence:'Reviewed CAD files in viewer, all 3 opened'});
 assert.equal(w.status,'verified');assert.equal(a.status,'verified');assert.equal(bucketOf(a),'mine');
 assert.throws(()=>h.update('tasks',a.id,{completionEvidence:''},a.revision),/证据/);
 const restored=new Hub(dir,dir);assert.equal(restored.data.tasks.find(x=>x.id===a.id).status,'verified');
 for(const status of ['draft','todo','doing','blocked','submitted','done','cancelled'])h.update('tasks',a.id,{status},a.revision);
});
