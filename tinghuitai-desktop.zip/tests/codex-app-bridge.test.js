'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('fs'),os=require('os'),path=require('path');
const bridge=require('../app/codex-app-bridge');

test('Codex app-server bridge persists and resumes the global thread while isolating task threads',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-codex-bridge-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const bin=path.join(dir,'fake-codex');
 fs.writeFileSync(bin,`#!/usr/bin/env node
const fs=require('fs');let buf='';const log=process.env.FAKE_CODEX_LOG;
function send(x){process.stdout.write(JSON.stringify(x)+'\\n')}
process.stdin.setEncoding('utf8');process.stdin.on('data',chunk=>{buf+=chunk;let i;while((i=buf.indexOf('\\n'))>=0){const line=buf.slice(0,i);buf=buf.slice(i+1);let m;try{m=JSON.parse(line)}catch{continue}if(m.method==='initialized')continue;if(log)fs.appendFileSync(log,m.method+' '+JSON.stringify(m.params||{})+'\\n');
if(m.method==='thread/start'){const n=(fs.existsSync(log)?fs.readFileSync(log,'utf8').split('\\n').filter(x=>x.startsWith('thread/start ')).length:1);send({id:m.id,result:{thread:{id:'thread-new-'+n}}})}
else if(m.method==='initialize')send({id:m.id,result:{}})
else if(m.method==='thread/resume')send({id:m.id,result:{thread:{id:m.params.threadId}}});
else if(m.method==='turn/start'){send({id:m.id,result:{turn:{id:'turn-1',status:'inProgress'}}});setImmediate(()=>{send({method:'item/completed',params:{item:{type:'agentMessage',text:JSON.stringify({reply:'Answer from Codex',action:null})}}});send({method:'turn/completed',params:{turn:{id:'turn-1',status:'completed'}}})})}
}});
`);fs.chmodSync(bin,0o700);
 const old=process.env.THT_CODEX_APP_SERVER_BIN,oldLog=process.env.FAKE_CODEX_LOG;process.env.THT_CODEX_APP_SERVER_BIN=bin;process.env.FAKE_CODEX_LOG=path.join(dir,'calls.log');
 t.after(()=>{if(old===undefined)delete process.env.THT_CODEX_APP_SERVER_BIN;else process.env.THT_CODEX_APP_SERVER_BIN=old;if(oldLog===undefined)delete process.env.FAKE_CODEX_LOG;else process.env.FAKE_CODEX_LOG=oldLog;});
 const first=await bridge.ask({dataDir:dir,kind:'chat',conversationId:'one',requestText:'first'});
 const second=await bridge.ask({dataDir:dir,kind:'chat',conversationId:'two',requestText:'second'});
 const task=await bridge.ask({dataDir:dir,kind:'run',conversationId:'task-1',requestText:'do task'});
 assert.equal(first.threadId,'thread-new-1');assert.equal(second.threadId,'thread-new-1');assert.equal(task.threadId,'thread-new-2');
 assert.match(first.text,/Answer from Codex/);assert.deepEqual(bridge.readMap(dir).value,{globalThreadId:'thread-new-1',taskThreads:{'task-1':'thread-new-2'}});
 const log=fs.readFileSync(path.join(dir,'calls.log'),'utf8');assert.equal((log.match(/thread\/start/g)||[]).length,2);assert.equal((log.match(/thread\/resume/g)||[]).length,1);
 assert.match(log,/"sandbox":"read-only"/);assert.match(log,/"sandboxPolicy":\{"type":"readOnly"\}/);
});

test('Codex bridge reports an uncertain submitted turn with its thread ID',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'tht-codex-timeout-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const bin=path.join(dir,'fake-codex');fs.writeFileSync(bin,`#!/usr/bin/env node\nlet b='';const s=x=>process.stdout.write(JSON.stringify(x)+'\\n');process.stdin.setEncoding('utf8');process.stdin.on('data',c=>{b+=c;let i;while((i=b.indexOf('\\n'))>=0){const l=b.slice(0,i);b=b.slice(i+1);let m;try{m=JSON.parse(l)}catch{continue}if(m.method==='initialize')s({id:m.id,result:{}});if(m.method==='thread/start')s({id:m.id,result:{thread:{id:'thread-timeout'}}});if(m.method==='turn/start')s({id:m.id,result:{turn:{id:'turn-timeout',status:'inProgress'}}})}});`);fs.chmodSync(bin,0o700);
 const old=process.env.THT_CODEX_APP_SERVER_BIN;process.env.THT_CODEX_APP_SERVER_BIN=bin;t.after(()=>old===undefined?delete process.env.THT_CODEX_APP_SERVER_BIN:process.env.THT_CODEX_APP_SERVER_BIN=old);
 await assert.rejects(bridge.ask({dataDir:dir,kind:'chat',requestText:'timeout',timeoutMs:1000}),e=>e.uncertain===true&&e.threadId==='thread-timeout');
 assert.equal(bridge.readMap(dir).value.globalThreadId,'thread-timeout');
});
