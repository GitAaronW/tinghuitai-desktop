(()=>{
 const back=document.querySelector('.topbar > .back-link');if(back)back.href=sessionStorage.getItem('tht-meeting-return')||('./'+(sessionStorage.getItem('tht-selected-meeting')?'?id='+encodeURIComponent(sessionStorage.getItem('tht-selected-meeting')):''));
 if(back&&new URLSearchParams(location.search).has('shell')&&parent!==window)back.onclick=e=>{e.preventDefault();parent.postMessage({type:'tht-work-return'},location.origin);};
 if(new URLSearchParams(location.search).has('embedded')){document.documentElement.classList.add('utility-embedded');const css=document.createElement('style');css.textContent='.topbar,body>header,.cw-fab{display:none!important}.shell{max-width:none!important;padding:8px!important}';document.head.append(css);}
})();
