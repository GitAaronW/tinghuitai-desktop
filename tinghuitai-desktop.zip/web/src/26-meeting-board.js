async function workspaceShareAction(message){
      const controls={lark:'share-lark',slack:'share-slack',full:'x-full',transcript:'x-verb',pdf:'x-pdf',copy:'copy',workspace:'save-hub'};
      const control=controls[message.action],id=message.sessionId;
      if(!control||!id)return;
      if(running&&cur?.id!==id){note(ui==='en'?'End the current meeting before exporting another.':'请先结束当前会议，再导出其他会议。',true);return;}
      try{
        const r=await fetch(relayBase()+'/export-state?ids='+encodeURIComponent(id)+'&token='+encodeURIComponent(cfg.relayToken||''),{cache:'no-store',signal:AbortSignal.timeout(8000)});
        if(!r.ok)throw Error('HTTP '+r.status);
        const selected=(await r.json()).sessions.find(x=>x.id===id);
        if(!selected)throw Error(ui==='en'?'Meeting not found':'未找到对应会议');
        if(!running){cur=normalizeSession(selected);resetSigs();render();}
        document.getElementById(control).click();
      }catch(error){note(error.message,true);}
}
// Keep the existing recorder and controls as the application shell. Its primary
// content is the same workspace used after the meeting, not a second data store.
{ // The recorder always uses the canonical meeting canvas.
  const frame = document.getElementById('workspace-frame');
  document.getElementById('app').classList.add('workspace-primary');
  frame.hidden = false;
  let previous = '', ready = false, viewedMeetingId = new URLSearchParams(location.search).get('id') || sessionStorage.getItem('tht-selected-meeting') || '', wasRunning=running;
  const workFrame=document.getElementById('work-frame');
  window.thtCloseWorkbench=()=>{workFrame.hidden=true;frame.hidden=false;syncWorkspace(true);};
  window.thtOpenWorkbench=view=>{
    sessionStorage.setItem('tht-meeting-return',location.href);
    if(!view&&!workFrame.hidden){window.thtCloseWorkbench();return;}
    if(!workFrame.getAttribute('src'))workFrame.src='work.html?shell=1'+(view?'#'+encodeURIComponent(view):'');
    else if(view)workFrame.contentWindow.location.hash=view;
    frame.hidden=true;workFrame.hidden=false;syncWorkspace(true);
  };
  window.thtOpenMeeting = id => {window.thtCloseWorkbench();viewedMeetingId=String(id||'');sessionStorage.setItem('tht-selected-meeting',viewedMeetingId);const q=new URLSearchParams(location.search);if(viewedMeetingId)q.set('id',viewedMeetingId);else q.delete('id');history.pushState(null,'',location.pathname+(q.toString()?'?'+q:'')+location.hash);syncWorkspace(true);};
  function syncWorkspace(force=false) {
    if (!ready) return;
    document.getElementById('b-assistant').textContent='✦ MyAgent';
    document.getElementById('b-work-top').textContent=workFrame.hidden?(ui==='en'?'Workbench':'工作台'):(ui==='en'?'← Meeting':'← 听会台');
    if(running&&!wasRunning){viewedMeetingId=cur?.id||'';workFrame.hidden=true;frame.hidden=false;}wasRunning=running;
    const context = {type:'tht-context', lang:ui,
      sessionId:viewedMeetingId || (cur?.id && (running || cur.transcript?.length) ? cur.id : ''), active:running,atSec:Number((location.hash.match(/(?:^#|&)t=(\d+(?:\.\d+)?)/)||[])[1]||0)};
    const key = JSON.stringify(context);
    if(force || key!==previous) { previous=key;frame.contentWindow.postMessage(context,location.origin);if(workFrame.getAttribute('src'))workFrame.contentWindow.postMessage({type:'tht-language',lang:ui},location.origin); }
  }
  frame.onload=()=>{ready=true;syncWorkspace(true);};
  workFrame.onload=()=>syncWorkspace(true);
  window.addEventListener('popstate',()=>{viewedMeetingId=new URLSearchParams(location.search).get('id')||'';syncWorkspace(true);});
  frame.src='meeting-board.html?embedded=1';
  window.addEventListener('hashchange',()=>{previous='';syncWorkspace(true);});
  setInterval(syncWorkspace,1000);
  const button=document.getElementById('b-assistant');
  button.textContent='✦ MyAgent';
  button.setAttribute('aria-controls','workspace-frame');
  button.addEventListener('click',e=>{
    e.preventDefault();e.stopImmediatePropagation();
    (workFrame.hidden?frame:workFrame).contentWindow.postMessage({type:workFrame.hidden?'tht-assistant':'tht-agent-open',open:true},location.origin);
  },true);
  document.getElementById('b-this').addEventListener('click',e=>{
    e.preventDefault();e.stopImmediatePropagation();
    window.thtCloseWorkbench();frame.contentWindow.postMessage({type:'tht-export'},location.origin);
  },true);
  window.addEventListener('message',async e=>{
    if(e.origin!==location.origin)return;
    if(e.source===workFrame.contentWindow){
      if(e.data?.type==='tht-work-return')window.thtCloseWorkbench();
      if(e.data?.type==='tht-open-meeting')window.thtOpenMeeting(e.data.id);
      if(e.data?.type==='tht-language'&&['zh','en'].includes(e.data.lang))document.querySelector('[data-ui="'+e.data.lang+'"]')?.click();
      return;
    }
    if(e.source!==frame.contentWindow)return;
    if(e.data?.type==='tht-selected-meeting'){viewedMeetingId=e.data.id;sessionStorage.setItem('tht-selected-meeting',viewedMeetingId);const q=new URLSearchParams(location.search);q.set('id',viewedMeetingId);history.pushState(null,'',location.pathname+(q.toString()?'?'+q:'')+location.hash);}
    if(e.data?.type==='tht-share-action'){
      await workspaceShareAction(e.data);
    }
    if(e.data?.type==='tht-assistant-state')button.setAttribute('aria-expanded',String(e.data.open));
    if(e.data?.type==='tht-language' && ['zh','en'].includes(e.data.lang))document.querySelector('[data-ui="'+e.data.lang+'"]')?.click();
    if(e.data?.type==='tht-app-panel'&&e.data.mode==='material'){document.getElementById('b-this').onclick();document.getElementById('more-title').textContent=ui==='en'?'Add meeting material':'补充会议资料';return;}
    if(e.data?.type==='tht-app-panel')document.getElementById(({settings:'gear2',history:'b-hist',update:'m-update'})[e.data.mode])?.click();
  });
}
