'use strict';
(()=>{
const $=s=>document.querySelector(s),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const labels={proposed:'待核实',todo:'待开始',doing:'进行中',blocked:'受阻',done:'已完成',parked:'暂存'};
const types={action:'待办',decision:'待决策',report:'汇报交付',insight:'研究输入'};
const roles={master:'长期主文档',report:'汇报材料',evidence:'会议与证据',reference:'参考资料',archive:'历史归档'};
let db=null,jobs=[],view='tasks',node='',query='',filter='',showClosed=false,loadedAt=0,undoable=null;
const VIEWS=['tasks','candidates','graph','sources'];
// 首访引导：URL 带 ?token= 就存进 tht-settings.relayToken 并从地址栏抹掉（手机扫码一次即可）
try{const q=new URLSearchParams(location.search),t=q.get('token');if(t){const c=JSON.parse(localStorage.getItem('tht-settings')||'{}');c.relayToken=t;localStorage.setItem('tht-settings',JSON.stringify(c));q.delete('token');history.replaceState(null,'',location.pathname+(q.toString()?'?'+q:'')+location.hash);}}catch{}
const auth=()=>{try{return JSON.parse(localStorage.getItem('tht-settings')||'{}').relayToken||''}catch{return ''}};
const base='/asr-relay/hub';
async function api(route='',body){const r=await fetch(base+route+(route.includes('?')?'&':'?')+'token='+encodeURIComponent(auth()),{cache:'no-store',...(body?{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify(body)}:{})});const j=await r.json();if(!r.ok)throw Error(j.error||'读取失败');return j;}
function message(s){$('#message').innerHTML=esc(s)+(undoable?' <button class="btn" id="undo-triage">撤销</button>':'')+(jobs.some(j=>['error','interrupted'].includes(j.status))?' <button class="btn" id="review-local-jobs">查看转写任务</button>':'')+(db?.sync?.recovery?.status==='warning'?` <button class="btn" id="review-recovery">核对恢复记录</button>`:'');}
const day=d=>{const t=new Date(d);return isNaN(t)?'':t.toLocaleDateString('zh-CN');};
const options=(list,v)=>list.map(([id,t])=>`<option value="${esc(id)}" ${id===v?'selected':''}>${esc(t)}</option>`).join('');
const closed=w=>['done','parked'].includes(w.status);
const sourceName=id=>db.sources.find(s=>s.id===id)?.title||'来源';
const nodeName=id=>db.knowledgeNodes.find(n=>n.id===id)?.title||'全部工作';
function path(id){const out=[],seen=new Set();let n=db.knowledgeNodes.find(n=>n.id===id);while(n&&!seen.has(n.id)){seen.add(n.id);out.unshift(n);n=db.knowledgeNodes.find(a=>a.id===n.parentId);}return out;}
const nodeOptions=v=>options([['','全部工作'],...db.knowledgeNodes.map(n=>[n.id,path(n.id).map(n=>n.title).join(' / ')])],v);
function scope(id){const ids=new Set(id?[id]:db.knowledgeNodes.map(n=>n.id));let last=-1;while(last!==ids.size){last=ids.size;db.knowledgeNodes.forEach(n=>{if(ids.has(n.parentId))ids.add(n.id)});}return ids;}
function selectedItems(){const ids=scope(node);return db.workItems.filter(w=>ids.has(w.nodeId)&&(showClosed||!closed(w))&&(!query||[w.title,w.notes,w.owner,...w.memberIds.map(id=>db.tasks.find(t=>t.id===id)?.text||'')].join(' ').toLowerCase().includes(query.toLowerCase())));}
function selectedSources(){const ids=scope(node),linked=new Set(db.workItems.filter(w=>ids.has(w.nodeId)).flatMap(w=>w.sourceIds));return db.sources.filter(s=>(ids.has(s.nodeId)||linked.has(s.id))&&(!query||(s.title+' '+(s.preview||'')).toLowerCase().includes(query.toLowerCase())));}
function syncWarning(){return Object.entries(db?.sync||{}).filter(([k,v])=>v&&['error','partial','warning'].includes(v.status)).map(([k,v])=>({disk:'本机资料',index:'飞书索引',knowledge:'知识关联',recovery:'恢复记录'}[k]||k)+'：'+(v.error||(v.errors?String(v.errors)+'项未完成':'部分未完成'))).join('；');}
async function load(){[db,jobs]=await Promise.all([api(),api('/jobs').catch(()=>[])]);loadedAt=Date.now();render();const warning=syncWarning()||(jobs.some(j=>['error','interrupted'].includes(j.status))?'本地转写有未完成任务，原始录音保留。':'');if(warning)message(warning);}
function navigate(v,id=node){view=VIEWS.includes(v)?v:'tasks';node=id;query='';filter='';limit=12;undoable=null;message('');render();window.scrollTo({top:0,behavior:'instant'});}
const dialogTop=t=>`<div class="dialog-top"><h2>${esc(t)}</h2><button class="btn" data-close>关闭</button></div>`;
function show(html){$('#detail-content').innerHTML=html;if(!$('#detail').open)$('#detail').showModal();}
async function submit(e,fn){e.preventDefault();const b=e.target.querySelector('[type=submit]');b.disabled=true;try{await fn();$('#detail').close();await load();message('已保存。');}catch(err){$('.form-status').textContent=err.message;}finally{b.disabled=false;}}
function crumbs(){return `<div class="breadcrumbs"><button data-node="">全部工作</button>${path(node).map(n=>`<span>›</span><button data-node="${n.id}">${esc(n.title)}</button>`).join('')}</div>`;}
function sourceRow(s){return `<div class="source-row"><div class="row-main">${s.url?`<a class="row-title" href="${esc(s.url)}" target="_blank" rel="noopener">${esc(s.title)} ↗</a>`:`<button class="row-title" data-source="${s.id}">${esc(s.title)}</button>`}<div class="meta">${esc(roles[s.knowledgeRole]||'资料')} · ${esc(s.channel||'来源')} · ${s.hasBody?'已读取快照':'原文链接'}${s.changed?' · 内容有变化，请核对':''}${s.fetchedAt?' · '+esc(day(s.fetchedAt)):s.snapshotDate?' · '+esc(s.snapshotDate):''}</div></div>${s.url?`<button class="row-action" data-source="${s.id}">笔记</button>`:''}</div>`;}
let limit=12,taskScope='mine';
// 归类由服务端算好放在 bucket 里（mine / candidate / notmine / ignored），这里不再按负责人猜：
// 生产库里 owner 写的是「本人」「Aaron」「S2」，旧的正则把 776 条真属于我的待办藏掉了。
const bucket=w=>w.bucket||'mine';
const editProjectOptions=v=>options(db.knowledgeNodes.map(n=>[n.id,path(n.id).map(n=>n.title).join(' / ')]),v);
const rootOf=id=>path(id)[0]?.id||id;
const projectOptions=v=>options([['','全部项目'],...db.knowledgeNodes.filter(n=>!n.parentId).map(n=>[n.id,n.title])],v);
// 会议来的待办里写的是「S2 负责…」。会后认人把这场的编号→人名存在它那份 source 上；
// 这里只在显示时替换，存的仍是原话（认错了改回来，待办正文不会被改坏）。
function applySpeakerNames(text,map){let t=String(text??'');for(const k of Object.keys(map||{})){const v=map[k];if(!v||!/^[A-Za-z0-9_]{1,12}$/.test(k))continue;t=t.replace(new RegExp('(?:说话人\\s*|Speaker\\s*|S)'+k+'(?!\\d)','g'),()=>v);}return t;}
const speakerMapFor=w=>Object.assign({},...(w.sourceIds||[]).map(id=>db.sources.find(s=>s.id===id)?.speakerNames||{}));
function itemRow(w){const map=speakerMapFor(w),title=applySpeakerNames(w.title,map),owner=applySpeakerNames(w.owner,map);
 return `<div class="task-row"><input type="checkbox" aria-label="完成：${esc(title)}" data-check="${w.id}" ${w.status==='done'?'checked':''}><div class="row-main"><button class="row-title ${w.status==='done'?'completed':''}" data-work="${w.id}">${esc(title)}</button><div class="meta">${esc(nodeName(rootOf(w.nodeId)))}${w.status!=='todo'?' · '+esc(labels[w.status]||w.status):''}${w.due?' · '+esc(w.due):''}${taskScope==='all'&&owner?' · '+esc(owner):''}</div></div></div>`;}
// 会议产生的待办先进候选，按场分组：每条三个动作，外加组头的「整场都不要」。
// 只改归类，不改文本、负责人、期限；每条都留一条回原句的路。
function candidateGroups(){
 const groups=new Map();
 for(const t of db.tasks.filter(t=>bucket(t)==='candidate')){
  const src=(t.sourceIds||[]).map(id=>db.sources.find(s=>s.id===id)).filter(Boolean);
  const s=src.find(x=>x.kind==='meeting')||src[0]||null;
  const key=s?s.id:'';
  if(!groups.has(key))groups.set(key,{source:s,tasks:[]});
  groups.get(key).tasks.push(t);
 }
 return [...groups.values()].sort((a,b)=>String(b.source?.date||'').localeCompare(String(a.source?.date||'')));
}
// 回原句：会议来源跳回看页并定位到那一刻（#t=秒），文档来源就开原文链接。
function backLink(t,s){
 if(s&&s.sessionId)return 'archive.html?id='+encodeURIComponent(s.sessionId)+(Number.isFinite(t.atSec)?'#t='+Math.round(t.atSec):'');
 return s&&s.url?s.url:'';
}
function candRow(t,s){const back=backLink(t,s);
 return `<div class="task-row cand-row" tabindex="0" data-cand="${esc(t.id)}"><div class="row-main"><div class="row-title">${esc(applySpeakerNames(t.text,s?.speakerNames))}</div><div class="meta">${t.owner?esc(applySpeakerNames(t.owner,s?.speakerNames))+' · ':''}${t.due?esc(t.due)+' · ':''}${back?`<a href="${esc(back)}" target="_blank" rel="noopener">回到原句 ↗</a>`:'原句位置没记下来'}</div></div><div class="cand-actions">${[['mine','我来做','1'],['notmine','不是我的','2'],['ignore','忽略','3']].map(([a,label,k])=>`<button class="btn" data-triage="${a}" data-id="${esc(t.id)}">${label}<span class="cand-key">${k}</span></button>`).join('')}</div></div>`;}
function candGroup(g){const s=g.source;
 return `<section class="cand-group"><div class="cand-head"><div><h2 class="section-title">${esc(s?s.title:'未关联来源')}</h2><div class="meta">${s&&s.date?esc(day(s.date))+' · ':''}${g.tasks.length} 条待认领</div></div>${s?`<button class="btn" data-ignore-all="${esc(s.id)}">整场都不要</button>`:''}</div><div class="listbox">${g.tasks.map(t=>candRow(t,s)).join('')}</div></section>`;}
const TRIAGE_DONE={mine:'已放进你的待办',notmine:'已标成不是你的',ignore:'已忽略','ignore-all':'整场已忽略'};
async function triage(body){
 const r=await api('/triage',body);
 const ids=(r.tasks||[]).map(t=>t.id);
 undoable=ids.length?{ids}:null;
 await load();
 message((TRIAGE_DONE[body.action]||'已处理')+' · '+ids.length+' 条。');
 // 重新渲染后焦点没了，键盘就断在这儿：把焦点放到下一条，1/2/3 才能连着按。
 if(view==='candidates')$('[data-cand]')?.focus();
}
const list=(items,fn,empty='这里暂时没有内容。')=>items.length?`<div class="listbox">${items.map(fn).join('')}</div>`:`<div class="blank">${empty}</div>`;
function render(){if(!db?.workItems)return;if(view!=='graph'&&node)node=rootOf(node);document.querySelectorAll('[data-view]').forEach(b=>b.setAttribute('aria-current',String(b.dataset.view===view)));
 const titles={tasks:['待办','记下下一步，完成一件，勾掉一件。'],candidates:['会议待办（候选）','开完会记下来的，按场归好。点「我来做」它才进你的待办。'],graph:['项目','每个项目的进展和资料，放在一起。'],sources:['资料','会议纪要、长期文档，都从这里找。']};const title=titles[view]||titles.tasks;
 // 候选条数放在导航上：不点进去也知道有多少条等着认领。
 const pending=db.tasks.filter(t=>bucket(t)==='candidate').length,navBtn=document.querySelector('[data-view="candidates"]');
 if(navBtn)navBtn.textContent='会议待办'+(pending?' · '+pending:'');
 $('#heading').textContent=node&&view==='graph'?nodeName(node):title[0];$('#subtitle').textContent=title[1];$('#add').hidden=['graph','candidates'].includes(view);$('#add').textContent=view==='sources'?'＋ 资料':'＋ 待办';$('#today').textContent=new Date().toLocaleDateString('zh-CN',{month:'long',day:'numeric',weekday:'long'});
 $('#filters').innerHTML=view==='candidates'?'':view==='graph'?node?'<button class="back-link" data-node="">← 所有项目</button>':'':`<div class="filters"><input id="search" aria-label="搜索" placeholder="${view==='sources'?'搜索资料':'搜索待办'}" value="${esc(query)}"><select id="node-filter" aria-label="项目">${projectOptions(node)}</select></div>${view==='tasks'?`<div class="segments"><button data-scope-filter="mine" aria-pressed="${taskScope==='mine'}">我的</button><button data-scope-filter="all" aria-pressed="${taskScope==='all'}">全部</button><label><input type="checkbox" id="show-closed" ${showClosed?'checked':''}>已完成与暂存</label></div>`:''}`;
 if(view==='graph')$('#filters').innerHTML+=crumbs()+`<details class="secondary"><summary>项目设置与导出</summary><button class="btn" id="new-node">新增层级</button>${node?'<button class="btn" id="edit-node">编辑当前层级</button>':''}<button class="btn" id="csv">导出工作清单 CSV</button></details>`+(node?db.knowledgeNodes.filter(n=>n.parentId===node).map(n=>`<button class="btn" data-node="${esc(n.id)}">${esc(n.title)} →</button>`).join(''):'');
 let ws=selectedItems(),ss=selectedSources(),html='';const order={doing:0,blocked:1,todo:2,proposed:3,done:4,parked:5};ws.sort((a,b)=>(order[a.status]??9)-(order[b.status]??9)||(a.due||'9999').localeCompare(b.due||'9999')||String(b.created||'').localeCompare(a.created||''));
 if(view==='tasks'){
   // 默认页只有「我的」：我手输的，和我在会议待办里点过「我来做」的。候选和忽略的都不在这儿。
   const visible=ws.filter(w=>taskScope==='all'?['mine','notmine'].includes(bucket(w)):bucket(w)==='mine'),actions=visible.filter(w=>w.kind==='action'||w.kind==='report'),decisions=visible.filter(w=>w.kind==='decision');
   html=list(actions.slice(0,limit),itemRow,query?'没有找到匹配的待办。':'目前没有你的未完成待办。可以新增一条，或切到「全部」查看协作事项。');
   if(actions.length>limit)html+=`<button class="more-items" id="show-more">再看 ${Math.min(12,actions.length-limit)} 条 · 还有 ${actions.length-limit} 条</button>`;
   const insights=visible.filter(w=>w.kind==='insight');if(insights.length)html+=`<details class="decision-list"><summary>研究输入 · ${insights.length}</summary>${list(insights,itemRow)}</details>`;
   if(decisions.length)html+=`<details class="decision-list"><summary>需要我决定 <span>${decisions.length}</span></summary>${list(decisions,itemRow)}</details>`;
 }
 if(view==='candidates'){const gs=candidateGroups();
   html=gs.length?gs.map(candGroup).join(''):'<div class="blank">没有待认领的会议待办。<p>开完会在听会台点「收进工作台」，新的候选会出现在这里。</p></div>';
 }
 if(view==='graph'){
   if(!node)html='<div class="project-grid">'+db.knowledgeNodes.filter(n=>!n.parentId).map(n=>{const items=db.workItems.filter(w=>rootOf(w.nodeId)===n.id&&!closed(w)&&w.kind!=='insight');return `<button class="project-card" data-node="${n.id}"><h2>${esc(n.title)}</h2><p>${items.length?items.length+' 项进行中的工作':'暂无未完成事项'}</p><span>查看项目 →</span></button>`;}).join('')+'</div>';
   else {html='<h2 class="section-title">进行中的工作</h2>'+list(ws.filter(w=>w.kind!=='insight').slice(0,limit),itemRow);if(ws.filter(w=>w.kind!=='insight').length>limit)html+='<button class="more-items" id="show-more">查看更多工作</button>';const docs=ss.filter(s=>['master','report'].includes(s.knowledgeRole));html+='<h2 class="section-title">常用文档</h2>'+list(docs,sourceRow)+`<button class="more-items" data-lens="sources" data-scope="${node}">查看项目全部资料 →</button>`;}
 }
 if(view==='sources'){ss.sort((a,b)=>Number(b.knowledgeRole==='master')-Number(a.knowledgeRole==='master')||String(b.fetchedAt||b.date||'').localeCompare(a.fetchedAt||a.date||''));html=list(ss.slice(0,limit*2),sourceRow,query?'没有找到匹配的资料。':'还没有收录资料。');if(ss.length>limit*2)html+=`<button class="more-items" id="show-more">加载更多资料</button>`;if(jobs.some(j=>j.status==='running'))html='<p class="subtle">录音正在处理，完成后会出现在资料中。</p>'+html;}
 $('#content').innerHTML=html;$('#sync-status').textContent='进度自动保存';
 if(!$('#detail').open)history.replaceState(null,'','#'+new URLSearchParams({view,node}));
}
function workDetail(id){const w=db.workItems.find(w=>w.id===id);if(!w)return;
 show(dialogTop('待办')+`<form id="edit-work">${!w.manual&&w.reason?`<p class="subtle">${esc(w.reason)}</p>`:''}${w.ownerConflict?.length?`<p class="subtle">来源中的负责人存在分歧：${esc(w.ownerConflict.join(' / '))}，请核对。</p>`:''}${w.parentId?`<p class="subtle">上级事项：${esc(db.workItems.find(x=>x.id===w.parentId)?.title||'未找到')}</p>`:''}<button class="btn" type="button" data-add-child="${esc(w.id)}">新增子待办</button><label>要做什么<input name="title" required value="${esc(w.title)}"></label><label>进展<textarea name="notes" placeholder="记下目前进展和下一步">${esc(w.notes)}</textarea></label><label>状态<select name="status">${options(Object.entries(labels),w.status)}</select></label><details class="secondary"><summary>类型、项目、负责人和日期</summary><label>类型<select name="kind">${options(Object.entries(types),w.kind)}</select></label><label>上级事项<select name="parentId">${options([['','无'],...db.workItems.filter(x=>x.id!==w.id).map(x=>[x.id,x.title])],w.parentId)}</select></label><label>项目<select name="nodeId">${editProjectOptions(w.nodeId)}</select></label><label>负责人<input name="owner" value="${esc(w.owner)}"></label><label>日期<input name="due" type="date" value="${esc(w.due)}"></label></details>${w.sourceIds.length?`<details class="secondary"><summary>来源 · ${w.sourceIds.length} 份</summary>${w.sourceIds.map(id=>`<p><button type="button" class="row-title" data-source="${id}">${esc(sourceName(id))}</button></p>`).join('')}</details>`:''}${w.memberIds.length>1?`<details class="secondary"><summary>包含的事项 · ${w.memberIds.length}</summary><p class="subtle">勾选完成会同步这些事项。</p>${w.memberIds.map(id=>db.tasks.find(t=>t.id===id)).filter(Boolean).map(t=>`<p>${esc(t.text)} <button type="button" class="btn" data-split="${esc(t.id)}" data-collection="${esc(w.id)}">拆为单独待办</button></p>`).join('')}</details>`:''}<div class="form-status" role="status"></div><div class="dialog-actions"><button class="btn" type="button" data-close>取消</button><button class="btn primary" type="submit">保存</button></div></form>`);
 $('#edit-work').onsubmit=e=>submit(e,()=>api('/knowledge/update',{kind:'work',id:w.id,revision:w.revision,patch:Object.fromEntries(new FormData(e.target))}));}
async function sourceDetail(id){const s=await api('/source?id='+encodeURIComponent(id)),linked=db.workItems.filter(w=>w.sourceIds.includes(id));show(dialogTop('资料')+`<form id="edit-source"><h3>${esc(s.title)}</h3>${s.archiveNote?`<p class="subtle">${esc(s.archiveNote)}</p>`:''}${s.changed?'<p class="subtle">内容有变化，请核对收录内容与在线原文。</p><button class="btn" type="button" id="ack-source-change">我已核对</button>':''}<details class="secondary"><summary>归属与关联</summary><div class="form-grid"><label>归属层级<select name="nodeId">${options(db.knowledgeNodes.map(n=>[n.id,path(n.id).map(n=>n.title).join(' / ')]),s.nodeId)}</select></label><label>用途<select name="knowledgeRole">${options(Object.entries(roles),s.knowledgeRole)}</select></label></div>${s.url?`<p><a class="btn" href="${esc(s.url)}" target="_blank" rel="noopener">打开在线原文 ↗</a></p>`:''}<p class="subtle">${s.fetchedAt?'最近读取：'+esc(day(s.fetchedAt)):s.snapshotDate?'本地快照：'+esc(s.snapshotDate):'来源正文按需读取。'}</p><h3>关联事项 · ${linked.length}</h3>${linked.map(w=>`<p><button type="button" class="row-title" data-work="${w.id}">${esc(w.title)}</button></p>`).join('')}${s.transcript?`<label>说话人姓名（编号=姓名）<textarea id="speaker-names">${esc(Object.entries(s.speakerNames||{}).map(([k,v])=>k+'='+v).join('\n'))}</textarea></label>`:''}<h3>关联资料</h3>${(s.relatedIds||[]).map(id=>`<p><button type="button" class="row-title" data-source="${id}">${esc(sourceName(id))}</button></p>`).join('')}<label>添加关联文档<select id="related-source"><option value="">选择文档</option>${db.sources.filter(x=>x.id!==id).map(x=>`<option value="${x.id}">${esc(x.title)}</option>`).join('')}</select></label></details><label>笔记<textarea id="source-notes">${esc(s.notes)}</textarea></label>${s.body?`<details open><summary>收录内容</summary><pre class="source-body">${esc(s.body)}</pre></details>`:'<p class="subtle">目前收录的是原文链接。</p>'}<div class="form-status" role="status"></div><details class="secondary"><summary>更新与处理</summary><div class="dialog-actions">${s.url&&/\/(docx|wiki)\//.test(s.url)?'<button class="btn" type="button" id="fetch-source">读取／更新原文</button>':''}${s.sessionId&&!s.sessionId.startsWith('local-')?'<label>人数（0=自动）<input type="number" id="local-speakers" min="0" max="20" value="0" style="width:70px"></label><button class="btn" type="button" id="local-asr">本地转写与分人</button>':''}${s.body?'<button class="btn" type="button" id="extract">提取行动项</button>':''}</div></details><div class="dialog-actions"><button class="btn primary" type="submit">保存笔记</button></div></form>`);$('#edit-source').onsubmit=e=>submit(e,async()=>{await api('/knowledge/update',{kind:'source',id,revision:s.revision,patch:{...Object.fromEntries(new FormData(e.target)),notes:$('#source-notes').value,relatedIds:[...new Set([...(s.relatedIds||[]),...($('#related-source').value?[$('#related-source').value]:[])])],...($('#speaker-names')?{speakerNames:Object.fromEntries($('#speaker-names').value.split('\n').map(l=>l.split('=').map(x=>x.trim())).filter(a=>a.length===2&&a[0]&&a[1]))}:{})}});});
 if($('#local-asr'))$('#local-asr').onclick=async e=>{e.target.disabled=true;try{await api('/asr',{sessionId:s.sessionId,speakers:parseInt($('#local-speakers').value)||0});$('#detail').close();await load();navigate('graph','meeting');message('正在本地转写，原始记录保留。');}catch(err){$('.form-status').textContent=err.message;e.target.disabled=false;}};
 if($('#ack-source-change'))$('#ack-source-change').onclick=async()=>{await api('/update',{kind:'sources',id,revision:s.revision,patch:{changed:false}});await load();await sourceDetail(id);};
 if($('#fetch-source'))$('#fetch-source').onclick=async e=>{e.target.disabled=true;$('.form-status').textContent='正在读取…';try{await api('/fetch',{id});await load();await sourceDetail(id);}catch(err){$('.form-status').textContent=err.message;e.target.disabled=false;}};
 if($('#extract'))$('#extract').onclick=async e=>{e.target.disabled=true;$('.form-status').textContent='正在提取并归入总待办…';try{await api('/extract',{id});await load();await sourceDetail(id);}catch(err){$('.form-status').textContent=err.message;e.target.disabled=false;}};
}
function editNode(){const n=db.knowledgeNodes.find(n=>n.id===node);if(!n)return;show(dialogTop('维护工作层级')+`<form id="node-edit"><label>名称<input name="title" required value="${esc(n.title)}"></label><label>上级<select name="parentId">${nodeOptions(n.parentId)}</select></label><label>这一层的目标与范围<textarea name="notes">${esc(n.notes)}</textarea></label><div class="form-status"></div><button class="btn primary" type="submit">保存</button></form>`);$('#node-edit').onsubmit=e=>submit(e,()=>api('/knowledge/update',{kind:'node',id:n.id,revision:n.revision,patch:Object.fromEntries(new FormData(e.target))}));}
function add(kind='work',parentId=''){if(kind==='node'){show(dialogTop('新增层级')+`<form id="create"><label>名称<input name="title" required autofocus></label><label>上级<select name="parentId"><option value="">无</option>${editProjectOptions(node||'')}</select></label><div class="form-status" role="status"></div><div class="dialog-actions"><button class="btn" type="button" data-close>取消</button><button class="btn primary" type="submit">保存</button></div></form>`);$('#create').onsubmit=e=>submit(e,()=>api('/knowledge/create',{kind:'node',...Object.fromEntries(new FormData(e.target))}));return;}const source=kind==='source';show(dialogTop(source?'收集资料':'新增待办')+`<form id="create"><label>${source?'标题':'要做什么'}<input name="title" required autofocus></label>${source?'<label>原文链接<input name="url" type="url"></label><label>正文或笔记<textarea name="body"></textarea></label>':`<label>项目<select name="nodeId">${editProjectOptions(node||'operations')}</select></label>`}<div class="form-status" role="status"></div><div class="dialog-actions"><button class="btn" type="button" data-close>取消</button><button class="btn primary" type="submit">保存</button></div></form>`);$('#create').onsubmit=e=>submit(e,()=>api(source?'/create':'/knowledge/create',{kind:source?'sources':'work',...(!source?{type:'action',parentId}:{}),...Object.fromEntries(new FormData(e.target))}));}
async function changeStatus(w,status){await api('/knowledge/update',{kind:'work',id:w.id,revision:w.revision,patch:{status}});await load();}
document.addEventListener('click',async e=>{const b=e.target.closest('button');if(!b)return;try{if(b.id==='review-local-jobs'){show(dialogTop('本地转写任务')+jobs.filter(j=>['error','interrupted'].includes(j.status)).map(j=>`<p>${esc(j.title)}：${esc(j.error||'处理已中断')} <button class="btn" data-retry-local="${esc(j.id)}">重试</button></p>`).join('')+'<div class="form-status" role="status"></div>');}if(b.dataset.retryLocal){b.disabled=true;try{await api('/asr/retry',{id:b.dataset.retryLocal});$('#detail').close();await load();}catch(err){$('.form-status').textContent=err.message;b.disabled=false;}}if(b.id==='review-recovery'){const r=db.sync.recovery;show(dialogTop('恢复记录')+`<p>${esc(r.error)}</p><p class="subtle">发现时间：${esc(r.at)}<br>恢复来源：${esc(r.backup)}</p><p>请先核对最近修改的待办和资料。确认只收起这条提醒，恢复记录仍保留。</p><div class="form-status" role="status"></div><div class="dialog-actions"><button class="btn" data-close>稍后核对</button><button class="btn primary" id="confirm-recovery">我已核对</button></div>`);$('#confirm-recovery').onclick=async ev=>{ev.target.disabled=true;try{await api('/recovery/ack',{at:r.at,backup:r.backup});$('#detail').close();await load();message(syncWarning()||'恢复记录已确认。');}catch(err){$('.form-status').textContent=err.message;ev.target.disabled=false;}};}
if(b.dataset.triage)await triage({ids:[b.dataset.id],action:b.dataset.triage});
if(b.dataset.ignoreAll)await triage({sourceId:b.dataset.ignoreAll,action:'ignore-all'});
if(b.id==='undo-triage'&&undoable){const ids=undoable.ids;undoable=null;await api('/triage',{ids,action:'restore'});await load();message('已撤销 '+ids.length+' 条，回到候选。');}
if(b.id==='show-more'){limit+=12;render();}if(b.dataset.scopeFilter){taskScope=b.dataset.scopeFilter;limit=12;render();}if(b.hasAttribute('data-close'))$('#detail').close();if(b.dataset.view)navigate(b.dataset.view,'');if(b.hasAttribute('data-node'))navigate('graph',b.dataset.node);if(b.dataset.lens)navigate(b.dataset.lens,b.dataset.scope);if(b.dataset.work)workDetail(b.dataset.work);if(b.dataset.source)await sourceDetail(b.dataset.source);if(b.dataset.addChild){const w=db.workItems.find(w=>w.id===b.dataset.addChild);node=w.nodeId;add('work',w.id);}if(b.dataset.split){const w=db.workItems.find(w=>w.id===b.dataset.collection);await api('/knowledge/split',{id:w.id,revision:w.revision,memberId:b.dataset.split});await load();workDetail(w.id);}if(b.id==='new-node')add('node');if(b.id==='edit-node')editNode();if(b.id==='csv')window.location.href=base+'/knowledge.csv?token='+encodeURIComponent(auth());}catch(err){message(err.message);const s=$('.form-status');if(s)s.textContent=err.message;}});
document.addEventListener('change',async e=>{try{if(e.target.id==='node-filter'){node=e.target.value;limit=12;render();}if(e.target.id==='type-filter'){filter=e.target.value;render();}if(e.target.id==='show-closed'){showClosed=e.target.checked;render();}if(e.target.dataset.check){const w=db.workItems.find(w=>w.id===e.target.dataset.check);await changeStatus(w,e.target.checked?'done':'todo');message('进度已保存。');}}catch(err){message(err.message);await load();}});
// 键盘 1/2/3：焦点落在某一条候选上就能直接分诊，一条一条过不用摸鼠标。
document.addEventListener('keydown',async e=>{
 if(view!=='candidates'||e.metaKey||e.ctrlKey||e.altKey)return;
 if(/^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName))return;
 const row=e.target.closest?.('[data-cand]'),action={1:'mine',2:'notmine',3:'ignore'}[e.key];
 if(!row||!action)return;
 e.preventDefault();
 try{await triage({ids:[row.dataset.cand],action});}catch(err){message(err.message);}
});
let timer;document.addEventListener('input',e=>{if(e.target.id==='search'){query=e.target.value;clearTimeout(timer);timer=setTimeout(()=>{const p=e.target.selectionStart;render();$('#search').focus();$('#search').setSelectionRange(p,p);},250);}});
$('#add').onclick=()=>add(view==='sources'?'source':'work');$('#sync').onclick=async e=>{e.target.disabled=true;message('正在收录和归类…');try{await api('/sync',{});await load();message(syncWarning()||'同步完成；未逐份核对的在线正文仍需读取。');}catch(err){message(err.message);}finally{e.target.disabled=false;}};
$('#export').onclick=async()=>{const d=await api('/export');const u=URL.createObjectURL(new Blob([JSON.stringify(d,null,2)],{type:'application/json'}));const a=document.createElement('a');a.href=u;a.download='工作记录.json';a.click();setTimeout(()=>URL.revokeObjectURL(u),1000);};
window.addEventListener('focus',()=>{if(!$('#detail').open&&Date.now()-loadedAt>15000)load().catch(e=>message(e.message));});
setInterval(()=>{if(!$('#detail').open&&jobs.some(j=>j.status==='running'))load().catch(e=>message(e.message));},10000);
const fromHash=h=>{const v=new URLSearchParams(h.slice(1)).get('view');return VIEWS.includes(v)?v:['decisions','reports','table'].includes(v)?'tasks':null;};
const params=new URLSearchParams(location.hash.slice(1));view=fromHash(location.hash)||view;node=params.get('node')||'';
window.addEventListener('hashchange',()=>{const p=new URLSearchParams(location.hash.slice(1));view=fromHash(location.hash)||view;node=p.get('node')||'';render();});
load().catch(e=>{message(e.message);$('#content').innerHTML='<div class="blank">暂时无法读取工作记录。请从已配置口令的听会台进入。<p><a href="./">打开听会台</a></p></div>';});
})();
