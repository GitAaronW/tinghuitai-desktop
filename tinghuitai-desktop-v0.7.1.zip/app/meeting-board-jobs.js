'use strict';
// Durable tasks: model work is serialized per meeting. Confirmed tool work is
// recorded before dispatch and never replayed automatically after a restart.
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const stores=new Map(),ACTIVE=['queued','running','planning','awaiting_confirmation','executing','uncertain'];
const error=(message,status=409)=>Object.assign(Error(message),{status});
function publicJob({request,pendingProposal,actionKey,...j}){return {...j,...(pendingProposal?{proposal:pendingProposal}:{})};}
class Jobs {
 constructor(dir){
  this.file=path.join(dir,'meeting-board-jobs.json');this.items=[];this.tails=new Map();
  try{const j=JSON.parse(fs.readFileSync(this.file,'utf8'));if(Array.isArray(j))this.items=j;}catch(e){if(e.code!=='ENOENT')throw e;}
  let dirty=false;for(const j of this.items){
   if(j.state==='executing'){j.state='uncertain';j.error='执行时服务重启，请先到对方核对结果 / Service restarted during execution; check the destination';dirty=true;}
   else if(['queued','running','planning'].includes(j.state)){j.state='interrupted';j.error='服务已重启，任务未完成，请重试 / Service restarted; retry the unfinished task';j.finished=new Date().toISOString();dirty=true;}
  }if(dirty)this.save();
 }
 save(){fs.mkdirSync(path.dirname(this.file),{recursive:true});const tmp=this.file+'.'+crypto.randomUUID()+'.tmp';try{fs.writeFileSync(tmp,JSON.stringify(this.items),{mode:0o600});fs.renameSync(tmp,this.file);}finally{try{fs.unlinkSync(tmp);}catch{}}}
 list(id){const all=this.items.filter(j=>j.meetingId===id);return all.filter((j,i)=>ACTIVE.includes(j.state)||i>=all.length-80).map(publicJob);}
 find(id,jobId){const j=this.items.find(j=>j.meetingId===id&&j.id===jobId);if(!j)throw error('任务不存在 / Task not found',404);return j;}
 enqueue(id,request,run){
  const duplicate=request.requestId&&this.items.find(j=>j.meetingId===id&&j.request?.requestId===request.requestId);if(duplicate)return publicJob(duplicate);
  if(this.items.filter(j=>['queued','running','planning'].includes(j.state)).length>=20)throw error('任务队列已满，请稍后再试 / Task queue full',429);
  const job={id:crypto.randomUUID(),meetingId:id,state:'queued',action:request.action,moduleId:request.moduleId||'',comment:request.comment||'',quote:request.selection?.original||'',lang:request.lang==='en'?'en':'zh',created:new Date().toISOString(),request};
  const oldItems=this.items.slice();this.items.push(job);if(this.items.length>1000)this.items=this.items.filter(j=>ACTIVE.includes(j.state)).concat(this.items.filter(j=>!ACTIVE.includes(j.state)).slice(-900));try{this.save();}catch(e){this.items=oldItems;throw e;}
  const previous=this.tails.get(id)||Promise.resolve();
  const work=previous.catch(()=>{}).then(async()=>{
   job.state=request.action==='run'?'planning':'running';job.started=new Date().toISOString();
   try{this.save();const result=await run(request);
    job.reply=result.reply||'已保存到本场工作台 / Saved to this workspace';job.resultRevision=result.source?.revision;job.resultIds=result.resultIds||[];
    if(result.proposal){job.pendingProposal=result.proposal;job.actionKey=result.actionKey;job.state='awaiting_confirmation';}
    else job.state=request.action==='run'?'planned':'completed';
   }catch(e){job.state='failed';job.error=e.message;}finally{job.finished=new Date().toISOString();this.save();}
  });
  this.tails.set(id,work);work.catch(()=>{}).finally(()=>{if(this.tails.get(id)===work)this.tails.delete(id);});return publicJob(job);
 }
 cancel(id,jobId){const j=this.find(id,jobId);if(j.state==='cancelled')return publicJob(j);if(j.state!=='awaiting_confirmation')throw error('这条任务不能取消 / This task cannot be cancelled');j.state='cancelled';try{this.save();}catch(e){j.state='awaiting_confirmation';throw e;}return publicJob(j);}
 confirm(id,jobId,confirmed,validate,run){
  if(confirmed!==true)throw error('请核对后点击确认 / Confirm after reviewing',400);
  const j=this.find(id,jobId);
  if(['executing','completed'].includes(j.state))return publicJob(j);
  if(j.state!=='awaiting_confirmation'||!j.pendingProposal)throw error('提案已失效或结果待核对 / Proposal expired or outcome needs checking');
  validate(j); // No await between checking the target and persisting executing.
  j.state='executing';j.confirmedAt=new Date().toISOString();
  try{this.save();}catch(e){j.state='awaiting_confirmation';delete j.confirmedAt;throw e;}
  Promise.resolve().then(()=>run(j)).then(result=>{
   j.state=result?.ok?'completed':result?.uncertain?'uncertain':'failed';j.reply=result?.text||'';
   if(!result?.ok)j.error=result?.error||result?.reason||'工具未返回成功回执 / No successful tool receipt';
   if(result?.url)j.resultUrl=result.url;
   if(result?.note)j.resultNote=result.note;
   if(result?.ok)j.executedAt=new Date().toISOString();
  },e=>{j.state='uncertain';j.error=e.message;}).finally(()=>{j.finished=new Date().toISOString();this.save();}).catch(()=>{});
  return publicJob(j);
 }
}
function get(dir){const key=path.resolve(dir);if(!stores.has(key))stores.set(key,new Jobs(key));return stores.get(key);}
module.exports={get,Jobs};
