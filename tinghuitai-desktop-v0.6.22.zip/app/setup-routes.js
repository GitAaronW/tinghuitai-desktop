'use strict';
module.exports=async function(req,res,u,{isLocal,localReason,settings,active,testModel,tokenOk}){
 const bootstrap=u.pathname==='/tinghuitai/bootstrap.js',setup=u.pathname==='/setup';
 const detect=u.pathname==='/setup/detect',agent=u.pathname==='/setup/agent';
 if(!bootstrap&&!setup&&!detect&&!agent&&u.pathname!=='/setup/test')return false;
 const json=(code,j)=>{res.writeHead(code,{'Content-Type':'application/json','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(JSON.stringify(j));return true;};
 // 非本机一律 403（跨站页面连 bootstrap.js 都不该拿到）；原因写在 403 的正文里，
 // 首页自己 fetch('/setup') 就能读到并展示，跨站页面因为没有 CORS 读不到。
 // 手机 / 外网页面（funnel 进来）拿不到 bootstrap.js，也就没有 boot 状态，「开始听会」会被
 // asrConfigured/macAsrAvailable 全空卡住（09-22 手机复现）。只读的就绪状态（不含任何密钥）
 // 允许带口令的远端 GET /setup 读到；写操作和 bootstrap.js 仍然只认本机。
 const remoteRead=!isLocal&&setup&&req.method==='GET'&&typeof tokenOk==='function'&&tokenOk(req.headers['x-tht-token']||u.searchParams.get('token'));
 if(!isLocal&&!remoteRead){const why=(typeof localReason==='function'?localReason():'')||'页面来源不是本机';return json(403,{error:'设置只能在本机打开：'+why});}
 const c=settings.load();
 const macAsr=(()=>{try{return require('./mac-asr').available();}catch(e){return false;}})();
 const asrLocal=c.ASR_PROVIDER==='mac';
 const asrDg=c.ASR_PROVIDER==='deepgram';
 const ownerProfile=typeof settings.dataDir==='string'?require('./owner-tracking').loadOwnerProfile(settings.dataDir):{id:'',displayName:'我'};
 const publicState={agentLabel:'MyAgent',provider:c.LLM_PROVIDER||'',asrProvider:c.ASR_PROVIDER||'',volcConfigured:!!(c.VOLC_APP_KEY&&c.VOLC_ACCESS_KEY),macAsrAvailable:macAsr,deepgramConfigured:!!c.DEEPGRAM_API_KEY,ready:!!((asrLocal||(asrDg&&c.DEEPGRAM_API_KEY)||(c.VOLC_APP_KEY&&c.VOLC_ACCESS_KEY))&&(c.DEEPSEEK_API_KEY||c.LLM_PROVIDER)),asrConfigured:!!(asrLocal||(asrDg&&c.DEEPGRAM_API_KEY)||(c.VOLC_APP_KEY&&c.VOLC_ACCESS_KEY)),modelConfigured:!!(c.DEEPSEEK_API_KEY||c.LLM_PROVIDER),base:c.LLM_BASE_URL,model:c.LLM_MODEL,resource:c.VOLC_RESOURCE_ID,archive:c.ARCHIVE_TARGET,ownerProfile};
 // X2（2026-09-22）：bootstrap.js 把 RELAY_TOKEN 当全局变量吐出来，原来只靠 isLocal 拦。
 // 漏洞：<script src> 是 no-cors 请求，不带 Origin；同机别的端口（旧中转 3101、deck 3102、任何本地 dev server）
 // 上的页面算 same-site 不算 cross-site，isLocal 全部通过 → 一行 script 标签就把全权口令读进它的 window。
 // 现在：被当成脚本加载（Sec-Fetch-Dest: script）时必须 same-origin。自家页面都是 <script src="bootstrap.js">
 // 相对路径同源加载，Chrome/Safari 给的就是 same-origin，不受影响。不发 Sec-Fetch-* 的老浏览器维持原行为。
 if(bootstrap&&req.method==='GET'){
  const dest=String(req.headers['sec-fetch-dest']||''),site=String(req.headers['sec-fetch-site']||'');
  if(dest==='script'&&site&&site!=='same-origin')return json(403,{error:'bootstrap.js 只能由本机同源页面加载（当前 '+site+'）'});
  res.writeHead(200,{'Content-Type':'application/javascript','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end('window.THT_BOOT='+JSON.stringify({...publicState,relayToken:c.RELAY_TOKEN})+';');return true;}
 // 远端只给就绪状态这几个字段（Codex 09-22 审核意见）：base / model / resource / archive 这类内部配置只留本机
 if(setup&&req.method==='GET'&&remoteRead){const {ready,asrConfigured,asrProvider,macAsrAvailable,modelConfigured,agentLabel}=publicState;return json(200,{ready,asrConfigured,asrProvider,macAsrAvailable,modelConfigured,agentLabel});}
 if(setup&&req.method==='GET')return json(200,publicState);
 // 本机装没装 AI 命令行：装了就不用申请 API Key
 if(detect&&req.method==='GET'){const found=require('./cli-llm').detect();return json(200,{found:Object.keys(found),provider:c.LLM_PROVIDER||''});}
 if(agent&&req.method==='POST'){
  if(active())return json(409,{error:'正在录音，请结束本场后再切换 MyAgent 后台'});
  if(req.headers['x-tht-token']!==c.RELAY_TOKEN)return json(403,{error:'请从本机设置页面操作'});
  let body='';for await(const chunk of req){body+=chunk;if(body.length>2000)return json(413,{error:'请求过长'});}
  let kind='';try{kind=String(JSON.parse(body||'{}').kind||'');}catch{}
  if(!['codex','claude','deepseek'].includes(kind))return json(400,{ok:false,error:'不认识这个 MyAgent 后台'});
  if(kind==='deepseek'){
   if(!c.DEEPSEEK_API_KEY)return json(409,{ok:false,error:'请先配置 DeepSeek API Key'});
   c.LLM_PROVIDER='deepseek';settings.save(c);return json(200,{ok:true,agentLabel:'MyAgent',provider:kind});
  }
  const r=await require('./cli-llm').probe(kind,settings.dataDir);
  if(!r.ok)return json(409,{ok:false,error:r.reason==='not_installed'?'这台电脑没有安装该后台':'该后台尚未登录或暂时不可用',reason:r.reason||''});
  c.LLM_PROVIDER=kind;settings.save(c);return json(200,{ok:true,agentLabel:'MyAgent',provider:kind});
 }
 if(detect&&req.method==='POST'){
  if(active())return json(409,{error:'正在录音，请结束本场后再改设置'});
  if(req.headers['x-tht-token']!==c.RELAY_TOKEN)return json(403,{error:'请从本机设置页面操作'});
  let body='';for await(const chunk of req){body+=chunk;if(body.length>2000)return json(413,{error:'请求过长'});}
  let kind='';try{kind=String(JSON.parse(body||'{}').kind||'');}catch{}
  if(!['codex','claude'].includes(kind))return json(400,{ok:false,error:'不认识这个工具'});
  const r=await require('./cli-llm').probe(kind,settings.dataDir);
  if(r.ok){c.LLM_PROVIDER=kind;settings.save(c);}
  const msg=r.ok?({codex:'Codex 已就绪，用的是你 ChatGPT 账号的额度，不用另外付钱。',claude:'Claude Code 已就绪，用的是你的 Claude 订阅，不用另外付钱。'})[kind]
    :(r.reason==='not_installed'?'没在这台电脑上找到它。':({codex:'找到了 Codex，但还没登录。打开「终端」，输入 codex 回车，按提示用 ChatGPT 账号登录，再回来点这里。',claude:'找到了 Claude Code，但还没登录。打开「终端」，输入 claude 回车，按提示登录 Claude 账号，再回来点这里。'})[kind]);
  return json(r.ok?200:200,{ok:!!r.ok,message:msg,reason:r.reason||''});
 }
 if(req.method!=='POST'||req.headers['content-type']!=='application/json'||req.headers['x-tht-token']!==c.RELAY_TOKEN)return json(403,{error:'请从本机设置页面操作'});
 if(active())return json(409,{error:'正在录音，请结束本场后再改设置'});
 if(u.pathname==='/setup/test'){const result=await testModel();return json(result?200:502,{ok:!!result,message:result?'模型已连通。语音服务请用30秒试录验证。':'模型未连通，请检查API Key、余额、模型名与网络。'});}
 let body='';for await(const chunk of req){body+=chunk;if(body.length>12000)return json(413,{error:'配置过长'});}
 try{const j=JSON.parse(body);
 if(typeof j.ASR_PROVIDER==='string'){const v=j.ASR_PROVIDER.trim();if(!['','volc','mac','deepgram'].includes(v))throw Error('转写方式取值不对');c.ASR_PROVIDER=v;}
 for(const k of Object.keys(settings.defaults)){if(k==='ASR_PROVIDER')continue;if(j[k]===undefined||['ARCHIVE_TARGET','THT_ARCHIVE_OWNER_ID','LLM_PROVIDER'].includes(k))continue;if(typeof j[k]!=='string'||j[k].length>4000||/[\r\n]/.test(j[k]))throw Error('字段格式不正确');if(['VOLC_APP_KEY','VOLC_ACCESS_KEY','DEEPSEEK_API_KEY','DEEPGRAM_API_KEY'].includes(k)&&!j[k])continue;c[k]=j[k].trim();}
 const base=new URL(c.LLM_BASE_URL);if(base.protocol!=='https:'||base.username||base.password||base.search||base.hash)throw Error('模型地址须为不含密钥的 HTTPS 地址');
 settings.save(c);
 // 选了本机转写就先把那个 .app 拉起来一次：系统的语音识别授权弹窗只认 GUI 会话，
 // 不先弹一次，用户开会时会以为坏了。它读不到 stdin 会自己退出。
 if(c.ASR_PROVIDER==='mac'){ try{ const {APP}=require('./mac-asr'); require('child_process').execFile('/usr/bin/open',['-a',APP,'--args','0','probe','zh-CN'],()=>{}); }catch(e){} }
 return json(200,{ok:true});}catch{return json(400,{error:'配置格式不正确，请检查模型地址与字段'});}
};
